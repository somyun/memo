# 부산교통공사 XPlatform 선로출입관리 HTTP 분석 요약

최종 갱신일: 2026-07-19  
대상 시스템: `https://mis.humetro.busan.kr/FS/`  
대상 업무: XPlatform 9.2.1 선로출입관리 (`LA`)

> 이 문서에는 비밀번호, 쿠키값, SSO 반환값, 실제 사번 및 조회 결과의 개인정보를 기록하지 않는다. HAR는 로그인 세션과 개인정보를 포함할 수 있으므로 자격증명 파일처럼 취급한다.

## 1. 최종 결론

- XPlatform 화면을 조작하지 않고 일반 HTTP 요청만으로 선로출입관리 데이터를 조회할 수 있다.
- Selenium, Chrome.ahk, XPlatform 런처 및 ERP 접속은 필요하지 않다.
- 공식 MIS 인증은 `MYSAPSSO2`가 아니라 `sso.humetro.busan.kr`의 중앙 SSO 리다이렉트로 이루어진다.
- 중앙 SSO가 인증 상태를 연결한 `mis.humetro.busan.kr`의 `JSESSIONID`가 실제 조회 세션이다.
- `ssoLogin.do`로 해당 MIS 세션을 초기화한 뒤 `selectList.do + LA10100.searchExcel`을 호출하면 엑셀 확장 Dataset을 받을 수 있다.
- 운전자 이름은 서버 검색조건이 아니므로 응답의 `DRIV_NAME`을 클라이언트에서 필터링해야 한다.
- 필요한 결과 필드는 `CNAP_BSNM`, `CNAP_NAME`, `APPR_NUMB`이다.

최종 HTTP 흐름:

```text
secret.txt 계정정보
→ btcep 포털 1차·2차 로그인
→ sso/pmi-sso.jsp
→ MIS index.jsp 및 install.jsp
→ MIS x_installChromeSSO.jsp
→ sso/pmi-sso2.jsp
→ MIS pmi-sso-return2 처리
→ 인증된 MIS JSESSIONID
→ ssoLogin.do
→ selectList.do + LA10100.searchExcel
→ DRIV_NAME 필터
→ 승인부서·승인자·승인번호 추출
```

## 2. 분석 자료와 HAR 구분

### `mis.humetro.busan.kr_pre.har`

- 통합로그인을 완료한 뒤 저장한 HAR이다.
- 5개의 MIS 요청 모두 Cookie 헤더를 포함한다.
- 기록된 쿠키 이름은 다음과 같다.

```text
JSESSIONID
_SSO_Global_Logout_url
EnviewLangKnd
tplsvcopenport
```

- `MYSAPSSO2`는 없다.
- 초기 데이터 조회 검증에서는 이 HAR에 있던 이미 인증·초기화된 MIS `JSESSIONID`를 메모리에서 재사용했다.
- 따라서 초기 분석은 “새 세션 생성”이 아니라 “기존 인증 세션으로 데이터 요청 재현”에 해당한다.

### `btcep.humetro.busan.kr.har`, `mis.humetro.busan.kr.har`

- 요청 Cookie 헤더, 응답 Set-Cookie 및 HAR cookies 객체가 제외돼 있다.
- 활성 세션 재사용 자료로는 사용할 수 없다.
- 로그인 요청 형식, 설치 페이지 및 런처 요청 구조 분석에 사용했다.

### `btcep.humetro.busan.kr_new.har`, `mis.humetro.busan.kr_new.har`

- 로그아웃 상태에서 포털 로그인과 MIS 접속까지 다시 기록한 sensitive-data 포함 HAR이다.
- 쿠키값을 출력하지 않고 쿠키 이름, 호스트, 값의 동일성 및 리다이렉트 순서를 추적했다.
- 두 HAR 어디에도 `MYSAPSSO2`가 없다.
- 중앙 SSO와 MIS 인증의 실제 연결 메커니즘을 확정하는 자료로 사용했다.

## 3. 공식 중앙 SSO 인증 메커니즘

로그인 과정에는 이름이 같은 서로 다른 세 개의 `JSESSIONID`가 존재한다.

```text
btcep.humetro.busan.kr | JSESSIONID
sso.humetro.busan.kr   | JSESSIONID
mis.humetro.busan.kr   | JSESSIONID
```

쿠키 이름만으로 저장하면 서로 덮어쓰므로 반드시 도메인과 경로를 포함해 구분해야 한다.

### 3.1 포털 로그인과 중앙 SSO 세션 생성

```text
POST https://btcep.humetro.busan.kr/user/loginProcess.face
→ 302 https://sso.humetro.busan.kr/sso/pmi-sso.jsp
```

`pmi-sso.jsp`는 중앙 SSO 도메인의 별도 `JSESSIONID`를 발급하고 포털로 돌려보낸다. 이 쿠키는 이후 MIS가 호출하는 `pmi-sso2.jsp`에서 포털 로그인 상태를 확인하는 데 사용된다.

### 3.2 MIS 익명 세션 생성

```text
GET https://mis.humetro.busan.kr/FS/index.jsp?gv_selSystGubn=LA
```

MIS는 이 요청에서 `/FS` 경로의 `JSESSIONID`를 발급한다. 발급 직후에는 서버 세션 공간만 만들어진 익명 세션이며, 쿠키 존재 자체가 로그인 성공을 의미하지 않는다.

### 3.3 MIS와 중앙 SSO의 인증값 교환

```text
GET /FS/xui/install/x_installChromeSSO.jsp
→ 302 sso.humetro.busan.kr/sso/pmi-sso2.jsp
```

첫 리다이렉트에는 다음 이름의 파라미터가 사용된다.

```text
from
pmi-sso2
returl
sinfo
```

중앙 SSO는 자신의 `JSESSIONID`로 포털 로그인 상태를 확인한 뒤 MIS로 되돌아갈 일회성 반환값을 만든다.

```text
sso/pmi-sso2.jsp
→ 302 MIS x_installChromeSSO.jsp?pmi-sso-return2=...
```

MIS는 반환값을 검증하고 기존 MIS `JSESSIONID`에 사용자 인증 상태를 연결한다. 이어 임시 반환값을 제거하기 위한 자체 리다이렉트를 거쳐 최종 설치 페이지를 반환한다.

```text
x_installChromeSSO.jsp?pmi-sso-return2=...
→ x_installChromeSSO.jsp?returnurl=...
→ x_installChromeSSO.jsp?gv_selSystGubn=LA&gv_userBrowser=Edg
→ HTTP 200
```

최종 페이지의 `userId`가 로그인 사번과 일치하는지 확인한다.

### 3.4 XPlatform 세션 초기화

중앙 SSO 인증을 마친 동일한 MIS `JSESSIONID`로 다음 요청을 호출한다.

```text
POST /FS/ssoLogin.do
queryId=login.userSSOSelect
```

성공 조건:

```text
ErrorCode=0
```

쿠키가 없는 새 세션은 자체 `JSESSIONID`를 발급받더라도 다음 오류를 반환한다.

```text
ErrorCode=-1
ErrorMsg=통합 로그인 후 이용하세요.
```

즉 `ssoLogin.do`의 사번만으로 인증하는 구조가 아니다. POST 요청에 사용된 MIS `JSESSIONID`가 앞선 중앙 SSO 과정에서 인증된 세션이어야 한다.

## 4. 쿠키 역할과 최소 요구사항

### 중앙 SSO 초기화 전

- `sso.humetro.busan.kr`의 `JSESSIONID`: 포털 로그인 상태를 중앙 SSO에서 증명한다.
- `mis.humetro.busan.kr`의 `JSESSIONID`: 중앙 SSO 반환값을 검증한 사용자 상태가 연결될 대상이다.

### MIS 초기화 후 조회

실제 최소 쿠키 시험에서는 인증·초기화가 완료된 MIS `JSESSIONID` 하나만으로 조회에 성공했다.

```text
Cookie: JSESSIONID=<MIS 세션값>
POST /FS/selectList.do
→ ErrorCode=0
→ Dataset 97행
```

다음 쿠키들은 실제 LA10100 데이터 조회의 필수 쿠키가 아니다.

```text
_SSO_Global_Logout_url   통합 로그아웃 연동
EnviewLangKnd            언어 설정
tplsvcopenport           로컬 런처 포트 상태
btcep JSESSIONID         포털 세션
sso JSESSIONID           MIS 인증 전 중앙 SSO 확인용
```

### `MYSAPSSO2`에 대한 최종 판단

- `MYSAPSSO2`는 ERP/SAP 접속 과정에서 발급되는 통합 SSO 쿠키이다.
- TotalAuto는 이미 확보한 ERP 쿠키를 XPlatform 런처의 `addWebInfo`에 전달하는 우회 경로를 사용한다.
- `MYSAPSSO2`를 강제로 전달한 시험도 MIS 초기화에 성공했으므로 사용할 수 있는 충분조건이 될 수는 있다.
- 그러나 공식 MIS HAR와 ERP를 전혀 사용하지 않은 재현 시험 모두 `MYSAPSSO2` 없이 성공했다.
- 따라서 `MYSAPSSO2`는 MIS/XPlatform 조회의 필요조건이 아니다.

## 5. 최초 HTTP 자동 로그인 시험이 실패했던 이유

최초 시험에서는 다음까지 확인했지만 `ssoLogin.do=-1`이 발생했다.

```text
포털 로그인 성공
MIS JSESSIONID 발급
최종 설치 페이지의 userId 일치
ssoLogin.do 실패
```

당시 AutoHotkey가 설치되지 않아 AHK 자체가 아니라 별도 HTTP 검증 코드로 시험했다. 쿠키값을 기록하지 않는 원칙 때문에 다음 세 요청의 MIS `JSESSIONID` 동일성을 확인하지 못했다.

```text
x_installChromeSSO.jsp 최초 요청
pmi-sso-return2 복귀 요청
ssoLogin.do 요청
```

새로운 실험에서 최초 구현과 동일한 조건을 그대로 재현했다.

```text
요청마다 새 WinHttp.WinHttpRequest 객체 사용
공통 수동 쿠키 저장소 사용
MYSAPSSO2 및 ERP 미사용
```

재검증 결과:

```text
중앙 SSO 리다이렉트 확인
MIS 사용자 일치
ssoLogin.do ErrorCode=0
searchExcel ErrorCode=0
Dataset 97행
```

따라서 최초 구조 자체의 한계가 아니었다. 최초 대체 검증에서 `ssoLogin.do`가 사용한 MIS `JSESSIONID`가 중앙 SSO에서 인증된 세션과 이어지지 않은 실험상의 거짓 음성이었다. 이를 `MYSAPSSO2` 누락으로 해석한 것은 잘못이었다.

중요한 것은 WinHTTP 객체 재사용 여부가 아니라 다음 조건이다.

```text
btcep, sso, mis의 동일 이름 쿠키를 호스트/경로별로 분리
모든 Location과 쿼리 문자열을 손실 없이 추적
pmi-sso-return2를 포함한 리다이렉트 체인을 끝까지 완료
동일한 MIS JSESSIONID로 ssoLogin.do와 조회 호출
```

## 6. XPlatform 런처와 네이티브 통신

공식 신규 HAR의 로컬 런처 요청은 다음과 같다.

```text
create
check
getengineversion
setproperty
launch
```

`setproperty`의 중요 값:

```text
xadl=https://mis.humetro.busan.kr:443/FS/xui/XUI.xadl
usewininet=true
globalvalue=
  gv_selSystGubn=LA
  gv_userBrowser=Edg
  gv_ssoUserId=<사번>
  gv_svcUrl=https://mis.humetro.busan.kr:443/FS/
```

`newlauncher_new.js`에는 `addWebInfo` 구현이 존재하지만 공식 실행 흐름에서는 호출되지 않았다. 신규 런처 HAR에도 `addWebInfo` 요청이 없다.

XPlatform 네이티브 프로세스의 HTTP 통신은 브라우저 HAR에 기록되지 않으므로 브라우저 쿠키가 네이티브 프로세스에 전달되는 내부 구현 전체를 HAR만으로 확인할 수는 없다. HTTP 전용 구현에서는 네이티브 전달을 모방하지 않고 하나의 논리적 쿠키 저장소에서 중앙 SSO부터 데이터 조회까지 연속 수행한다.

## 7. XPlatform 리소스와 화면 구조

주요 정적 리소스:

```text
/FS/xui/XUI.xadl
/FS/xui/default_typedef.xml
/FS/xui/globalvars.xml
/FS/xui/frame/loginFrame.xfdl
/FS/xui/lib/commTran.xjs
/FS/xui/la/LA10000/LA10100.xfdl
```

`default_typedef.xml`에서 확인한 별칭:

```text
LA10000 → ./la/LA10000
```

따라서 `LA10000::LA10100.xfdl`의 실제 주소는 다음과 같다.

```text
https://mis.humetro.busan.kr/FS/xui/la/LA10000/LA10100.xfdl
```

선로출입관리 메뉴:

| 메뉴 | XFDL |
|---|---|
| 선로출입현황 조회 | `LA10100.xfdl` |
| 선로출입 등록/신청 | `LA10200.xfdl` |
| 선로출입 승인 | `LA10300.xfdl` |
| 선로출입 작업현황 관리 | `LA10400.xfdl` |
| 작업현황 관리(관제) | `LA10500.xfdl` |
| 선로 내 모터카 운행구간 | `LA10600.xfdl` |
| 역사 영업준비 조회 | `LA10700.xfdl` |
| 철도운행안전협의 | `LA10800.xfdl` |

## 8. LA10100 조회 요청

### 일반 화면 조회

```text
POST /FS/procSelect.do
Content-Type: text/xml; charset=UTF-8
queryId=LA10100.search
```

응답:

```text
ds_out → 화면 Dataset ds_fsmsliacxm
확인된 열 수: 46개
```

### 엑셀 확장 조회

```text
POST /FS/selectList.do
Content-Type: text/xml; charset=UTF-8
queryId=LA10100.searchExcel
```

응답:

```text
ds_out → 엑셀 Dataset ds_fsmsliacxm00
확인된 열 수: 54개
CNAP_BSNM 포함
```

조회 파라미터:

| 파라미터 | 의미 | 전체 조건 |
|---|---|---|
| `IN_START_DATE` | 시작일 | 필수 날짜 |
| `IN_END_DATE` | 종료일 | 필수 날짜 |
| `IN_LINE_CODE` | 호선 | 빈 문자열 |
| `IN_STST_CODE` | 시작역 | 빈 문자열 |
| `IN_FNST_CODE` | 종료역 | 빈 문자열 |
| `IN_REQU_BSCD` | 요청부서 코드 | 빈 문자열 |
| `IN_WORK_CODE` | 작업구분 | 빈 문자열 |
| `IN_STUS` | 상태 | 빈 문자열 |

화면에 보이는 전체 부서 경로가 아니라 부서코드만 `IN_REQU_BSCD`에 전달한다. 전체 부서 조회는 빈 문자열을 사용한다.

## 9. 운전자 승인정보 추출

필드 매핑:

```text
운전자 이름       → DRIV_NAME
운행관제승인부서  → CNAP_BSNM
운행관제승인사번  → CNAP_USER
운행관제승인자    → CNAP_NAME
운행관제승인일자  → CNAP_DATE
승인번호          → APPR_NUMB
작업구분          → WORK_CODE
내역              → PRMT_CTNT

확인부서          → CONF_BSNM
확인자사번        → CONF_USER
확인자            → CONF_NAME
확인일자          → CONF_DATE
```

`DRIV_NAME`은 `LA10100.searchExcel`의 서버 검색조건이 아니다. 지정 기간의 전체 확장 Dataset을 받은 뒤 정확 일치 또는 부분 일치로 필터링한다.

사용자가 요청한 최종 출력:

```text
CNAP_BSNM  → 운행관제승인부서
CNAP_NAME  → 운행관제승인자
APPR_NUMB  → 승인번호
WORK_CODE  → 작업구분
PRMT_CTNT  → 내역
```

## 10. 오류 코드 해석

```text
ErrorCode=0
  정상 처리

ErrorCode=-1
  중앙 SSO 인증을 완료하지 않은 MIS 세션으로 ssoLogin.do 호출

ErrorCode=-99999
  MIS 세션이 없거나 만료됐거나 초기화되지 않은 상태로 업무 요청 호출
```

HTTP 200만으로 성공을 판단하지 않고 반드시 XPlatform XML의 `ErrorCode`를 검사한다.

## 11. 실제 검증 결과

### 기존 인증 세션 재사용

- `mis.humetro.busan.kr_pre.har`의 인증된 `JSESSIONID`를 사용했다.
- 일반 조회: HTTP 200, `ErrorCode=0`, 46열 Dataset.
- 엑셀 조회: HTTP 200, `ErrorCode=0`, 54열 Dataset, `CNAP_BSNM` 확인.

### 계정정보에서 새 세션 생성

ERP 요청과 `MYSAPSSO2` 없이 다음을 실제 계정으로 검증했다.

```text
포털 1차 사용자 확인: 성공
포털 1차 비밀번호 확인: 성공
포털 2차 비밀번호 확인: 성공
중앙 SSO pmi-sso.jsp: 성공
MIS pmi-sso2/pmi-sso-return2: 성공
MIS 사용자 사번 일치: 성공
ssoLogin.do: ErrorCode=0
LA10100.searchExcel: ErrorCode=0
Dataset: 97행
```

민감한 값과 응답 원문은 출력하거나 저장하지 않았다.

## 12. 최종 AHK v2 구현

대상 파일:

```text
totalauto_session_exam.ahk
```

구현 내용:

- `secret.txt` 또는 `secret.txt.txt`에서 `사번`, `1차비번`, `2차비번` 읽기.
- 기존 WinINet MIS 세션이 있으면 먼저 재사용 시도.
- 없으면 WinHTTP로 포털 로그인과 중앙 SSO 수행.
- `btcep`, `sso`, `mis` 쿠키를 도메인·경로별로 메모리에서 분리 관리.
- 리다이렉트 `Location`을 수동으로 따라가며 모든 Set-Cookie 반영.
- 최종 설치 페이지의 사용자 사번 검증.
- `ssoLogin.do` 성공 검증.
- `selectList.do + LA10100.searchExcel` 호출.
- `DRIV_NAME` 정확 일치 또는 부분 일치.
- `CNAP_BSNM`, `CNAP_NAME`, `APPR_NUMB`만 화면 표시.
- 비밀번호, 쿠키, SSO 반환값 및 XML 원문 비저장·비출력.
- Selenium, Chrome.ahk, ERP 및 XPlatform 런처 미사용.

현재 PC에는 AutoHotkey v2가 설치되어 있지 않아 GUI 스크립트 자체의 실행 검증은 남아 있다. 스크립트가 사용하는 것과 같은 HTTP 및 쿠키 흐름은 실제 계정으로 조회 성공까지 검증했다.

## 13. 세션 만료와 다른 PC 재사용

MIS `JSESSIONID`의 Set-Cookie 속성:

```text
Path
Secure
HttpOnly
```

`Expires`와 `Max-Age`가 없는 세션 쿠키이므로 정확한 서버 측 유휴 만료시간은 HAR만으로 알 수 없다.

세션이 무효화되는 조건:

- AHK 종료로 메모리 쿠키 유실.
- MIS 서버의 유휴 세션 제한 도달.
- 통합 로그아웃.
- 서버 재시작 또는 서버 측 세션 정리.
- 보안 정책에 따른 강제 무효화.

인증·초기화된 MIS `JSESSIONID`만으로 별도 HTTP 클라이언트에서 조회가 성공했다. 따라서 서버가 IP, 장치, TLS 연결 또는 서버 노드에 별도로 결속하지 않는다면 다른 PC에서도 같은 세션이 재사용될 가능성이 높다. 이는 세션 이전이면서 세션 탈취와 동일한 효과를 가지므로 허가된 환경에서만 검증하고 비밀번호와 같은 수준으로 보호해야 한다.

## 14. 보안 및 운영 주의사항

- `secret.txt`와 모든 sensitive-data HAR를 Git, 메일 또는 메신저에 올리지 않는다.
- 쿠키, 비밀번호, 사번, SSO 반환값 및 원문 Dataset을 로그에 남기지 않는다.
- 조회 권한이 있는 데이터와 업무 목적 범위에서만 사용한다.
- 대량 조회 시 기간을 나누고 요청 간격을 둔다.
- 저장·승인·삭제 기능을 수행하는 엔드포인트는 자동화 대상에서 제외한다.
- 결과 데이터의 이름, 연락처 및 승인정보에 접근 권한과 보관 기간을 적용한다.
- 사용 후 통합 로그아웃으로 서버 세션을 무효화한다.
