# TotalAuto 핸디웨어 공람문서 HTTP 연동 적용 가이드

## 1. 문서 목적

이 문서는 `TotalAuto`에 브라우저, Selenium, `chrome.ahk` 없이 HTTP 요청만으로 핸디웨어의 `공람대기` 및 `공람완료` 문서 목록을 조회하는 기능을 추가하기 위한 구현 지침이다.

다른 개발자나 AI가 기존 ERP 세션 기능을 손상시키지 않고 구현할 수 있도록 다음 내용을 구체적으로 설명한다.

- 실제로 검증된 HTTP 요청 순서
- `세션BG.ahk`에 추가해야 하는 핸디웨어 세션 초기화 과정
- 같은 이름의 `JSESSIONID`를 경로별로 보존하는 방법
- `Main.ahk`와 `헤드리스.ahk`의 쿠키 전달 구조 변경
- 사용자·부서·폴더 파라미터를 HAR에 의존하지 않고 동적으로 얻는 방법
- 공람완료 목록 요청 본문 구성과 HTML 파싱 방법
- 세션 만료, HTML 오류 페이지, 빈 목록을 구분하는 방법
- 단계별 검증 항목과 완료 조건

이 문서는 설계 및 적용 가이드이며, 현재 `TotalAuto` 원본 파일에는 핸디웨어 관련 변경을 적용하지 않은 상태다.

---

## 2. 기준 파일

구현 전 다음 파일을 함께 확인해야 한다.

| 파일 | 역할 |
|---|---|
| `TotalAuto/세션BG.ahk` | 통합포털, NIW, ERP 세션 생성 및 쿠키 반환 |
| `TotalAuto/헤드리스.ahk` | 저장된 쿠키로 실제 HTTP 업무 요청 수행 |
| `TotalAuto/Main.ahk` | `세션BG.exe` 실행, 결과 JSON 수신 및 `HeadlessAutomation`에 저장 |
| `TotalAuto/유저로그인.ahk` | CDP 브라우저 쿠키 주입을 사용하는 기존 경로 |
| `btcep.humetro.busan.kr_handy.har` | 포털 로그인부터 공람대기·공람완료까지의 실제 네트워크 기록 |
| `handy_http_simulation.ps1` | HTTP 전용 로그인 및 공람완료 50행 추출에 성공한 검증 코드 |

`handy_http_simulation.ps1`은 운영 코드가 아니라 메커니즘 검증용이다. 이 스크립트는 HAR의 공람완료 요청 본문을 사용하므로 운영 구현에서는 HAR 의존 부분을 동적 추출 방식으로 교체해야 한다.

---

## 3. 검증 완료된 사실

### 3.1 HTTP 전용 조회 성공 결과

다음 전체 과정을 브라우저 없이 HTTP 요청만으로 실행해 성공했다.

1. 통합포털 로그인
2. 핸디웨어 SSO 진입
3. NIW 루트 세션 생성
4. BMS 세션 생성
5. `frame.jsp` 사용자 세션 초기화
6. 공람완료 목록 POST
7. HTML에서 실제 문서 행 계수

검증 결과는 다음과 같다.

```text
PortalFinalHost         : btcep.humetro.busan.kr
HandySsoFinalPath       : /sso/index.jsp
BmsLoginStatus          : 200
FrameStatus             : 200
NiwJSessionIdCount      : 2
ListStatus              : 200
SessionError            : False
RenderedBodyRows        : 50
ExtractableDocumentRows : 50
DocumentAreaLinks       : 296
UserInfoCallCount       : 196
```

따라서 HTTP 요청만으로 공람완료 문서 50행을 추출할 수 있다는 점은 확인되었다.

### 3.2 목록 엔드포인트

```text
공람대기
POST https://niw.humetro.busan.kr/bms/com/hs/gwweb/appr/retrieveCnrsWaitDocList.act

공람완료
POST https://niw.humetro.busan.kr/bms/com/hs/gwweb/appr/retrieveCnrsComptDocList.act
```

공통 특성:

- 요청 형식: `application/x-www-form-urlencoded`
- 응답 형식: `text/html;charset=utf-8`
- JSON 또는 XPlatform Dataset이 아니라 서버가 렌더링한 HTML
- HTTP 상태가 200이어도 세션 오류 HTML일 수 있음
- HAR에서는 별도 CSRF 헤더나 CSRF 토큰이 발견되지 않음
- 목록 요청은 AJAX 요청이 아니므로 `X-Requested-With`가 필수 아님

### 3.3 화면별 상수

| 구분 | 엔드포인트 | `APPLID` / `applId` |
|---|---|---:|
| 공람완료 | `retrieveCnrsComptDocList.act` | `3010` |
| 공람대기 | `retrieveCnrsWaitDocList.act` | `3020` |

`fldrId`는 폴더 트리 응답에서 동적으로 추출하는 것이 안전하다. HAR의 값을 코드에 고정하지 않는다.

---

## 4. 현재 TotalAuto 구조의 문제점

### 4.1 현재 NIW 세션은 ERP 진입까지만 준비함

현재 `세션BG.ahk`는 대략 다음 순서로 동작한다.

```text
btcep 로그인
  → 중앙 SSO 교환
  → niw /sso/index.jsp 호출
  → erpep.jsp에서 ERP용 값 추출
  → ep 로그인
  → MYSAPSSO2 획득
```

핸디웨어 공람 목록에 필요한 다음 단계는 수행하지 않는다.

```text
menuType=approval SSO 페이지 요청
  → /bms/login.cmmn
  → /jsp/main/frame.jsp
  → /bms 전용 JSESSIONID 생성
```

ERP의 `MYSAPSSO2`는 핸디웨어 목록 조회와 직접 관계가 없다. ERP 세션 생성 과정은 그대로 유지하되, NIW 단계에 핸디웨어 세션 초기화를 별도로 추가해야 한다.

### 4.2 이름만 사용하는 쿠키 Map은 중복 JSESSIONID를 잃어버림

현재 구조는 다음과 같다.

```ahk
btcep_cookies := Map()
niw_cookies := Map()
ep_cookies := Map()
```

그리고 쿠키 이름을 키로 사용한다.

```ahk
current_cookies[cookieName] := cookieValue
```

하지만 핸디웨어 초기화 후에는 `niw.humetro.busan.kr`에 다음 쿠키가 동시에 존재한다.

```text
JSESSIONID; Path=/
JSESSIONID; Path=/bms
```

두 쿠키는 이름은 같지만 값과 적용 경로가 다르다. 실제 성공한 시뮬레이션에서도 NIW에 `JSESSIONID`가 두 개 존재했다.

이름만 키로 사용하면 나중에 발급된 `/bms` 쿠키가 기존 루트 쿠키를 덮어쓴다. 그러면 다음 문제가 생긴다.

- `/jsp/main/frame.jsp`에 잘못된 `/bms` 세션을 보냄
- `/bms/...` 요청에 루트 세션만 보내 BMS 인증 실패
- 새로 로그인했는데도 `<title>세션 에러</title>`가 반환됨

### 4.3 HeadlessAutomation도 경로 정보를 잃어버림

현재 `헤드리스.ahk`는 도메인 키 하나에 쿠키 문자열 하나를 저장한다.

```text
btcep
niw
ep
```

`_SendRequest()`는 URL 호스트만 보고 `niw` 쿠키 하나를 보낸다. `/bms` 경로를 별도로 처리하지 않는다.

CDP용 `GetCookieParamsForCDP()`도 모든 쿠키의 경로를 `/`로 고정한다. `/bms` 쿠키를 브라우저에 주입할 경우에도 경로를 보존해야 한다.

---

## 5. 권장 변경 전략

전체 쿠키 저장소를 RFC 방식으로 다시 작성하는 것이 가장 정확하지만, 기존 ERP 코드의 변경 범위를 줄이기 위해 다음의 분리 저장 방식을 우선 권장한다.

```ahk
btcep_cookies  := Map()
niw_cookies    := Map() ; niw 루트 Path=/ 쿠키
niw_bms_cookies := Map() ; Path=/bms 쿠키
ep_cookies     := Map()
```

이 방식의 전제:

- `niw_bms_cookies`에는 `/bms`에서 발급된 쿠키만 저장한다.
- `/jsp/...`, `/sso/...` 요청에는 `niw_cookies`만 보낸다.
- `/bms/...` 요청에는 `niw_bms_cookies`를 먼저, `niw_cookies`를 뒤에 연결해 보낸다.
- 같은 이름의 `JSESSIONID`가 두 개면 경로가 더 구체적인 `/bms` 쿠키를 먼저 보낸다.

예시:

```text
Cookie: JSESSIONID=<bms 값>; JSESSIONID=<root 값>; K=...; key=...; userID=...
```

장기적으로 여러 경로의 쿠키가 추가된다면 다음 키 구조를 사용하는 범용 쿠키 저장소로 교체한다.

```text
domain | path | cookie-name
```

예:

```text
niw.humetro.busan.kr|/|JSESSIONID
niw.humetro.busan.kr|/bms|JSESSIONID
```

---

## 6. 세션BG.ahk 상세 변경 방법

### 6.1 BMS 쿠키 Map 추가

기존 쿠키 Map 선언부에 다음을 추가한다.

```ahk
btcep_cookies := Map()
niw_cookies := Map()
niw_bms_cookies := Map()  ; 신규: Path=/bms 전용
ep_cookies := Map()
```

### 6.2 UpdateCookies에 저장 대상 Map을 명시적으로 전달

현재 `UpdateCookies(headers)`는 전역 `current_cookies`에 의존한다. 핸디웨어에서는 요청에 사용한 쿠키 Map과 응답 쿠키를 저장할 Map이 다를 수 있으므로 저장 대상을 인자로 받도록 확장한다.

권장 형태:

```ahk
UpdateCookies(headers, targetMap := "") {
    global current_cookies

    if !IsObject(targetMap)
        targetMap := current_cookies

    loop parse, headers, "`n", "`r" {
        if RegExMatch(A_LoopField, "i)^Set-Cookie:\s*([^=]+)=([^;]*)", &m)
            targetMap[Trim(m[1])] := m[2]
    }
}
```

주의점:

- 기존 호출은 `UpdateCookies(headers)` 형태로 계속 동작하게 유지한다.
- 핸디웨어 BMS 로그인 응답은 반드시 `UpdateCookies(headers, niw_bms_cookies)`로 저장한다.
- 정규식 값 부분은 `([^;]*)`로 하여 빈 값 쿠키도 처리한다.
- 이 최소 구현은 Path를 자동 판정하지 않는다. 호출자가 응답 종류에 따라 올바른 Map을 선택해야 한다.

### 6.3 SetHeaders가 Map 또는 완성된 Cookie 문자열을 받도록 확장

현재 함수는 Map만 받는 구조에 가깝다. `/bms` 요청에서는 루트와 BMS 쿠키를 결합한 문자열이 필요하다.

권장 인터페이스:

```ahk
SetHeaders(mode := "DEFAULT", referer := "", cookieSource := "") {
    global http

    http.SetRequestHeader("User-Agent",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        . "AppleWebKit/537.36 (KHTML, like Gecko) "
        . "Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0")

    if (referer != "")
        http.SetRequestHeader("Referer", referer)

    if (mode == "AJAX") {
        http.SetRequestHeader("X-Requested-With", "XMLHttpRequest")
        http.SetRequestHeader("Content-Type", "application/json")
    } else if (mode == "FORM") {
        http.SetRequestHeader("Content-Type", "application/x-www-form-urlencoded")
    } else if (mode == "HTML_FORM") {
        http.SetRequestHeader("Content-Type", "application/x-www-form-urlencoded")
        http.SetRequestHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
    }

    cookieStr := ""
    if IsObject(cookieSource)
        cookieStr := GetCookieString(cookieSource)
    else if (cookieSource != "")
        cookieStr := cookieSource

    if (cookieStr != "")
        http.SetRequestHeader("Cookie", cookieStr)
}
```

기존 ERP 호출과 호환되도록 `Map` 입력을 그대로 지원해야 한다.

### 6.4 BMS용 쿠키 결합 함수 추가

```ahk
GetNiwBmsCookieString() {
    global niw_cookies, niw_bms_cookies

    bms := GetCookieString(niw_bms_cookies)
    root := GetCookieString(niw_cookies)

    if (bms != "" && root != "")
        return bms "; " root
    return bms != "" ? bms : root
}
```

반드시 BMS 쿠키가 먼저 오게 한다.

### 6.5 핸디웨어 SSO HTML의 hidden input 추출 함수

`/sso/index.jsp` 응답에는 자동 제출용 폼이 들어 있다. 필요한 필드는 다음과 같다.

```text
K
GWLANG
ctms
gnbType
flagFromHome
bodyView
linkage
mainurl
CLOSEOFF
isPortal
menuType
```

AHK v2 예시:

```ahk
ExtractHiddenInputs(html) {
    values := Map()
    pos := 1

    while RegExMatch(html, 'is)<input\b[^>]*\bname="([^"]+)"[^>]*>', &m, pos) {
        tag := m[0]
        name := m[1]
        value := ""
        if RegExMatch(tag, 'is)\bvalue="([^"]*)"', &valueMatch)
            value := HtmlEntityDecode(valueMatch[1])
        values[name] := value
        pos := m.Pos + m.Len
    }
    return values
}

HtmlEntityDecode(value) {
    value := StrReplace(value, "&amp;", "&")
    value := StrReplace(value, "&quot;", Chr(34))
    value := StrReplace(value, "&#39;", "'")
    value := StrReplace(value, "&lt;", "<")
    value := StrReplace(value, "&gt;", ">")
    return value
}
```

속성 순서는 서버 변경 가능성이 있으므로 전체 input 태그를 먼저 찾고 태그 안에서 `name`과 `value`를 각각 찾는 방식이 더 안전하다. 운영 구현에서는 `name`이 `value`보다 앞에 있다는 가정도 가능하면 제거한다.

### 6.6 핸디웨어 세션 초기화 단계 삽입

삽입 위치는 NIW SSO가 준비된 뒤, 결과 JSON을 출력하기 전이다. ERP 로그인 전후 어느 쪽도 가능하지만 다음 순서를 권장한다.

```text
Step 1  btcep 로그인
Step 2  중앙 SSO 교환
Step 3  NIW 루트 세션 및 K 준비
Step H1 핸디웨어 approval SSO 폼 수신
Step H2 BMS 로그인
Step H3 frame.jsp 사용자 세션 초기화
Step 4 이후 기존 ERP 흐름 계속
```

ERP 흐름이 실패해도 핸디웨어만 사용하도록 만들 계획이라면 ERP와 핸디웨어 초기화의 오류 처리를 분리해야 한다. 현재 TotalAuto의 요구가 ERP 세션까지 모두 성공해야 준비 완료인 구조라면 우선 동일한 `try` 안에 추가해도 된다.

### H1. approval SSO 페이지 요청

현재 NIW 루트 세션이 이미 준비된 경우 다음 주소를 직접 요청할 수 있다.

```text
https://niw.humetro.busan.kr/sso/index.jsp?menuType=approval&callType=callMenu
```

브라우저에서 사용한 원래 진입 주소는 다음이다.

```text
https://btcep.humetro.busan.kr/jeon/jeonja.jsp?menuType=approval&callType=callMenu
```

원래 주소는 NIW 주소로 리다이렉트한다. 새로운 세션이나 NIW 인증이 불완전한 경우 중앙 SSO를 추가로 왕복할 수 있다.

중요:

- 자동 리다이렉트와 수동 쿠키 저장소를 섞을 때 중간 응답의 `Set-Cookie`를 잃어버릴 수 있다.
- 가능하면 각 301/302 응답의 `Location`을 수동으로 따라가며 호스트·경로별 쿠키를 적용한다.
- 기존 Step 3을 통과한 상태라면 NIW 주소 직접 요청이 단순하고 안전하다.
- 최종 응답 URL이 `/sso/index.jsp`인지 확인한다.
- 응답 HTML에 `name="K"`가 없으면 성공으로 간주하지 않는다.

개념 코드:

```ahk
approvalSsoUrl := "https://niw.humetro.busan.kr/sso/index.jsp?menuType=approval&callType=callMenu"

http.Open("GET", approvalSsoUrl, false)
http.Option[6] := false
SetHeaders("DEFAULT", "https://btcep.humetro.busan.kr/", niw_cookies)
http.Send()
UpdateCookies(http.GetAllResponseHeaders(), niw_cookies)

if (http.Status != 200)
    throw Error("핸디웨어 approval SSO 페이지 요청 실패: HTTP " http.Status)

handySsoHtml := http.ResponseText
handyInputs := ExtractHiddenInputs(handySsoHtml)
if !handyInputs.Has("K") || handyInputs["K"] = ""
    throw Error("핸디웨어 SSO 응답에서 K를 찾지 못했습니다.")

handyK := handyInputs["K"]
```

`K` 값 자체를 로그에 남기지 않는다.

### H2. BMS 세션 생성

```text
POST https://niw.humetro.busan.kr/bms/login.cmmn
Content-Type: application/x-www-form-urlencoded
Body: K=<현재 SSO에서 받은 값>
```

개념 코드:

```ahk
bmsLoginUrl := "https://niw.humetro.busan.kr/bms/login.cmmn"

http.Open("POST", bmsLoginUrl, false)
http.Option[6] := false
SetHeaders("HTML_FORM", approvalSsoUrl, niw_cookies)
http.SetRequestHeader("Origin", "https://niw.humetro.busan.kr")
http.Send("K=" EncodeURI(handyK))

UpdateCookies(http.GetAllResponseHeaders(), niw_bms_cookies)

if (http.Status != 200)
    throw Error("핸디웨어 BMS 로그인 실패: HTTP " http.Status)
if !niw_bms_cookies.Has("JSESSIONID")
    throw Error("핸디웨어 Path=/bms JSESSIONID를 받지 못했습니다.")
```

HAR에서 이 응답은 `<title>null</title>`인 짧은 HTML이다. 내용보다 `Path=/bms`용 `JSESSIONID` 획득 여부가 중요하다.

### H3. frame.jsp 사용자 세션 속성 초기화

SSO HTML 내부 주석에 따르면 `K`가 있어야 `frame.jsp`가 사용자 세션 속성을 생성한다. 이 단계는 생략하지 않는다.

```text
POST https://niw.humetro.busan.kr/jsp/main/frame.jsp
```

본문에는 H1에서 추출한 hidden input을 그대로 보낸다.

AHK v2 개념 코드:

```ahk
frameFieldNames := [
    "K", "GWLANG", "ctms", "gnbType", "flagFromHome",
    "bodyView", "linkage", "mainurl", "CLOSEOFF", "isPortal", "menuType"
]

frameBody := ""
for fieldName in frameFieldNames {
    if !handyInputs.Has(fieldName)
        continue
    pair := EncodeURI(fieldName) "=" EncodeURI(handyInputs[fieldName])
    frameBody .= (frameBody = "" ? "" : "&") pair
}

frameUrl := "https://niw.humetro.busan.kr/jsp/main/frame.jsp"
http.Open("POST", frameUrl, false)
http.Option[6] := false

; /jsp 경로에는 Path=/bms JSESSIONID를 보내면 안 된다.
SetHeaders("HTML_FORM", approvalSsoUrl, niw_cookies)
http.SetRequestHeader("Origin", "https://niw.humetro.busan.kr")
http.Send(frameBody)
UpdateCookies(http.GetAllResponseHeaders(), niw_cookies)

if (http.Status != 200)
    throw Error("핸디웨어 frame.jsp 초기화 실패: HTTP " http.Status)
```

정상적으로 다음 루트 쿠키가 추가될 수 있다.

```text
key
userID
communityID
```

이 값의 실제 내용을 로그나 JSON 디버그 출력에 기록하지 않는다.

### H4. 페이지당 50건 설정

HAR의 50건 화면 조건은 다음 UI 쿠키였다.

```ahk
niw_cookies["pageUnit"] := "50"
```

이 쿠키가 없으면 서버 기본값으로 10건만 실제 문서 행이 들어올 수 있다. HTML 표는 빈 보정 행을 포함하여 50개의 `<tr>`을 만들 수 있으므로 단순 `<tr>` 개수만 세면 안 된다.

### 6.7 결과 JSON에 niw_bms 추가

현재 결과에 다음 키를 추가한다.

```ahk
result := Map(
    "btcep", GetCookieString(btcep_cookies),
    "niw", GetCookieString(niw_cookies),
    "niw_bms", GetCookieString(niw_bms_cookies),
    "ep", GetCookieString(ep_cookies)
)
```

완료 판단 전에 다음 조건을 검사한다.

```ahk
if !niw_cookies.Has("JSESSIONID")
    throw Error("NIW 루트 JSESSIONID 없음")
if !niw_bms_cookies.Has("JSESSIONID")
    throw Error("NIW BMS JSESSIONID 없음")
if !niw_cookies.Has("K")
    throw Error("NIW K 쿠키 없음")
```

`K`가 hidden input에는 있지만 쿠키에는 없을 가능성까지 고려하려면 결과에 별도 `handy_k`를 넣기보다 H3까지 마친 뒤 서버 세션만 사용하도록 설계한다. 목록 요청 본문에는 현재 `K`가 필요하므로 런타임에서 사용할 수 있게 안전하게 저장해야 한다. 다음 두 방식 중 하나를 선택한다.

1. `niw` 쿠키 문자열에 이미 포함된 `K`를 목록 요청 시 읽음
2. 별도의 `handy_meta` 구조에 `K`를 넣되 로그·평문 진단 출력 금지

현재 HAR와 성공 시뮬레이션에서는 NIW의 `K` 쿠키와 폼의 `K`가 동일했다.

---

## 7. Main.ahk 변경 방법

`Main.ahk`의 `OnSessionBGOutput()`은 JSON을 통째로 `HeadlessAutomation.SetCookieStorage(data)`에 전달하므로 `niw_bms` 키 추가만으로 JSON 파싱 로직의 대규모 수정은 필요하지 않다.

다만 다음을 변경한다.

### 7.1 로그 문구

기존:

```ahk
LogDebug("세션BG: 쿠키 저장 완료 (btcep, niw, ep)")
```

변경:

```ahk
LogDebug("세션BG: 쿠키 저장 완료 (btcep, niw, niw_bms, ep)")
```

### 7.2 준비 완료 조건

핸디웨어 기능이 필수 기능이면 `headlessReady`를 보내기 전에 다음 키 존재를 검사한다.

```ahk
requiredKeys := ["btcep", "niw", "niw_bms", "ep"]
for key in requiredKeys {
    if !data.Has(key) || data[key] = "" {
        ; 적절한 오류 메시지 전송 후 return
    }
}
```

ERP와 핸디웨어를 독립 기능으로 운영하려면 상태를 다음처럼 분리하는 것이 더 좋다.

```text
portalReady
handyReady
erpReady
```

한 시스템의 일시 장애 때문에 다른 시스템 기능까지 사용 불가능하게 만들지 않으려면 장기적으로 이 구조를 권장한다.

---

## 8. 헤드리스.ahk 변경 방법

### 8.1 `/bms` 요청 시 쿠키 결합

현재 `_SendRequest()`는 호스트만 보고 `niw` 문자열 하나를 선택한다. 다음 분기를 추가한다.

```ahk
cookie := ""

if InStr(url, "niw.humetro.busan.kr/bms/") {
    bmsCookie := HeadlessAutomation.CookieStorage.Has("niw_bms")
        ? HeadlessAutomation.CookieStorage["niw_bms"] : ""
    rootCookie := HeadlessAutomation.CookieStorage.Has("niw")
        ? HeadlessAutomation.CookieStorage["niw"] : ""

    ; 더 구체적인 /bms 쿠키가 먼저 와야 한다.
    if (bmsCookie != "" && rootCookie != "")
        cookie := bmsCookie "; " rootCookie
    else
        cookie := bmsCookie != "" ? bmsCookie : rootCookie
} else if InStr(url, "niw.humetro.busan.kr") {
    cookie := HeadlessAutomation.CookieStorage.Has("niw")
        ? HeadlessAutomation.CookieStorage["niw"] : ""
} else if InStr(url, "btcep.humetro.busan.kr") {
    cookie := HeadlessAutomation.CookieStorage.Has("btcep")
        ? HeadlessAutomation.CookieStorage["btcep"] : ""
} else {
    cookie := HeadlessAutomation.CookieStorage.Has("ep")
        ? HeadlessAutomation.CookieStorage["ep"] : ""
}
```

`niw_bms` 문자열 안의 `JSESSIONID`가 `niw` 문자열 안의 `JSESSIONID`보다 먼저 전송되는지 실제 요청 헤더에서 검증한다. 값 자체는 로그에 출력하지 않는다.

### 8.2 CDP 쿠키 주입 경로 보존

`GetCookieParamsForCDP()`에 다음 매핑을 추가한다.

```ahk
cDomain := "ep.humetro.busan.kr"
cPath := "/"

if (domainKey == "btcep") {
    cDomain := "btcep.humetro.busan.kr"
} else if (domainKey == "niw") {
    cDomain := "niw.humetro.busan.kr"
} else if (domainKey == "niw_bms") {
    cDomain := "niw.humetro.busan.kr"
    cPath := "/bms"
}

cookieParams.Push(Map(
    "name", cName,
    "value", cValue,
    "domain", cDomain,
    "path", cPath,
    "url", "https://" cDomain cPath
))
```

현재 코드는 `url`에 `http://`를 사용한다. NIW 쿠키가 `Secure`인 경우 HTTPS URL을 사용해야 정상 주입될 수 있으므로 `https://`로 변경하는 것이 안전하다. ERP의 HTTP 전용 쿠키 동작에 영향이 없는지 별도 회귀 테스트한다.

### 8.3 HTML 요청용 메서드 분리

기존 `_SendRequest()`는 다음 헤더를 항상 사용한다.

```text
Accept: application/json, text/javascript, */*
X-Requested-With: XMLHttpRequest
```

공람 목록은 일반 HTML 폼 요청이다. 서버가 현재 이 헤더를 허용하더라도 HAR와 같은 형태로 별도 메서드를 만드는 것이 안전하다.

권장 메서드 인터페이스:

```ahk
_SendHtmlFormRequest(payload, url, referer := "")
```

권장 헤더:

```text
Content-Type: application/x-www-form-urlencoded
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Language: ko-KR,ko;q=0.9
Origin: https://niw.humetro.busan.kr
Referer: https://niw.humetro.busan.kr/bms/...
User-Agent: 기존 값 사용 가능
```

`X-Requested-With`는 보내지 않는다.

### 8.4 HTTP 상태와 HTML 상태를 모두 검사

핸디웨어는 만료된 세션에도 HTTP 200을 반환한다. 다음 검사를 반드시 수행한다.

```ahk
EnsureHandyHtmlSuccess(html, status) {
    if (status != 200)
        throw Error("핸디웨어 HTTP 오류: " status)

    if RegExMatch(html, 'is)<title[^>]*>\s*세션\s*에러\s*</title>')
        throw Error("HANDY_SESSION_EXPIRED")

    if InStr(html, "retrieveCnrsComptDocList.act") = 0
        throw Error("공람완료 목록 HTML 형식이 예상과 다릅니다.")
}
```

`HANDY_SESSION_EXPIRED` 발생 시 기존 세션BG 재실행 경로와 연결한다. 단순 재요청만 반복하면 같은 만료 세션으로 계속 실패하므로 반드시 새 SSO/BMS 세션을 생성해야 한다.

---

## 9. 사용자·부서·폴더 정보의 동적 추출

### 9.1 HAR 값을 하드코딩하면 안 되는 이유

다음 값은 사용자, 부서 또는 현재 세션에 종속될 수 있다.

```text
userId
deptId
userDeptId
saveDeptId
K
fldrId
RETURNURLPARAM
_NOARG
```

HAR의 값을 그대로 코드에 넣으면 다음 상황에서 실패할 수 있다.

- 다른 사용자가 로그인함
- 사용자의 현재 부서가 바뀜
- 서버의 폴더 ID가 변경됨
- 세션의 `K`가 갱신됨
- 서버가 오래된 `_NOARG` 또는 반환 파라미터를 거부함

### 9.2 권장 동적 탐색 순서

### 1단계: 메뉴 페이지 요청

```text
GET /jsp/main/menu.jsp?K=<현재 K>&menuType=approval&flagFromHome=
```

이 요청은 NIW 루트 쿠키를 사용한다.

응답 스크립트에서 다음 결재 프레임 호출을 찾는다.

```text
/cz/cb/viw/retrieveApprFrame.act
```

HAR에서는 `gpLoad2('/cz/cb/viw/retrieveApprFrame.act','MENU_HOMS_SBOX')` 형태였다. 실제 URL에 필요한 `DEPTID`, `USERDEPTID`, `USU`, `EFKEY`, `K` 등은 관련 스크립트 또는 생성된 요청에서 얻는다.

### 2단계: 결재 프레임 요청

```text
GET /bms/cz/cb/viw/retrieveApprFrame.act?...현재 사용자 파라미터...
```

이 요청부터 `/bms` 쿠키와 루트 쿠키를 결합해 사용한다.

응답은 frameset이며 다음 주소를 포함한다.

```text
/bms/com/hs/gwweb/appr/retrieveFldrPrivate.act
```

이 URL의 쿼리에서 다음 값을 확보한다.

```text
USU
K
DEPTID
USERDEPTID
SUSINADMIN
SIMSAJA
DOCADMIN
```

### 3단계: 개인 결재 폴더 페이지 및 트리 요청

`retrieveFldrPrivate.act` 응답에서 폴더 트리 요청에 필요한 폼/스크립트 값을 추출한 뒤 다음 요청을 보낸다.

```text
POST /bms/com/hs/gwweb/folder/retrieveFldrPrivateTree.act
```

주요 입력:

```text
userId
deptId
userDeptId
exids
K
actFldr=0
auditorFlag=
fMode=appr
cacheType=1
_NOARG=<현재 epoch milliseconds>
RETURNURLPARAM=<현재 값으로 재생성>
```

### 4단계: 공람완료 노드 추출

트리 응답은 다음과 비슷한 JavaScript를 포함한다.

```javascript
new WebFXTreeItem(
    "공람완료",
    "<fldrId>",
    "<fldrId>,1,3010,2,공람완료,<parentId>",
    "javascript:showSancSbox(event);",
    true
)
```

따라서 다음 정보를 동적으로 추출할 수 있다.

```text
폴더명 = 공람완료
fldrId = 두 번째 인자
APPLID = 3010
applType = 2
```

AHK v2 정규식 예시:

```ahk
pattern := 'is)new\s+WebFXTreeItem\(\s*"공람완료"\s*,\s*"([^"]+)"\s*,\s*"([^"]+)"'
if !RegExMatch(treeHtml, pattern, &m)
    throw Error("공람완료 폴더를 찾지 못했습니다.")

fldrId := m[1]
nodeData := m[2]
nodeParts := StrSplit(nodeData, ",")
if (nodeParts.Length < 4 || nodeParts[3] != "3010")
    throw Error("공람완료 폴더 메타데이터가 예상과 다릅니다.")
```

공람대기는 같은 방식으로 이름 `공람대기`, APPLID `3020`을 사용한다.

---

## 10. 공람완료 목록 요청 본문 구성

정상 요청의 주요 필드는 다음과 같다.

```text
fldrName=<UTF-8 URL 인코딩된 공람완료>
deptId=<현재 부서 ID>
userId=<현재 사용자 ID>
userDeptId=<현재 사용자 부서 ID>
saveDeptId=<현재 저장 부서 ID>
APPLID=3010
applId=3010
applType=2
fldrId=<폴더 트리에서 추출>
customFolder=false
K=<현재 K>
_NOARG=<현재 epoch milliseconds>
RETURNURLPARAM=<동일 값으로 구성한 중첩 반환 파라미터>
```

`fldrName`의 외부 값은 일반 UTF-8 URL 인코딩을 사용한다.

```text
공람완료 → %EA%B3%B5%EB%9E%8C%EC%99%84%EB%A3%8C
```

`RETURNURLPARAM` 내부에서 기존 웹 코드가 JavaScript `escape()` 형식인 `%uXXXX`를 사용할 수 있다.

```text
공람완료 → %uACF5%uB78C%uC644%uB8CC
```

검증된 HAR에서는 `RETURNURLPARAM`을 URL 디코딩하면 다음 구조였다.

```text
fldrName=%uACF5%uB78C%uC644%uB8CC
&deptId=<현재 값>
&userId=<현재 값>
&userDeptId=<현재 값>
&saveDeptId=<현재 값>
&APPLID=3010
&applId=3010
&applType=2
&fldrId=<현재 폴더 ID>
&customFolder=false
&K=<현재 K>
&_NOARG=<현재 값>
```

운영 구현 순서:

1. 현재 값으로 위 중첩 문자열을 만든다.
2. 중첩 문자열 전체를 다시 form URL 인코딩한다.
3. 결과를 외부 `RETURNURLPARAM` 값으로 넣는다.

HAR의 완성 문자열을 복사해 놓고 일부 값만 치환하는 방식은 사용하지 않는다.

### 10.1 `_NOARG` 생성

서버가 사용한 값은 epoch milliseconds 형태였다.

기존 TotalAuto에도 유사한 코드가 있다.

```ahk
noArg := DateDiff(A_NowUTC, "19700101000000", "Seconds") * 1000
```

밀리초 하위 자릿수가 반드시 필요하지는 않았지만, 같은 밀리초에 여러 요청을 보내는 경우 `A_TickCount`의 하위 값을 더하는 방식을 고려할 수 있다.

### 10.2 본문 조립 시 주의사항

- 사용자 입력과 동적 값은 모두 form URL 인코딩한다.
- 이미 인코딩된 `fldrName`을 다시 인코딩해 `%25EA...`로 만들지 않는다.
- `RETURNURLPARAM`은 중첩 문자열 전체를 한 번 인코딩한다.
- `K`, 부서 ID, 사용자 ID를 로그에 출력하지 않는다.
- 요청 헤더의 `Content-Length`는 WinHTTP가 계산하도록 직접 설정하지 않는다.

---

## 11. 목록 HTML 파싱 방법

### 11.1 단순 tr 개수는 문서 개수가 아님

핸디웨어 표는 페이지 레이아웃을 유지하기 위해 빈 보정 행을 만든다.

- 공람대기 문서 0개인 HAR 응답도 문서 영역에 50개의 `<tr>`이 있었음
- 하지만 해당 행에는 실제 문서 링크가 없었음
- 공람완료 50개 응답은 50개 행 모두 문서 링크를 포함했음

따라서 다음처럼 판별한다.

1. 문서 목록에 해당하는 두 번째 `<tbody>`를 찾음
2. 그 안의 각 `<tr>`을 분리
3. `<a ...>` 또는 문서 열람 JavaScript를 포함한 행만 실제 문서 행으로 인정

### 11.2 권장 파싱 절차

```text
HTML 정상 여부 검사
  → tbody 목록 추출
  → 두 번째 tbody 선택
  → tr 반복
  → 링크가 있는 행만 채택
  → td 셀 텍스트 및 링크 인자 추출
```

HTML 파서 라이브러리가 없다면 정규식을 사용할 수 있지만, 반드시 범위를 `<tbody>`와 `<tr>` 단위로 제한한다. 전체 HTML에서 `<td>`를 한 번에 찾으면 검색 폼과 도움말 표가 섞인다.

개념 코드:

```ahk
ExtractHandyDocumentRows(html) {
    EnsureHandyHtmlSuccess(html, 200)

    tbodies := []
    pos := 1
    while RegExMatch(html, 'is)<tbody\b[^>]*>(.*?)</tbody>', &m, pos) {
        tbodies.Push(m[1])
        pos := m.Pos + m.Len
    }

    if (tbodies.Length < 2)
        throw Error("문서 목록 tbody를 찾지 못했습니다.")

    rows := []
    body := tbodies[2]
    pos := 1
    while RegExMatch(body, 'is)<tr\b[^>]*>(.*?)</tr>', &m, pos) {
        rowHtml := m[1]
        pos := m.Pos + m.Len

        if !RegExMatch(rowHtml, 'is)<a\b')
            continue

        rows.Push(ParseHandyDocumentRow(rowHtml))
    }
    return rows
}
```

`ParseHandyDocumentRow()`에서는 `<td>`별 텍스트, HTML entity, 중첩 태그를 정리한다.

### 11.3 확인 가능한 열

HAR 응답에서 확인된 공람완료 표의 주요 열은 다음과 같다.

```text
제목
기안자
기안일자
공람지정자
결재경로
문서번호
기안부서
공개여부(시민)
상태
문서종류
원기안자
기안일시
최종결재자
공람일시
결재암호
```

일부 열은 화면에서 숨겨져 있거나 행별 구조가 다를 수 있으므로 헤더 순번만 절대적으로 믿지 말고 HAR 및 실제 HTML로 다시 확인한다.

### 11.4 문서 열람 링크

각 문서 행에는 문서 식별자 또는 열람 JavaScript 인자가 포함된다. 목록 추출 단계에서는 링크를 문자열로 보존하되 문서를 실제로 열지 않는다.

목록 조회와 문서 열람은 별도 기능으로 분리한다. 문서 열람 요청은 서버에서 공람 상태를 변경할 가능성이 있으므로 사용자가 명시적으로 요청한 경우에만 구현·호출한다.

### 11.5 핸디그룹웨어 클라이언트로 문서 열기

2026-07-30에 문서 한 건을 실제로 연 HAR에서 브라우저용 문서 URL을 직접 여는 방식이 아니라 다음 공식 흐름을 확인했다.

```text
선택 행의 docinfo 및 doCallClientApp 인자 추출
→ POST /bms/com/hs/gwweb/appr/hstCmdEx.act
→ JSON 응답의 ok=true 확인
→ clientURL 추출
→ xsclient8:// 전용 프로토콜 실행
→ 핸디그룹웨어 클라이언트에서 문서 열기
```

`hstCmdEx.act`에는 현재 사용자·부서·K와 선택 행의 `APPRID`, `WORDTYPE`, `APPRSTATUS`, `APPRTYPE`, `MENUMASK`, `DOCATTR`, `EXTERNALDOCF`, `DRAFTSRC`, `ORGAPPRID` 등을 form body로 전송한다. 이 값은 HAR에서 고정하지 않고 현재 목록 행의 `docinfo` 값과 현재 세션 메타데이터에서 추출한다.

응답의 `clientURL`은 인증·문서 실행정보를 포함할 수 있으므로 로그에 기록하지 않는다. 실행 전 스킴이 정확히 `xsclient8://`인지 검사하고 다른 프로토콜은 차단한다. 공람대기 문서는 열람으로 상태가 변경될 수 있으므로 사용자 확인을 받은 뒤 호출한다.

---

## 12. 세션 만료 및 재로그인 처리

### 12.1 만료 응답 특성

저장된 HAR 쿠키를 재사용했을 때 서버는 다음처럼 응답했다.

```text
HTTP status: 200
HTML title: 세션 에러
문서 행: 0
```

따라서 HTTP 200만으로 성공을 판단하면 안 된다.

### 12.2 재로그인 정책

권장 흐름:

```text
목록 요청
  ├─ 정상 HTML → 파싱
  ├─ 세션 에러 → 세션BG 재실행 요청
  │                 → 새 niw + niw_bms 쿠키 저장
  │                 → 목록 요청 1회 재시도
  └─ 기타 HTML 오류 → 즉시 오류 보고
```

무한 재시도를 방지한다.

- 자동 세션 재생성: 최대 1회
- 재생성 후에도 실패: 사용자에게 오류 표시
- 동일 세션으로 반복 재요청 금지

### 12.3 유지 타이머

기존 ERP 새로고침 타이머가 NIW BMS 세션을 연장해 준다는 보장은 없다. 핸디웨어 세션 유지가 필요하면 상태 변경이 없는 다음 요청 중 하나를 별도 주기로 사용할 수 있다.

- 공람 폴더 개수 조회
- 메뉴 또는 폴더 프레임 조회

그러나 불필요한 서버 부하를 피하기 위해 우선 만료 시 재로그인 방식으로 구현하고, 실제 만료 시간이 짧아 사용성이 떨어질 때만 keep-alive를 추가한다.

### 12.4 프로그램 실행 중 세션 재활용

`totalauto_session_exam.ahk`에서 확인한 것처럼 HTTP 자동 로그인 때 생성한 세션 객체를 조회가 끝난 뒤 폐기하면 후속 조회마다 포털 로그인이 반복된다. 이는 불필요한 인증 요청뿐 아니라 중복 로그인 경고를 유발할 수 있다.

따라서 프로그램이 실행 중인 동안에는 인증된 HTTP 세션과 쿠키 저장소를 메모리에 유지하고 다음 순서로 재사용한다.

```text
기능 요청
  → 메모리에 보관한 HTTP 세션으로 먼저 요청
  → 정상 응답이면 같은 세션을 계속 사용
  → 세션 만료가 명확히 확인된 경우에만 보관 세션 폐기
  → 새 로그인 및 세션 초기화는 최대 1회
  → 원래 기능 요청 1회 재시도
```

적용 원칙:

- XPlatform 조회와 핸디웨어 조회가 같은 포털 로그인 세션을 공유한다.
- MIS 초기화가 끝난 `JSESSIONID`와 NIW 루트·`/bms` 쿠키를 동일한 세션 객체에 보관한다.
- `/bms` 요청에서는 경로가 더 구체적인 `/bms` 쿠키를 루트 쿠키보다 먼저 전송한다.
- 기능 조회가 성공했다고 세션 객체를 지역 변수와 함께 폐기하지 않는다.
- 단순 네트워크 오류를 곧바로 세션 만료로 간주하지 않는다.
- XPlatform의 세션 오류 코드 또는 핸디웨어의 `세션 에러` HTML처럼 만료가 확인된 경우에만 재로그인한다.
- 프로그램 종료 시 메모리 세션은 함께 폐기하며 쿠키를 디버그 로그에 기록하지 않는다.

독립형 조회기의 참고 구조:

```ahk
global activeHttpSession := 0

if IsObject(activeHttpSession) {
    ; 보유 세션으로 기능 요청
} else {
    activeHttpSession := CreateAuthenticatedSession()
}
```

TotalAuto에 적용할 때도 `HeadlessAutomation.CookieStorage`를 매 요청마다 초기화하지 않고 로그인·로그아웃·명시적 만료 시점에만 교체하는 방식으로 동일한 원칙을 적용한다.

프로그램 종료 후에도 세션을 재사용해야 한다면 쿠키를 평문으로 저장하지 않는다. Windows 환경에서는 DPAPI로 세션 전체를 현재 Windows 사용자에게 묶어 암호화하고, 다음 실행 시 저장된 사번과 GUI의 사번이 일치하는 경우에만 복원한다. 다른 사번으로 로그인할 때는 기존 파일을 먼저 지우지 않고 새 로그인이 성공한 뒤 원자적으로 덮어써야 로그인 실패로 유효한 기존 세션까지 잃는 상황을 피할 수 있다.

---

## 13. 보안 및 로그 규칙

다음 값은 인증정보이므로 절대 로그에 원문을 남기지 않는다.

```text
K
key
JSESSIONID
MYSAPSSO2
userID 쿠키
communityID 쿠키
1차 비밀번호
2차 비밀번호
문서 제목 및 문서번호가 포함된 원문 HTML
```

허용되는 진단 로그 예:

```text
NIW 루트 JSESSIONID 획득: 성공
BMS JSESSIONID 획득: 성공
frame.jsp 초기화: HTTP 200
공람완료 목록: 전체 렌더링 50행 / 실제 문서 50행
```

금지되는 로그 예:

```text
K값 획득 성공: <K 원문>
Cookie: JSESSIONID=...
응답 HTML 전체 출력
```

현재 `세션BG.ahk`에는 일부 동적 인증값을 로그에 기록하는 기존 코드가 있으므로 핸디웨어 적용 시 해당 부분도 함께 정리하는 것이 바람직하다.

`.saved_cookies.json`에는 실제 인증 세션이 평문으로 저장된다. 최소한 다음을 지킨다.

- 프로그램 전용 디렉터리에 저장
- 일반 사용자 이외 계정의 읽기 권한 제한 검토
- 로그나 오류 보고서에 파일 첨부 금지
- 로그아웃 또는 계정 변경 시 삭제/교체

---

## 14. 단계별 구현 순서

다른 AI 또는 개발자는 다음 순서를 지켜 수정한다.

### 1단계: 쿠키 구조만 변경

- `niw_bms_cookies` 추가
- `UpdateCookies()` 저장 대상 인자 추가
- `SetHeaders()`가 쿠키 문자열을 받을 수 있도록 변경
- 결과 JSON에 `niw_bms` 추가
- 기존 ERP 로그인이 그대로 되는지 테스트

이 단계에서 공람 조회는 아직 구현하지 않는다.

### 2단계: 핸디웨어 세션 초기화 추가

- approval SSO 페이지 요청
- hidden input 추출
- `/bms/login.cmmn`
- `/jsp/main/frame.jsp`
- `pageUnit=50`
- 루트 및 BMS `JSESSIONID` 동시 존재 검증
- ERP 로그인 회귀 테스트

### 3단계: Main/Headless 저장 구조 확장

- `niw_bms` 수신 및 저장
- `/bms` 요청의 쿠키 결합
- CDP 쿠키 경로 보존
- 저장/재로딩 후 `niw_bms`가 유지되는지 확인

### 4단계: 공람 폴더 메타데이터 동적 추출

- 메뉴 페이지 요청
- 결재 프레임 URL 추출
- 개인 폴더 프레임 요청
- 폴더 트리 요청
- `공람완료` 노드의 `fldrId`, `APPLID`, `applType` 추출
- HAR 고정값 없이 동작하는지 확인

### 5단계: 공람완료 목록 조회 및 파싱

- 현재 값으로 form body 생성
- HTML 폼 요청 전송
- 세션 오류 검사
- 실제 링크가 있는 문서 행만 추출
- 0건, 10건, 50건 상태 구분

### 6단계: 세션 갱신 연결

- `HANDY_SESSION_EXPIRED` 오류 정의
- Main에서 세션BG 재실행
- 성공 후 요청 1회 재시도
- 반복 실패 시 사용자에게 명확한 오류 표시

---

## 15. 테스트 시나리오

### 15.1 기존 기능 회귀 테스트

- 통합포털 로그인 성공
- MIS 관련 기존 기능이 있다면 정상 동작
- ERP `MYSAPSSO2` 획득 성공
- 업무일지/근태/기존 HTTP 요청 정상
- CDP 브라우저 실행 경로가 필요한 기존 기능 정상

### 15.2 핸디웨어 세션 테스트

- approval SSO 최종 URL이 `/sso/index.jsp`
- hidden input에서 `K` 추출
- `/bms/login.cmmn` HTTP 200
- `/bms`용 `JSESSIONID` 존재
- 루트용 `JSESSIONID`도 별도로 존재
- `/jsp/main/frame.jsp` HTTP 200
- `userID`, `communityID` 쿠키 존재 여부 기록은 이름만 확인

### 15.3 목록 테스트

- `pageUnit=50` 상태에서 공람완료 실제 문서 행 50개
- `pageUnit`이 없을 때 기본 실제 행 수와 차이를 확인
- 공람대기 0건일 때 빈 보정 행을 문서로 오인하지 않음
- 잘못된/만료된 쿠키로 HTTP 200 `세션 에러` 감지
- BMS 쿠키를 제외하면 실패하는지 확인
- 루트 쿠키를 제외하면 초기화 또는 목록이 실패하는지 확인

마지막 두 최소 쿠키 실험은 운영 서버에 불필요한 요청을 반복하지 않도록 각 1회만 수행한다.

### 15.4 사용자 변경 테스트

가능하다면 별도 테스트 계정 또는 부서가 다른 계정으로 다음을 확인한다.

- HAR의 사용자/부서 ID를 사용하지 않음
- 메뉴와 프레임에서 현재 사용자 정보 추출
- 폴더 트리에서 현재 공람완료 폴더를 찾음
- 문서 목록이 현재 사용자 기준으로 반환됨

---

## 16. 완료 조건

다음 조건을 모두 만족해야 구현 완료로 판단한다.

- 브라우저, Selenium, Chrome.ahk 없이 공람완료 목록 조회 가능
- `niw` 루트와 `/bms`의 두 `JSESSIONID`를 덮어쓰지 않고 보존
- 세션BG 결과에 `niw_bms` 포함
- Main 저장 및 재로딩 후에도 `niw_bms` 유지
- `/bms` 요청에서 BMS 쿠키가 루트 쿠키보다 먼저 전송
- HAR의 `userId`, `deptId`, `fldrId`, `K`, `_NOARG`를 하드코딩하지 않음
- `pageUnit=50`일 때 실제 문서 행 50개 추출
- 공람대기 0건을 정확히 0건으로 판별
- HTTP 200 세션 오류를 성공으로 오인하지 않음
- 세션 만료 시 새 세션 생성 후 최대 한 번 재시도
- 기존 ERP 및 TotalAuto 기능 회귀 없음
- 로그에 쿠키, K, 비밀번호, 문서 원문을 남기지 않음

---

## 17. 구현 시 사용하면 안 되는 지름길

다음 방식은 초기 테스트에서는 동작할 수 있지만 운영 코드에는 사용하지 않는다.

1. HAR의 `Cookie` 헤더 전체를 복사해 고정
2. HAR의 `K`, 사용자 ID, 부서 ID를 고정
3. HAR의 `fldrId`를 유일한 값이라고 가정
4. 루트와 `/bms` `JSESSIONID` 중 하나만 보존
5. `/bms/login.cmmn` 또는 `frame.jsp` 생략
6. HTTP 200만 보고 로그인 성공 처리
7. 전체 `<tr>` 개수를 문서 개수로 사용
8. 만료 세션으로 무한 재시도
9. 디버그 로그에 전체 쿠키나 응답 HTML 출력
10. 핸디웨어 기능 추가 과정에서 ERP의 기존 `MYSAPSSO2` 흐름 제거

---

## 18. 권장 최종 구조

```text
세션BG.exe
  ├─ PortalLogin()
  ├─ PrepareNiwRootSession()
  ├─ PrepareHandyBmsSession()
  │    ├─ RequestApprovalSsoForm()
  │    ├─ PostBmsLogin()
  │    └─ PostHandyFrameInit()
  ├─ PrepareErpSession()
  └─ OutputCookieJson()
       ├─ btcep
       ├─ niw
       ├─ niw_bms
       └─ ep

Main.ahk
  ├─ ReceiveSessionJson()
  ├─ HeadlessAutomation.SetCookieStorage()
  └─ 세션 만료 시 세션BG 재실행

HeadlessAutomation
  ├─ BuildCookieHeaderForUrl()
  │    ├─ 일반 NIW → niw
  │    └─ /bms → niw_bms + niw
  ├─ DiscoverHandyFolderMetadata()
  ├─ RequestCompletedCirculationList()
  ├─ ValidateHandyHtml()
  └─ ParseHandyDocumentRows()
```

세션 생성, 폴더 메타데이터 탐색, 목록 요청, HTML 파싱을 각각 분리하면 서버 화면 구조가 일부 변경되어도 수정 범위를 작게 유지할 수 있다.

---

## 19. 참고: 검증 스크립트의 역할과 한계

`handy_http_simulation.ps1`은 다음을 증명한다.

- 통합포털 계정으로 HTTP 로그인 가능
- 핸디웨어 approval SSO를 HTTP로 통과 가능
- 루트와 `/bms` JSESSIONID를 경로별로 보존하면 정상 동작
- `/bms/login.cmmn`과 `frame.jsp` 초기화가 HTTP로 가능
- 공람완료 목록 응답에서 실제 50개 문서 행을 판별 가능

하지만 다음 부분은 운영 구현에서 교체해야 한다.

- HAR 463번 요청의 본문을 기준으로 사용한 부분
- 같은 사용자라는 가정 아래 남아 있는 사용자·부서 값
- PowerShell `CookieContainer`가 자동 처리한 도메인·경로 쿠키 관리

TotalAuto의 AHK 구현은 이 문서의 동적 파라미터 추출과 경로별 쿠키 저장 방법을 사용해야 한다.
