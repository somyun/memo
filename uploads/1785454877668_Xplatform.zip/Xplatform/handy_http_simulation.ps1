﻿$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$basePath = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }

function Encode-FormValue([string] $Value) {
    return [Uri]::EscapeDataString($Value)
}

function Read-SecretValues {
    $path = if (Test-Path -LiteralPath "$basePath\secret.txt") {
        "$basePath\secret.txt"
    } else {
        "$basePath\secret.txt.txt"
    }

    $values = @{}
    foreach ($line in Get-Content -LiteralPath $path -Encoding UTF8) {
        $separator = $line.IndexOf(':')
        if ($separator -gt 0) {
            $values[$line.Substring(0, $separator).Trim()] = $line.Substring($separator + 1).Trim()
        }
    }
    foreach ($key in @('사번', '1차비번', '2차비번')) {
        if (-not $values[$key]) {
            throw "secret.txt에 '${key}: 값'이 필요합니다."
        }
    }
    return $values
}

function Invoke-FormPost($Session, [string] $Uri, [string] $Body, [string] $Referer) {
    return Invoke-WebRequest -UseBasicParsing -WebSession $Session -Method Post -Uri $Uri `
        -Headers @{ Referer = $Referer; Origin = 'https://niw.humetro.busan.kr' } `
        -ContentType 'application/x-www-form-urlencoded' -Body $Body -TimeoutSec 30
}

function Get-HiddenInputs([string] $Html) {
    $inputs = @{}
    foreach ($match in [regex]::Matches($Html, '(?is)<input\b[^>]*\bname="([^"]+)"[^>]*>')) {
        $tag = $match.Value
        $name = $match.Groups[1].Value
        $value = if ($tag -match '\bvalue="([^"]*)"') { $matches[1] } else { '' }
        $inputs[$name] = [Net.WebUtility]::HtmlDecode($value)
    }
    return $inputs
}

function Get-ListMetrics([string] $Html) {
    $title = if ($Html -match '(?is)<title[^>]*>(.*?)</title>') {
        ([regex]::Replace($matches[1], '<[^>]+>', ' ') -replace '\s+', ' ').Trim()
    } else { '' }

    $tbodies = [regex]::Matches($Html, '(?is)<tbody\b[^>]*>(.*?)</tbody>')
    $bodyRows = 0
    $documentRows = 0
    $bodyLinks = 0
    if ($tbodies.Count -ge 2) {
        $rows = [regex]::Matches($tbodies[1].Groups[1].Value, '(?is)<tr\b[^>]*>(.*?)</tr>')
        $bodyRows = $rows.Count
        foreach ($row in $rows) {
            $linkCount = [regex]::Matches($row.Groups[1].Value, '(?i)<a\b').Count
            $bodyLinks += $linkCount
            if ($linkCount -gt 0) { $documentRows++ }
        }
    }

    return [pscustomobject]@{
        Title = $title
        SessionError = $Html -match '(?is)<title[^>]*>\s*세션\s*에러\s*</title>'
        BodyRows = $bodyRows
        DocumentRows = $documentRows
        BodyLinks = $bodyLinks
        UserInfoCalls = [regex]::Matches($Html, '(?i)showUserInfo\s*\(').Count
    }
}

$secret = Read-SecretValues
$userId = $secret['사번']
$password1 = $secret['1차비번']
$password2 = $secret['2차비번']

$session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$session.UserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
    '(KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0'

$loginPage = 'https://btcep.humetro.busan.kr/user/login.face?destination=%2Fportal%2F'
$null = Invoke-WebRequest -UseBasicParsing -WebSession $session -Uri $loginPage -TimeoutSec 30
$ajaxHeaders = @{ 'X-Requested-With' = 'XMLHttpRequest'; Referer = $loginPage }

$firstJson = @{ userId = $userId; pwd = $password1 } | ConvertTo-Json -Compress
$null = Invoke-WebRequest -UseBasicParsing -WebSession $session -Method Post `
    -Uri 'https://btcep.humetro.busan.kr/user/checkUser.face' -Headers $ajaxHeaders `
    -ContentType 'application/json;charset=UTF-8' -Body ([Text.Encoding]::UTF8.GetBytes($firstJson))
$null = Invoke-WebRequest -UseBasicParsing -WebSession $session -Method Post `
    -Uri 'https://btcep.humetro.busan.kr/user/checkLogin.face' -Headers $ajaxHeaders `
    -ContentType 'application/json;charset=UTF-8' -Body ([Text.Encoding]::UTF8.GetBytes($firstJson))

$secondJson = @{ userId = $userId; secondpwd = $password2 } | ConvertTo-Json -Compress
$null = Invoke-WebRequest -UseBasicParsing -WebSession $session -Method Post `
    -Uri 'https://btcep.humetro.busan.kr/user/secondLoginYn.face' -Headers $ajaxHeaders `
    -ContentType 'application/json;charset=UTF-8' -Body ([Text.Encoding]::UTF8.GetBytes($secondJson))
$null = Invoke-WebRequest -UseBasicParsing -WebSession $session -Method Post `
    -Uri 'https://btcep.humetro.busan.kr/user/failReset.face' -Headers $ajaxHeaders `
    -ContentType 'application/json;charset=UTF-8' -Body ([Text.Encoding]::UTF8.GetBytes($secondJson))

$loginForm = 'username=' + (Encode-FormValue $userId) +
    '&userId=' + (Encode-FormValue $userId) +
    '&password=' + (Encode-FormValue $password1)
$portal = Invoke-WebRequest -UseBasicParsing -WebSession $session -Method Post `
    -Uri 'https://btcep.humetro.busan.kr/user/loginProcess.face?destination=%2Fportal%2F' `
    -Headers @{ Referer = $loginPage; Origin = 'https://btcep.humetro.busan.kr' } `
    -ContentType 'application/x-www-form-urlencoded' -Body $loginForm -MaximumRedirection 12 -TimeoutSec 30

$secret.Clear()
$password1 = ''
$password2 = ''
$firstJson = ''
$secondJson = ''
$loginForm = ''

$handyEntry = 'https://btcep.humetro.busan.kr/jeon/jeonja.jsp?menuType=approval&callType=callMenu'
$ssoPage = Invoke-WebRequest -UseBasicParsing -WebSession $session -Uri $handyEntry `
    -Headers @{ Referer = 'https://btcep.humetro.busan.kr/portal/default/main/groupware/gwapproval.page' } `
    -MaximumRedirection 20 -TimeoutSec 30
$inputs = Get-HiddenInputs ([string] $ssoPage.Content)
if (-not $inputs['K']) { throw '핸디웨어 SSO 응답에서 K 값을 찾지 못했습니다.' }
$kValue = [string] $inputs['K']

$bmsLogin = Invoke-FormPost $session 'https://niw.humetro.busan.kr/bms/login.cmmn' `
    ('K=' + (Encode-FormValue $kValue)) $ssoPage.BaseResponse.ResponseUri.AbsoluteUri

$frameNames = @('K', 'GWLANG', 'ctms', 'gnbType', 'flagFromHome', 'bodyView', 'linkage',
    'mainurl', 'CLOSEOFF', 'isPortal', 'menuType')
$framePairs = foreach ($name in $frameNames) {
    if ($inputs.ContainsKey($name)) {
        (Encode-FormValue $name) + '=' + (Encode-FormValue ([string] $inputs[$name]))
    }
}
$frame = Invoke-FormPost $session 'https://niw.humetro.busan.kr/jsp/main/frame.jsp' `
    ($framePairs -join '&') $ssoPage.BaseResponse.ResponseUri.AbsoluteUri

# HAR 당시와 같은 한 페이지 50건 표시 조건이다. 인증 토큰이 아니라 UI 환경 쿠키다.
$session.Cookies.Add((New-Object Net.Cookie('pageUnit', '50', '/', 'niw.humetro.busan.kr')))

$harPath = "$basePath\btcep.humetro.busan.kr_handy.har"
$har = Get-Content -LiteralPath $harPath -Raw -Encoding UTF8 | ConvertFrom-Json
$capturedRequest = $har.log.entries[462]
$listBody = [string] $capturedRequest.request.postData.text
$oldK = ([regex]::Match($listBody, '(?:^|&)K=([^&]+)')).Groups[1].Value
$listBody = $listBody.Replace($oldK, (Encode-FormValue $kValue))
$listBody = [regex]::Replace($listBody, '(?<=_NOARG=)\d+', [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())

$listResponse = Invoke-FormPost $session `
    'https://niw.humetro.busan.kr/bms/com/hs/gwweb/appr/retrieveCnrsComptDocList.act' `
    $listBody 'https://niw.humetro.busan.kr/bms/cz/cb/viw/retrieveApprFrame.act'
$metrics = Get-ListMetrics ([string] $listResponse.Content)

$niwCookies = @($session.Cookies.GetCookies([Uri] 'https://niw.humetro.busan.kr/bms/'))
$jSessionCount = @($niwCookies | Where-Object Name -eq 'JSESSIONID').Count

[pscustomobject]@{
    PortalFinalHost = $portal.BaseResponse.ResponseUri.Host
    HandySsoFinalPath = $ssoPage.BaseResponse.ResponseUri.AbsolutePath
    BmsLoginStatus = $bmsLogin.StatusCode
    FrameStatus = $frame.StatusCode
    NiwJSessionIdCount = $jSessionCount
    ListStatus = $listResponse.StatusCode
    SessionError = $metrics.SessionError
    RenderedBodyRows = $metrics.BodyRows
    ExtractableDocumentRows = $metrics.DocumentRows
    DocumentAreaLinks = $metrics.BodyLinks
    UserInfoCallCount = $metrics.UserInfoCalls
} | Format-List

$userId = ''
$kValue = ''
$listBody = ''
