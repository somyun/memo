#Requires AutoHotkey v2.0
#SingleInstance Force

SetWorkingDir(A_ScriptDir)

global BASE_PORTAL := "https://btcep.humetro.busan.kr"
global BASE_MIS := "https://mis.humetro.busan.kr/FS"
global XP_NAMESPACE := "http://www.tobesoft.com/platform/Dataset"
global DEBUG_LOG := A_ScriptDir "\LA10100_debug.log"
global SESSION_FILE := A_ScriptDir "\LA10100_session.dat"
; 자동 로그인으로 만든 세션을 프로그램이 종료될 때까지 재사용한다.
global activeHttpSession := 0
global handyDocumentRows := Map()
global handyAllRows := []
global currentHandyKind := ""
global handyDocumentSequence := 0
global suppressHandyFilterEvents := false
global suppressHandyDateFormatting := false
global handyDateFiltersAutoManaged := true
global handyImeComposition := Map()
global lastHandyTextFilterSignature := ""
global handyEditSubclassProc := 0
global handyEditOriginalWndProcs := Map()
global handyStatusItems := []
global handyDocumentTypeItems := []
global handySelectedStatuses := Map()
global handySelectedDocumentTypes := Map()
global handyStatusPopup := 0
global handyDocumentTypePopup := 0
global openHandyChoicePopupKind := ""

global appGui := Gui(, "부산교통공사 업무 조회")
appGui.SetFont("s10", "Malgun Gothic")

global loginGroup := appGui.AddGroupBox("xm ym w1170 h70", "로그인 - 로그인하지 않음")
appGui.AddText("x22 y35 w55", "사번")
global employeeEdit := appGui.AddEdit("x80 y31 w180")
appGui.AddText("x280 y35 w65", "1차 비번")
global password1Edit := appGui.AddEdit("x350 y31 w190 Password")
appGui.AddText("x560 y35 w65", "2차 비번")
global password2Edit := appGui.AddEdit("x630 y31 w190 Password")
global loginButton := appGui.AddButton("x835 y27 w100 h30 Default", "로그인")
global saveSecretsButton := appGui.AddButton("x945 y27 w110 h30", "계정 저장")

global mainTabs := appGui.AddTab3("xm y130 w1170 h475", ["XPlatform 조회", "공람 문서"])

mainTabs.UseTab(1)
appGui.AddText("x30 y175 w90", "운전자 이름")
global driverEdit := appGui.AddEdit("x+8 yp-3 w180")
global partialCheck := appGui.AddCheckbox("x+12 yp+3", "부분 일치")

appGui.AddText("x30 y+18 w90", "시작일")
global startEdit := appGui.AddEdit("x+8 yp-3 w110", FormatTime(A_Now, "yyyyMMdd"))
appGui.AddText("x+18 yp+3 w50", "종료일")
global endEdit := appGui.AddEdit("x+8 yp-3 w110", FormatTime(DateAdd(A_Now, 1, "Days"), "yyyyMMdd"))

global searchButton := appGui.AddButton("x30 y+18 w110 h30", "조회")
global copyButton := appGui.AddButton("x+8 yp w130 h30", "선택 결과 복사")
global statusText := appGui.AddText("x+15 yp+7 w780", "대기 중")

global resultList := appGui.AddListView("x30 y+12 w1130 h270 Grid", ["운행관제승인부서", "운행관제승인자", "승인번호", "작업구분", "내역"])
resultList.ModifyCol(1, 250)
resultList.ModifyCol(2, 160)
resultList.ModifyCol(3, 220)
resultList.ModifyCol(4, 120)
resultList.ModifyCol(5, 380)

mainTabs.UseTab(2)
global waitSearchButton := appGui.AddButton("x30 y175 w150 h32", "공람대기 조회")
global completeSearchButton := appGui.AddButton("x+8 yp w150 h32", "공람완료 조회")
global handyCopyButton := appGui.AddButton("x+8 yp w130 h32", "선택 결과 복사")
global clearFiltersButton := appGui.AddButton("x+8 yp w110 h32", "필터 초기화")
global handyStatusText := appGui.AddText("x+15 yp+8 w520", "대기 중")

appGui.AddText("x30 y218 w75", "상태")
global handyStatusDropdownButton := appGui.AddButton("x30 y238 w75 h24", "전체  ▼")
appGui.AddText("x110 y218 w90", "문서종류")
global handyDocumentTypeDropdownButton := appGui.AddButton("x110 y238 w90 h24", "전체  ▼")
appGui.AddText("x205 y218 w200", "제목")
global handyTitleFilter := appGui.AddEdit("x205 y238 w200 h24")
appGui.AddText("x410 y218 w70", "원기안자")
global handyOriginalDrafterFilter := appGui.AddEdit("x410 y238 w70 h24")
appGui.AddText("x485 y218 w70", "기안자")
global handyDrafterFilter := appGui.AddEdit("x485 y238 w70 h24")
appGui.AddText("x560 y218 w205", "기안일시")
global handyDraftDateFromFilter := appGui.AddEdit("x560 y238 w92 h24 Limit10 Number")
appGui.AddText("x655 y241 w12 Center", "~")
global handyDraftDateToFilter := appGui.AddEdit("x670 y238 w95 h24 Limit10 Number")
appGui.AddText("x770 y218 w75", "최종결재자")
global handyFinalApproverFilter := appGui.AddEdit("x770 y238 w75 h24")
appGui.AddText("x850 y218 w80", "공람지정자")
global handyCirculatorFilter := appGui.AddEdit("x850 y238 w80 h24")
appGui.AddText("x935 y218 w195", "공람일시")
global handyCirculationDateFromFilter := appGui.AddEdit("x935 y238 w87 h24 Limit10 Number")
appGui.AddText("x1025 y241 w12 Center", "~")
global handyCirculationDateToFilter := appGui.AddEdit("x1040 y238 w90 h24 Limit10 Number")

global handyTextFilterEdits := [handyTitleFilter, handyOriginalDrafterFilter, handyDrafterFilter,
    handyFinalApproverFilter, handyCirculatorFilter]
global handyDateFilterEdits := [handyDraftDateFromFilter, handyDraftDateToFilter,
    handyCirculationDateFromFilter, handyCirculationDateToFilter]
global handyTextFilterByHwnd := Map()
for filterEdit in handyTextFilterEdits
    handyTextFilterByHwnd[filterEdit.Hwnd] := filterEdit

global handyList := appGui.AddListView("x30 y270 w1130 h285 Grid", ["상태", "문서종류", "제목", "원기안자", "기안자", "기안일시", "최종결재자", "공람지정자", "공람일시", "_KEY"])
handyList.ModifyCol(1, 75)
handyList.ModifyCol(2, 90)
handyList.ModifyCol(3, 300)
handyList.ModifyCol(4, 90)
handyList.ModifyCol(5, 90)
handyList.ModifyCol(6, 125)
handyList.ModifyCol(7, 95)
handyList.ModifyCol(8, 105)
handyList.ModifyCol(9, 135)
handyList.ModifyCol(10, 0)
appGui.AddText("x30 y565 w1100 c666666", "상태·문서종류 드롭다운에서 여러 항목을 체크할 수 있습니다. 행을 더블클릭하면 핸디그룹웨어에서 문서를 엽니다.")

mainTabs.UseTab()
appGui.AddText("xm y620 w1160 c666666", "세션은 프로그램 종료 전까지 재사용합니다. 로그에는 인증정보, 문서 원문 및 조회 결과를 기록하지 않습니다.")

loginButton.OnEvent("Click", LoginAll)
searchButton.OnEvent("Click", SearchDriver)
copyButton.OnEvent("Click", CopySelected)
waitSearchButton.OnEvent("Click", (*) => SearchHandyDocuments("wait"))
completeSearchButton.OnEvent("Click", (*) => SearchHandyDocuments("complete"))
handyCopyButton.OnEvent("Click", (*) => CopyHandySelected(handyList))
clearFiltersButton.OnEvent("Click", ClearHandyFilters)
handyList.OnEvent("DoubleClick", OpenSelectedHandyDocument)
handyStatusDropdownButton.OnEvent("Click", (*) => ToggleHandyChoicePopup("status"))
handyDocumentTypeDropdownButton.OnEvent("Click", (*) => ToggleHandyChoicePopup("documentType"))
for filterEdit in handyTextFilterEdits
    filterEdit.OnEvent("Change", HandyFilterChanged)
for filterEdit in handyDateFilterEdits
    filterEdit.OnEvent("Change", HandyDateFilterChanged)
saveSecretsButton.OnEvent("Click", SaveSecretsFromGui)
employeeEdit.OnEvent("Change", AccountIdentityChanged)
appGui.OnEvent("Close", CloseApplication)
InstallHandyImeSubclasses()
LoadSecretsIntoGui()
RestorePersistedSession()
LogDebug("프로그램 시작")
appGui.Show("w1200 h655")
SetTimer(PollHandyTextFilters, 75)

LoginAll(*) {
    global activeHttpSession, loginButton

    loginButton.Enabled := false
    try {
        if IsObject(activeHttpSession) && !IsSessionForCurrentAccount(activeHttpSession) {
            LogDebug("GUI 계정이 변경되어 보유 세션을 폐기")
            activeHttpSession := 0
        }
        if !IsObject(activeHttpSession)
            RestorePersistedSession()
        if IsObject(activeHttpSession) {
            SetLoginStatus("보유 세션으로 공람 기능 준비 중...")
            if !activeHttpSession.HandyReady
                PrepareHandySession(activeHttpSession)
            SetLoginStatus("로그인 완료 · XPlatform/공람 세션 준비됨")
            LogDebug("로그인 버튼: 보유 세션 재사용 완료")
            return
        }

        SetLoginStatus("포털 및 MIS 로그인 중...")
        session := CreateAuthenticatedSession(false)
        activeHttpSession := session

        SetLoginStatus("MIS 로그인 완료 · 공람 세션 준비 중...")
        PrepareHandySession(session)
        SetLoginStatus("로그인 완료 · XPlatform/공람 세션 준비됨")
        PersistSession(session)
        LogDebug("로그인 버튼: 전체 세션 준비 완료")
    } catch as err {
        LogException(err, "로그인 버튼 처리 실패")
        if IsObject(activeHttpSession)
            SetLoginStatus("MIS 로그인 완료 · 공람 준비 실패")
        else
            SetLoginStatus("로그인 실패")
        MsgBox(err.Message, "로그인 오류", "Iconx")
    } finally {
        loginButton.Enabled := true
    }
}

CreateAuthenticatedSession(prepareHandy := false) {
    secrets := GetSecretsFromGui()
    try {
        session := HttpSession()
        AutoLogin(session, secrets)
        session.EmployeeId := secrets["사번"]
        if prepareHandy
            PrepareHandySession(session)
        PersistSession(session)
        return session
    } finally {
        if IsObject(secrets) {
            secrets["사번"] := ""
            secrets["1차비번"] := ""
            secrets["2차비번"] := ""
        }
    }
}

SearchDriver(*) {
    global driverEdit, partialCheck, startEdit, endEdit, searchButton
    global statusText, resultList, activeHttpSession

    driverName := Trim(driverEdit.Value)
    startDate := Trim(startEdit.Value)
    endDate := Trim(endEdit.Value)

    if (driverName = "") {
        MsgBox("운전자 이름을 입력하세요.", "입력 확인", "Icon!")
        return
    }
    if !RegExMatch(startDate, "^\d{8}$") || !RegExMatch(endDate, "^\d{8}$") {
        MsgBox("날짜는 yyyyMMdd 형식으로 입력하세요.", "입력 확인", "Icon!")
        return
    }
    if (startDate > endDate) {
        MsgBox("종료일은 시작일보다 빠를 수 없습니다.", "입력 확인", "Icon!")
        return
    }

    LogDebug("조회 시작: 기간=" startDate "~" endDate ", 부분일치=" (partialCheck.Value = 1 ? "예" : "아니오"))
    searchButton.Enabled := false
    resultList.Delete()
    statusText.Value := "세션 확인 중..."

    try {
        responseText := ""
        route := ""

        if IsObject(activeHttpSession) && !IsSessionForCurrentAccount(activeHttpSession) {
            LogDebug("GUI 계정이 변경되어 보유 세션을 폐기")
            activeHttpSession := 0
        }
        if !IsObject(activeHttpSession)
            RestorePersistedSession()

        ; 이전 조회에서 자동 로그인한 세션이 있으면 가장 먼저 재사용한다.
        if IsObject(activeHttpSession) {
            try {
                statusText.Value := "보유 중인 MIS 세션으로 조회 중..."
                responseText := QueryViaSession(activeHttpSession, startDate, endDate)
                EnsureXpSuccess(responseText)
                route := "보유 HTTP 세션"
                LogDebug("보유 HTTP 세션 재사용 성공")
            } catch as cachedSessionErr {
                LogDebug("보유 HTTP 세션을 사용할 수 없음: " cachedSessionErr.Message, "WARN")
                if IsMisSessionExpiredError(cachedSessionErr)
                    DeletePersistedSession()
                activeHttpSession := 0
                responseText := ""
            }
        }

        if (route = "") {
            ; XPlatform이 usewininet=true로 만든 기존 MIS 세션이 남아 있으면
            ; 브라우저나 XPlatform 프로세스가 열려 있지 않아도 바로 사용할 수 있다.
            try {
                statusText.Value := "기존 WinINet MIS 세션 확인 중..."
                responseText := QueryViaWinInet(startDate, endDate)
                EnsureXpSuccess(responseText)
                route := "기존 WinINet 세션"
                LogDebug("기존 WinINet MIS 세션 조회 성공")
            } catch as winInetSessionErr {
                LogDebug("기존 WinINet MIS 세션을 사용할 수 없음: " winInetSessionErr.Message, "WARN")
                statusText.Value := "계정으로 통합 SSO 및 MIS 로그인 중..."
                secrets := GetSecretsFromGui()
                session := HttpSession()
                AutoLogin(session, secrets)
                session.EmployeeId := secrets["사번"]

                ; 비밀번호 문자열을 더 이상 참조하지 않는다.
                secrets["1차비번"] := ""
                secrets["2차비번"] := ""

                responseText := QueryViaSession(session, startDate, endDate)
                EnsureXpSuccess(responseText)
                activeHttpSession := session
                PersistSession(session)
                route := "HTTP 자동 로그인"
                SetLoginStatus("MIS 로그인 완료 · 세션 보관 중")
                LogDebug("자동 로그인 세션을 후속 조회용으로 보관")
            }
        }

        parsed := ExtractMatches(responseText, driverName, partialCheck.Value = 1)
        for item in parsed.Items
            resultList.Add("", item.Dept, item.Approver, item.ApprovalNo, item.WorkType, item.Details)

        resultList.ModifyCol(1, 250)
        resultList.ModifyCol(2, 160)
        resultList.ModifyCol(3, 220)
        resultList.ModifyCol(4, 120)
        resultList.ModifyCol(5, 380)
        statusText.Value := route " · 전체 " parsed.Total "건 / 일치 " parsed.Items.Length "건"
        LogDebug("조회 완료: 경로=" route ", 전체=" parsed.Total ", 일치=" parsed.Items.Length)

        if (parsed.Items.Length = 0)
            MsgBox("해당 기간에 일치하는 운전자 데이터가 없습니다.", "조회 결과", "Iconi")
    } catch as err {
        LogException(err, "조회 실패")
        statusText.Value := "조회 실패"
        detail := err.Message
        if (err.What != "")
            detail .= "`n대상: " err.What
        if (err.File != "")
            detail .= "`n파일: " err.File
        if (err.Line != 0)
            detail .= "`n줄: " err.Line
        MsgBox(
            detail,
            "오류",
            "Iconx"
        )
    } finally {
        searchButton.Enabled := true
    }
}

CopySelected(*) {
    global resultList
    row := 0
    output := ""
    while (row := resultList.GetNext(row)) {
        if (output != "")
            output .= "`r`n"
        output .= resultList.GetText(row, 1) "`t"
            . resultList.GetText(row, 2) "`t"
            . resultList.GetText(row, 3) "`t"
            . resultList.GetText(row, 4) "`t"
            . resultList.GetText(row, 5)
    }
    if (output = "") {
        MsgBox("복사할 행을 선택하세요.", "선택 결과 복사", "Icon!")
        return
    }
    A_Clipboard := output
}

SearchHandyDocuments(kind) {
    global activeHttpSession
    global handyAllRows, handyDocumentRows, currentHandyKind
    global waitSearchButton, completeSearchButton, handyStatusText, handyList
    global handyDateFiltersAutoManaged, suppressHandyFilterEvents, handyDateFilterEdits

    isWait := kind = "wait"
    label := isWait ? "공람대기" : "공람완료"

    waitSearchButton.Enabled := false
    completeSearchButton.Enabled := false
    handyList.Delete()
    handyAllRows := []
    handyDocumentRows := Map()
    currentHandyKind := kind
    handyDateFiltersAutoManaged := true
    suppressHandyFilterEvents := true
    try {
        for filterEdit in handyDateFilterEdits
            filterEdit.Value := ""
    } finally {
        suppressHandyFilterEvents := false
    }
    handyStatusText.Value := label " 세션 확인 중..."
    LogDebug(label " 문서 조회 시작")

    try {
        Loop 2 {
            try {
                if IsObject(activeHttpSession) && !IsSessionForCurrentAccount(activeHttpSession) {
                    LogDebug("GUI 계정이 변경되어 보유 세션을 폐기")
                    activeHttpSession := 0
                }
                if !IsObject(activeHttpSession)
                    RestorePersistedSession()
                if !IsObject(activeHttpSession) {
                    SetLoginStatus("포털 및 MIS 로그인 중...")
                    activeHttpSession := CreateAuthenticatedSession(false)
                    SetLoginStatus("MIS 로그인 완료 · 공람 세션 준비 중...")
                }

                if !activeHttpSession.HandyReady {
                    handyStatusText.Value := label " 세션 준비 중..."
                    PrepareHandySession(activeHttpSession)
                }

                SetLoginStatus("로그인 완료 · XPlatform/공람 세션 준비됨")
                pageNumber := 1
                totalPages := 1
                paginationFields := 0
                Loop {
                    handyStatusText.Value := label " " pageNumber "페이지 조회 중..."
                    pageResult := RequestHandyDocumentPage(activeHttpSession, kind, pageNumber, paginationFields)
                    for item in pageResult.Rows {
                        item.Kind := kind
                        handyAllRows.Push(item)
                    }
                    if (pageNumber = 1)
                        totalPages := pageResult.TotalPages
                    paginationFields := pageResult.PaginationFields
                    RefreshHandyChoiceFilters()
                    UpdateDefaultHandyDateFilters()
                    ApplyHandyFilters(false)
                    handyStatusText.Value := label " " pageNumber "/" totalPages "페이지 · 누적 " handyAllRows.Length "건"
                    LogDebug(label " 페이지 수신: " pageNumber "/" totalPages " · 누적=" handyAllRows.Length)
                    Sleep(10)
                    if (pageNumber >= totalPages)
                        break
                    pageNumber += 1
                }
                break
            } catch as sessionErr {
                if (A_Index >= 2 || !IsRecoverableHandySessionError(sessionErr))
                    throw sessionErr

                LogDebug(label " 세션 만료 감지 · 새 세션으로 1회 재시도", "WARN")
                DeletePersistedSession()
                activeHttpSession := 0
                handyAllRows := []
                handyDocumentRows := Map()
                handyList.Delete()
                SetLoginStatus("세션 만료 · 다시 로그인 중...")
            }
        }

        ApplyHandyFilters()
        PersistSession(activeHttpSession)
        LogDebug(label " 문서 조회 완료: 실제 문서=" handyAllRows.Length)
        if (handyAllRows.Length = 0)
            MsgBox(label " 문서가 없습니다.", label, "Iconi")
    } catch as err {
        LogException(err, label " 문서 조회 실패")
        handyStatusText.Value := label " 조회 실패"
        MsgBox(err.Message, label " 조회 오류", "Iconx")
    } finally {
        waitSearchButton.Enabled := true
        completeSearchButton.Enabled := true
    }
}

ApplyHandyFilters(updateStatus := true, *) {
    global handyAllRows, handyDocumentRows, handyDocumentSequence
    global handyList, handyStatusText, currentHandyKind
    global handySelectedStatuses, handySelectedDocumentTypes
    global handyTitleFilter, handyOriginalDrafterFilter, handyDrafterFilter
    global handyFinalApproverFilter, handyCirculatorFilter
    global handyDraftDateFromFilter, handyDraftDateToFilter
    global handyCirculationDateFromFilter, handyCirculationDateToFilter

    selectedStatuses := handySelectedStatuses
    selectedDocumentTypes := handySelectedDocumentTypes
    textFilters := [
        StrLower(Trim(GetHandyTextFilterValue(handyTitleFilter))),
        StrLower(Trim(GetHandyTextFilterValue(handyOriginalDrafterFilter))),
        StrLower(Trim(GetHandyTextFilterValue(handyDrafterFilter))),
        StrLower(Trim(GetHandyTextFilterValue(handyFinalApproverFilter))),
        StrLower(Trim(GetHandyTextFilterValue(handyCirculatorFilter)))
    ]
    draftDateFrom := DateFilterBoundary(handyDraftDateFromFilter.Value, false)
    draftDateTo := DateFilterBoundary(handyDraftDateToFilter.Value, true)
    circulationDateFrom := DateFilterBoundary(handyCirculationDateFromFilter.Value, false)
    circulationDateTo := DateFilterBoundary(handyCirculationDateToFilter.Value, true)
    hasActiveFilter := selectedStatuses.Count > 0 || selectedDocumentTypes.Count > 0
        || draftDateFrom != "" || draftDateTo != ""
        || circulationDateFrom != "" || circulationDateTo != ""
    for filterValue in textFilters {
        if (filterValue != "") {
            hasActiveFilter := true
            break
        }
    }

    handyList.Opt("-Redraw")
    handyList.Delete()
    handyDocumentRows := Map()
    visibleCount := 0
    for item in handyAllRows {
        if (selectedStatuses.Count > 0 && !selectedStatuses.Has(item.Status))
            continue
        if (selectedDocumentTypes.Count > 0 && !selectedDocumentTypes.Has(item.DocumentType))
            continue

        textValues := [item.Title, item.OriginalDrafter, item.Drafter, item.FinalApprover, item.Circulator]
        matched := true
        for index, filterValue in textFilters {
            if (filterValue != "" && !InStr(StrLower(textValues[index]), filterValue)) {
                matched := false
                break
            }
        }
        if !matched
            continue
        if !MatchesDateRange(item.DraftDate, draftDateFrom, draftDateTo)
            continue
        if !MatchesDateRange(item.CirculationDate, circulationDateFrom, circulationDateTo)
            continue

        handyDocumentSequence += 1
        rowKey := currentHandyKind "-" handyDocumentSequence
        handyDocumentRows[rowKey] := item
        handyList.Add("", item.Status, item.DocumentType, item.Title, item.OriginalDrafter,
            item.Drafter, item.DraftDate, item.FinalApprover, item.Circulator, item.CirculationDate, rowKey)
        visibleCount += 1
    }
    handyList.Opt("+Redraw")
    if updateStatus {
        label := currentHandyKind = "wait" ? "공람대기" : (currentHandyKind = "complete" ? "공람완료" : "공람")
        handyStatusText.Value := hasActiveFilter
            ? label " 필터 결과 " visibleCount "건 / 전체 " handyAllRows.Length "건"
            : label " 전체 " handyAllRows.Length "건"
    }
}

RefreshHandyChoiceFilters() {
    global handyAllRows, handyStatusItems, handyDocumentTypeItems
    global handySelectedStatuses, handySelectedDocumentTypes

    statusItems := []
    documentTypeItems := []
    seenStatus := Map()
    seenDocumentType := Map()
    for item in handyAllRows {
        status := Trim(item.Status)
        documentType := Trim(item.DocumentType)
        if (status != "" && !seenStatus.Has(status)) {
            seenStatus[status] := true
            statusItems.Push(status)
        }
        if (documentType != "" && !seenDocumentType.Has(documentType)) {
            seenDocumentType[documentType] := true
            documentTypeItems.Push(documentType)
        }
    }

    handyStatusItems := statusItems
    handyDocumentTypeItems := documentTypeItems
    RemoveUnavailableChoices(handySelectedStatuses, seenStatus)
    RemoveUnavailableChoices(handySelectedDocumentTypes, seenDocumentType)
    RebuildHandyChoicePopups()
    UpdateHandyChoiceButtonLabels()
}

RemoveUnavailableChoices(selectedMap, availableMap) {
    removeKeys := []
    for itemText in selectedMap {
        if !availableMap.Has(itemText)
            removeKeys.Push(itemText)
    }
    for itemText in removeKeys
        selectedMap.Delete(itemText)
}

RebuildHandyChoicePopups() {
    global handyStatusItems, handyDocumentTypeItems
    global handyStatusPopup, handyDocumentTypePopup, openHandyChoicePopupKind

    if IsObject(handyStatusPopup)
        handyStatusPopup.Destroy()
    if IsObject(handyDocumentTypePopup)
        handyDocumentTypePopup.Destroy()
    handyStatusPopup := CreateHandyChoicePopup("status", handyStatusItems, 210)
    handyDocumentTypePopup := CreateHandyChoicePopup("documentType", handyDocumentTypeItems, 240)
    openHandyChoicePopupKind := ""
}

CreateHandyChoicePopup(kind, items, popupWidth) {
    global appGui
    popup := Gui("+AlwaysOnTop -Caption +ToolWindow +Border +Owner" appGui.Hwnd)
    popup.SetFont("s10", "Malgun Gothic")
    y := 8
    if (items.Length = 0) {
        popup.AddText("x10 y" y " w" (popupWidth - 20) " Center c666666", "조회된 항목 없음")
        y += 28
    } else {
        for itemText in items {
            checkControl := popup.AddCheckbox("x10 y" y " w" (popupWidth - 20) " h22", itemText)
            checkControl.Value := IsHandyChoiceSelected(kind, itemText)
            checkControl.OnEvent("Click", HandyChoiceCheckChanged.Bind(kind, itemText))
            y += 24
        }
    }
    clearButton := popup.AddButton("x10 y" (y + 4) " w" ((popupWidth - 24) // 2) " h25", "전체")
    closeButton := popup.AddButton("x+4 yp w" ((popupWidth - 24) // 2) " h25", "닫기")
    clearButton.OnEvent("Click", ClearHandyChoiceSelection.Bind(kind))
    closeButton.OnEvent("Click", HideHandyChoicePopup.Bind(kind))
    popup.OnEvent("Escape", HideHandyChoicePopup.Bind(kind))
    popup.OnEvent("Close", HideHandyChoicePopup.Bind(kind))
    return popup
}

IsHandyChoiceSelected(kind, itemText) {
    global handySelectedStatuses, handySelectedDocumentTypes
    selectedMap := kind = "status" ? handySelectedStatuses : handySelectedDocumentTypes
    return selectedMap.Has(itemText)
}

HandyChoiceCheckChanged(kind, itemText, checkControl, *) {
    global handySelectedStatuses, handySelectedDocumentTypes
    selectedMap := kind = "status" ? handySelectedStatuses : handySelectedDocumentTypes
    if checkControl.Value
        selectedMap[itemText] := true
    else if selectedMap.Has(itemText)
        selectedMap.Delete(itemText)
    UpdateHandyChoiceButtonLabels()
    ApplyHandyFilters()
}

ClearHandyChoiceSelection(kind, *) {
    global handySelectedStatuses, handySelectedDocumentTypes
    selectedMap := kind = "status" ? handySelectedStatuses : handySelectedDocumentTypes
    selectedMap.Clear()
    HideHandyChoicePopup(kind)
    UpdateHandyChoiceButtonLabels()
    ApplyHandyFilters()
    SetTimer(RebuildHandyChoicePopups, -1)
}

ToggleHandyChoicePopup(kind) {
    global appGui, handyStatusDropdownButton, handyDocumentTypeDropdownButton
    global handyStatusPopup, handyDocumentTypePopup, openHandyChoicePopupKind
    global handyStatusItems, handyDocumentTypeItems

    if (openHandyChoicePopupKind = kind) {
        HideHandyChoicePopup(kind)
        return
    }
    if (openHandyChoicePopupKind != "")
        HideHandyChoicePopup(openHandyChoicePopupKind)

    popup := kind = "status" ? handyStatusPopup : handyDocumentTypePopup
    dropdownButton := kind = "status" ? handyStatusDropdownButton : handyDocumentTypeDropdownButton
    items := kind = "status" ? handyStatusItems : handyDocumentTypeItems
    popupWidth := kind = "status" ? 210 : 240
    popupHeight := 8 + (items.Length ? items.Length * 24 : 28) + 37
    if !IsObject(popup)
        return
    dropdownButton.GetPos(&buttonX, &buttonY, &buttonWidth, &buttonHeight)
    pointBuffer := Buffer(8, 0)
    NumPut("Int", buttonX, "Int", buttonY + buttonHeight, pointBuffer)
    DllCall("user32\ClientToScreen", "Ptr", appGui.Hwnd, "Ptr", pointBuffer.Ptr)
    screenX := NumGet(pointBuffer, 0, "Int")
    screenY := NumGet(pointBuffer, 4, "Int")
    popup.Show("x" screenX " y" screenY " w" popupWidth " h" popupHeight)
    openHandyChoicePopupKind := kind
}

HideHandyChoicePopup(kind, *) {
    global handyStatusPopup, handyDocumentTypePopup, openHandyChoicePopupKind
    popup := kind = "status" ? handyStatusPopup : handyDocumentTypePopup
    if IsObject(popup)
        popup.Hide()
    if (openHandyChoicePopupKind = kind)
        openHandyChoicePopupKind := ""
}

UpdateHandyChoiceButtonLabels() {
    global handyStatusDropdownButton, handyDocumentTypeDropdownButton
    global handySelectedStatuses, handySelectedDocumentTypes
    handyStatusDropdownButton.Text := HandyChoiceButtonText(handySelectedStatuses)
    handyDocumentTypeDropdownButton.Text := HandyChoiceButtonText(handySelectedDocumentTypes)
}

HandyChoiceButtonText(selectedMap) {
    if (selectedMap.Count = 0)
        return "전체  ▼"
    firstText := ""
    for itemText in selectedMap {
        firstText := itemText
        break
    }
    return selectedMap.Count = 1 ? firstText "  ▼" : firstText " 외 " (selectedMap.Count - 1) "  ▼"
}

HandyFilterChanged(*) {
    global suppressHandyFilterEvents
    if !suppressHandyFilterEvents
        ApplyHandyFilters()
}

HandyDateFilterChanged(editControl, *) {
    global suppressHandyFilterEvents, suppressHandyDateFormatting, handyDateFiltersAutoManaged
    if suppressHandyFilterEvents || suppressHandyDateFormatting
        return

    handyDateFiltersAutoManaged := false

    rawValue := editControl.Value
    selection := GetEditSelection(editControl)
    digitsBeforeCaret := StrLen(RegExReplace(SubStr(rawValue, 1, selection.Start), "\D"))
    formatted := FormatDateFilterValue(rawValue)
    if (rawValue != formatted) {
        suppressHandyDateFormatting := true
        try {
            editControl.Value := formatted
            caretPosition := DateCaretPosition(digitsBeforeCaret)
            SetEditSelection(editControl, caretPosition, caretPosition)
        } finally {
            suppressHandyDateFormatting := false
        }
    }
    ApplyHandyFilters()
}

DateCaretPosition(digitCount) {
    if (digitCount <= 4)
        return digitCount
    if (digitCount <= 6)
        return digitCount + 1
    return Min(digitCount + 2, 10)
}

GetEditSelection(editControl) {
    return GetEditSelectionByHwnd(editControl.Hwnd)
}

GetEditSelectionByHwnd(editHwnd) {
    selection := DllCall("user32\SendMessageW", "Ptr", editHwnd,
        "UInt", 0x00B0, "Ptr", 0, "Ptr", 0, "Ptr")  ; EM_GETSEL
    return {Start: selection & 0xFFFF, End: (selection >> 16) & 0xFFFF}
}

SetEditSelection(editControl, selectionStart, selectionEnd) {
    DllCall("user32\SendMessageW", "Ptr", editControl.Hwnd,
        "UInt", 0x00B1, "Ptr", selectionStart, "Ptr", selectionEnd)  ; EM_SETSEL
}

FormatDateFilterValue(value) {
    digits := RegExReplace(value, "\D")
    digits := SubStr(digits, 1, 8)
    if (StrLen(digits) <= 4)
        return digits
    if (StrLen(digits) <= 6)
        return SubStr(digits, 1, 4) "." SubStr(digits, 5)
    return SubStr(digits, 1, 4) "." SubStr(digits, 5, 2) "." SubStr(digits, 7)
}

UpdateDefaultHandyDateFilters() {
    global handyDateFiltersAutoManaged, suppressHandyFilterEvents
    global handyDraftDateFromFilter, handyDraftDateToFilter
    global handyCirculationDateFromFilter, handyCirculationDateToFilter

    if !handyDateFiltersAutoManaged
        return

    draftRange := GetHandyDateRange(true)
    circulationRange := GetHandyDateRange(false)
    previousSuppression := suppressHandyFilterEvents
    suppressHandyFilterEvents := true
    try {
        handyDraftDateFromFilter.Value := FormatDateFilterValue(draftRange.From)
        handyDraftDateToFilter.Value := FormatDateFilterValue(draftRange.To)
        handyCirculationDateFromFilter.Value := FormatDateFilterValue(circulationRange.From)
        handyCirculationDateToFilter.Value := FormatDateFilterValue(circulationRange.To)
    } finally {
        suppressHandyFilterEvents := previousSuppression
    }
}

GetHandyDateRange(isDraftDate) {
    global handyAllRows
    minimumDate := ""
    maximumDate := ""
    for item in handyAllRows {
        value := isDraftDate ? item.DraftDate : item.CirculationDate
        digits := SubStr(RegExReplace(value, "\D"), 1, 8)
        ; 날짜가 비어 있는 행이 하나라도 있으면 범위를 비워 모든 행을 포함한다.
        if (StrLen(digits) < 8)
            return {From: "", To: ""}
        if (minimumDate = "" || digits < minimumDate)
            minimumDate := digits
        if (maximumDate = "" || digits > maximumDate)
            maximumDate := digits
    }
    return {From: minimumDate, To: maximumDate}
}

DateFilterBoundary(value, isEnd) {
    digits := RegExReplace(value, "\D")
    if (digits = "")
        return ""
    padding := isEnd ? "99999999" : "00000000"
    return SubStr(digits padding, 1, 8)
}

MatchesDateRange(value, dateFrom, dateTo) {
    if (dateFrom = "" && dateTo = "")
        return true
    documentDate := SubStr(RegExReplace(value, "\D"), 1, 8)
    if (StrLen(documentDate) < 8)
        return false
    return (dateFrom = "" || documentDate >= dateFrom)
        && (dateTo = "" || documentDate <= dateTo)
}

ClearHandyFilters(*) {
    global handySelectedStatuses, handySelectedDocumentTypes
    global handyTextFilterEdits, handyDateFilterEdits, handyImeComposition
    global suppressHandyFilterEvents, handyDateFiltersAutoManaged
    suppressHandyFilterEvents := true
    try {
        handySelectedStatuses.Clear()
        handySelectedDocumentTypes.Clear()
        for filterEdit in handyTextFilterEdits
            filterEdit.Value := ""
        handyDateFiltersAutoManaged := true
        UpdateDefaultHandyDateFilters()
    } finally {
        suppressHandyFilterEvents := false
    }
    handyImeComposition := Map()
    RebuildHandyChoicePopups()
    UpdateHandyChoiceButtonLabels()
    ApplyHandyFilters()
}

InstallHandyImeSubclasses() {
    global handyTextFilterEdits, handyEditSubclassProc, handyEditOriginalWndProcs
    if handyEditSubclassProc
        return

    handyEditSubclassProc := CallbackCreate(HandyFilterEditWndProc, "Fast", 4)
    setterName := A_PtrSize = 8 ? "SetWindowLongPtrW" : "SetWindowLongW"
    for filterEdit in handyTextFilterEdits {
        oldProc := DllCall("user32\" setterName, "Ptr", filterEdit.Hwnd,
            "Int", -4, "Ptr", handyEditSubclassProc, "Ptr")  ; GWLP_WNDPROC
        if !oldProc
            throw OSError(A_LastError, -1, "IME 필터 입력 컨트롤 연결 실패")
        handyEditOriginalWndProcs[filterEdit.Hwnd] := oldProc
    }
}

RestoreHandyImeSubclasses() {
    global handyEditSubclassProc, handyEditOriginalWndProcs
    if !handyEditSubclassProc
        return

    setterName := A_PtrSize = 8 ? "SetWindowLongPtrW" : "SetWindowLongW"
    for editHwnd, oldProc in handyEditOriginalWndProcs {
        if DllCall("user32\IsWindow", "Ptr", editHwnd)
            DllCall("user32\" setterName, "Ptr", editHwnd, "Int", -4, "Ptr", oldProc, "Ptr")
    }
    handyEditOriginalWndProcs := Map()
    CallbackFree(handyEditSubclassProc)
    handyEditSubclassProc := 0
}

HandyFilterEditWndProc(hwnd, msg, wParam, lParam) {
    global handyEditOriginalWndProcs, handyImeComposition
    if !handyEditOriginalWndProcs.Has(hwnd)
        return DllCall("user32\DefWindowProcW", "Ptr", hwnd, "UInt", msg,
            "Ptr", wParam, "Ptr", lParam, "Ptr")

    oldProc := handyEditOriginalWndProcs[hwnd]
    compositionState := 0
    refreshNeeded := false
    if (msg = 0x010D) {  ; WM_IME_STARTCOMPOSITION
        if handyImeComposition.Has(hwnd)
            handyImeComposition.Delete(hwnd)
        refreshNeeded := true
    } else if (msg = 0x010F) {  ; WM_IME_COMPOSITION
        if (lParam & 0x0008) {  ; GCS_COMPSTR
            compositionText := ReadImeCompositionString(hwnd)
            if (compositionText != "") {
                selection := GetEditSelectionByHwnd(hwnd)
                compositionState := {Text: compositionText,
                    Start: selection.Start, End: selection.End}
            }
        }
        refreshNeeded := true
    } else if (msg = 0x010E) {  ; WM_IME_ENDCOMPOSITION
        refreshNeeded := true
    }

    result := DllCall("user32\CallWindowProcW", "Ptr", oldProc, "Ptr", hwnd,
        "UInt", msg, "Ptr", wParam, "Ptr", lParam, "Ptr")

    if (msg = 0x010F && IsObject(compositionState)) {
        handyImeComposition[hwnd] := compositionState
    } else if ((msg = 0x010E)
        || (msg = 0x010F && ((lParam & 0x0800) || lParam = 0))) {
        if handyImeComposition.Has(hwnd)
            handyImeComposition.Delete(hwnd)
    }

    if refreshNeeded
        SetTimer(ApplyHandyFiltersAfterImeCommit, -1)
    return result
}

ApplyHandyFiltersAfterImeCommit() {
    ApplyHandyFilters()
}

PollHandyTextFilters() {
    global currentHandyKind, handyTextFilterEdits, handyImeComposition
    global lastHandyTextFilterSignature
    if (currentHandyKind = "")
        return

    try {
        signature := ""
        for filterEdit in handyTextFilterEdits {
            composition := handyImeComposition.Has(filterEdit.Hwnd)
                ? handyImeComposition[filterEdit.Hwnd].Text : ""
            signature .= filterEdit.Value Chr(30) composition Chr(31)
        }
        if (signature = lastHandyTextFilterSignature)
            return
        lastHandyTextFilterSignature := signature
        ApplyHandyFilters()
    } catch as err {
        SetTimer(PollHandyTextFilters, 0)
        LogException(err, "공람 텍스트 필터 감시 실패")
    }
}

ReadImeCompositionString(hwnd) {
    inputContext := DllCall("imm32\ImmGetContext", "Ptr", hwnd, "Ptr")
    if !inputContext
        return ""
    try {
        byteLength := DllCall("imm32\ImmGetCompositionStringW", "Ptr", inputContext,
            "UInt", 0x0008, "Ptr", 0, "UInt", 0, "Int")
        if (byteLength <= 0)
            return ""
        compositionBuffer := Buffer(byteLength + 2, 0)
        copiedLength := DllCall("imm32\ImmGetCompositionStringW", "Ptr", inputContext,
            "UInt", 0x0008, "Ptr", compositionBuffer.Ptr, "UInt", byteLength, "Int")
        return copiedLength > 0 ? StrGet(compositionBuffer.Ptr, copiedLength // 2, "UTF-16") : ""
    } finally {
        DllCall("imm32\ImmReleaseContext", "Ptr", hwnd, "Ptr", inputContext)
    }
}

GetHandyTextFilterValue(editControl) {
    global handyImeComposition
    value := editControl.Value
    if !handyImeComposition.Has(editControl.Hwnd)
        return value
    compositionState := handyImeComposition[editControl.Hwnd]
    if !IsObject(compositionState) || compositionState.Text = ""
        return value

    selectionStart := Min(compositionState.Start, StrLen(value))
    selectionEnd := Min(compositionState.End, StrLen(value))
    return SubStr(value, 1, selectionStart) compositionState.Text SubStr(value, selectionEnd + 1)
}

CopyHandySelected(listControl) {
    row := 0
    output := ""
    while (row := listControl.GetNext(row)) {
        columns := ""
        Loop 9
            columns .= (A_Index = 1 ? "" : "`t") listControl.GetText(row, A_Index)
        output .= (output = "" ? "" : "`r`n") columns
    }
    if (output = "") {
        MsgBox("복사할 행을 선택하세요.", "선택 결과 복사", "Icon!")
        return
    }
    A_Clipboard := output
}

OpenSelectedHandyDocument(*) {
    global activeHttpSession, handyDocumentRows, handyList

    row := handyList.GetNext(0)
    if !row
        return
    rowKey := handyList.GetText(row, 10)
    if (rowKey = "" || !handyDocumentRows.Has(rowKey)) {
        MsgBox("선택한 문서의 열람정보를 찾지 못했습니다. 목록을 다시 조회하세요.", "문서 열기", "Icon!")
        return
    }
    item := handyDocumentRows[rowKey]
    kind := item.Kind
    if !IsObject(activeHttpSession) || !activeHttpSession.HandyReady {
        MsgBox("상단 로그인 버튼으로 공람 세션을 먼저 준비하세요.", "문서 열기", "Icon!")
        return
    }
    if !IsSessionForCurrentAccount(activeHttpSession) {
        MsgBox("현재 계정과 보유 세션의 사용자가 다릅니다. 다시 로그인하세요.", "문서 열기", "Icon!")
        return
    }
    if (kind = "wait") {
        answer := MsgBox("공람대기 문서를 열면 서버에서 열람 또는 공람 상태가 변경될 수 있습니다.`n계속하시겠습니까?",
            "공람대기 문서 열기", "YesNo Icon!")
        if (answer != "Yes")
            return
    }

    if !IsObject(item.ViewData) || item.ViewData.Count = 0 {
        MsgBox("이 행에는 사용할 수 있는 문서 열람정보가 없습니다.", "문서 열기", "Icon!")
        return
    }

    try {
        clientUrl := RequestHandyClientUrl(activeHttpSession, kind, item.ViewData)
        Run(clientUrl)
        clientUrl := ""
        LogDebug((kind = "wait" ? "공람대기" : "공람완료") " 문서 핸디그룹웨어 실행 요청")
    } catch as err {
        LogException(err, "공람 문서 열기 실패")
        MsgBox(err.Message, "문서 열기 오류", "Iconx")
    }
}

RequestHandyClientUrl(session, kind, viewData) {
    fields := viewData["Fields"]
    if (fields.Length < 14)
        throw Error("문서 열람 파라미터가 예상보다 부족합니다.")

    meta := session.HandyMeta
    folder := meta[kind = "wait" ? "Wait" : "Complete"]
    params := Map(
        "USERID", meta["UserId"],
        "APPRIDLIST", GetHandyDocumentField(fields, 1),
        "APPRDEPTID", meta["DeptId"],
        "APPRIDXID", viewData["DocumentIndexId"],
        "WORDTYPE", GetHandyDocumentField(fields, 5),
        "APPRSTATUSLIST", GetHandyDocumentField(fields, 2),
        "APPRTYPELIST", GetHandyDocumentField(fields, 4),
        "MENUMASKLIST", GetHandyDocumentField(fields, 6),
        "SIGNERTYPELIST", "",
        "APPLID", folder["AppId"],
        "PARTICIPANTID", "",
        "EXTERNALDOCF", GetHandyDocumentField(fields, 10),
        "EXTERNALDOCFLIST", GetHandyDocumentField(fields, 10),
        "DRAFTSRCLIST", GetHandyDocumentField(fields, 12),
        "menuID", viewData["MenuId"],
        "WEBIP", "https://niw.humetro.busan.kr",
        "USERAGENT", "edge",
        "K", meta["K"],
        "DOCATTRLIST", GetHandyDocumentField(fields, 9),
        "externalDocPrint", "false",
        "CLTAPP", "1",
        "fldrShare", "false",
        "fldrShareDeptId", meta["DeptId"],
        "ORGAPPRIDLIST", GetHandyDocumentField(fields, 13),
        "_NOARG", EpochMilliseconds()
    )
    endpoint := kind = "wait" ? "retrieveCnrsWaitDocList.act" : "retrieveCnrsComptDocList.act"
    response := session.Request("POST",
        "https://niw.humetro.busan.kr/bms/com/hs/gwweb/appr/hstCmdEx.act",
        BuildFormBody(params), Map(
            "Content-Type", "application/x-www-form-urlencoded; charset=UTF-8",
            "Accept", "application/json, text/javascript, */*; q=0.01",
            "X-Requested-With", "XMLHttpRequest",
            "Origin", "https://niw.humetro.busan.kr",
            "Referer", "https://niw.humetro.busan.kr/bms/com/hs/gwweb/appr/" endpoint))

    if !RegExMatch(response.Text, "i)" Chr(34) "ok" Chr(34) "\s*:\s*true")
        throw Error("핸디그룹웨어가 문서 실행 명령을 만들지 못했습니다.")
    pattern := "is)" Chr(34) "clientURL" Chr(34) "\s*:\s*" Chr(34)
        . "((?:\\.|[^" Chr(34) "\\])*)" Chr(34)
    if !RegExMatch(response.Text, pattern, &urlMatch)
        throw Error("핸디그룹웨어 응답에서 실행 URL을 찾지 못했습니다.")

    clientUrl := JsonUnescapeString(urlMatch[1])
    if !RegExMatch(clientUrl, "i)^xsclient8://")
        throw Error("허용되지 않은 핸디그룹웨어 실행 프로토콜을 차단했습니다.")
    return clientUrl
}

GetHandyDocumentField(fields, jsIndex) {
    ; Handy JavaScript 상수는 1부터 시작하고 docinfo split 결과도 AHK에서 1부터 시작하므로 같은 인덱스를 쓴다.
    ahkIndex := jsIndex
    return fields.Length >= ahkIndex ? fields[ahkIndex] : ""
}

JsonUnescapeString(value) {
    slash := Chr(92)
    output := ""
    pos := 1
    while (pos <= StrLen(value)) {
        char := SubStr(value, pos, 1)
        if (char != slash) {
            output .= char
            pos += 1
            continue
        }
        pos += 1
        if (pos > StrLen(value))
            throw Error("JSON 문자열의 이스케이프가 잘못되었습니다.")
        escaped := SubStr(value, pos, 1)
        switch escaped {
            case Chr(34), slash, "/": output .= escaped
            case "b": output .= Chr(8)
            case "f": output .= Chr(12)
            case "n": output .= "`n"
            case "r": output .= "`r"
            case "t": output .= "`t"
            case "u":
                if (pos + 4 > StrLen(value))
                    throw Error("JSON 유니코드 이스케이프가 잘못되었습니다.")
                output .= Chr(Integer("0x" SubStr(value, pos + 1, 4)))
                pos += 4
            default: throw Error("지원하지 않는 JSON 이스케이프입니다.")
        }
        pos += 1
    }
    return output
}

IsRecoverableHandySessionError(err) {
    message := err.Message
    return InStr(message, "HANDY_SESSION_EXPIRED")
        || InStr(message, "핸디웨어 SSO")
        || InStr(message, "BMS JSESSIONID")
}

IsMisSessionExpiredError(err) {
    return InStr(err.Message, "MIS 세션이 없거나 만료")
        || InStr(err.Message, "MIS 통합 SSO 초기화")
}

IsSessionForCurrentAccount(session) {
    global employeeEdit
    return session.EmployeeId != "" && Trim(employeeEdit.Value) = session.EmployeeId
}

AccountIdentityChanged(*) {
    global activeHttpSession
    if IsObject(activeHttpSession) && !IsSessionForCurrentAccount(activeHttpSession)
        SetLoginStatus("계정 변경됨 · 다시 로그인 필요")
}

SetLoginStatus(status) {
    global loginGroup
    loginGroup.Text := "로그인 - " status
}

PrepareHandySession(session) {
    baseNiw := "https://niw.humetro.busan.kr"
    portalEntry := "https://btcep.humetro.busan.kr/jeon/jeonja.jsp?menuType=approval&callType=callMenu"

    LogDebug("핸디웨어 approval SSO 시작")
    ssoPage := session.Request("GET", portalEntry, "", Map(
        "Referer", "https://btcep.humetro.busan.kr/portal/default/main/groupware/gwapproval.page"))
    ssoUri := session.ParseUrl(ssoPage.Url)
    if (ssoUri.Scheme != "https" || ssoUri.Host != "niw.humetro.busan.kr"
        || StrLower(ssoUri.Path) != "/sso/index.jsp")
        throw Error("HANDY_SESSION_EXPIRED: 핸디웨어 SSO 페이지에 도달하지 못했습니다.")

    inputs := ExtractHiddenInputs(ssoPage.Text)
    if !inputs.Has("K") || inputs["K"] = ""
        throw Error("HANDY_SESSION_EXPIRED: 핸디웨어 SSO 응답에서 K를 찾지 못했습니다.")
    handyK := inputs["K"]
    LogDebug("핸디웨어 SSO 폼 확인 완료")

    bmsLoginUrl := baseNiw "/bms/login.cmmn"
    session.Request("POST", bmsLoginUrl, "K=" UrlEncode(handyK), Map(
        "Content-Type", "application/x-www-form-urlencoded",
        "Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Origin", baseNiw,
        "Referer", ssoPage.Url))
    if !session.HasCookieAtPath("niw.humetro.busan.kr", "/bms", "JSESSIONID")
        throw Error("HANDY_SESSION_EXPIRED: 핸디웨어 BMS JSESSIONID를 받지 못했습니다.")
    LogDebug("핸디웨어 BMS 세션 생성 완료")

    frameFields := Map()
    for fieldName in ["K", "GWLANG", "ctms", "gnbType", "flagFromHome", "bodyView",
        "linkage", "mainurl", "CLOSEOFF", "isPortal", "menuType"] {
        if inputs.Has(fieldName)
            frameFields[fieldName] := inputs[fieldName]
    }
    session.Request("POST", baseNiw "/jsp/main/frame.jsp", BuildFormBody(frameFields), Map(
        "Content-Type", "application/x-www-form-urlencoded",
        "Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Origin", baseNiw,
        "Referer", ssoPage.Url))
    session.StoreCookie(session.ParseUrl(baseNiw "/"), "pageUnit=50; Path=/; Secure")
    LogDebug("핸디웨어 frame.jsp 초기화 완료")

    session.HandyMeta := DiscoverHandyMetadata(session, handyK)
    session.HandyReady := true
    handyK := ""
    PersistSession(session)
    LogDebug("핸디웨어 사용자·부서·공람폴더 동적 탐색 완료")
}

DiscoverHandyMetadata(session, handyK) {
    baseNiw := "https://niw.humetro.busan.kr"
    menuUrl := baseNiw "/jsp/main/menu.jsp?K=" UrlEncode(handyK) "&menuType=approval&flagFromHome="
    menuPage := session.Request("GET", menuUrl)
    EnsureHandyPageNotExpired(menuPage.Text)

    frameQuery := Map(
        "USU", RequireJsString(menuPage.Text, "usu"),
        "DOCADMIN", RequireJsString(menuPage.Text, "isDocAdmin"),
        "SIMSAJA", RequireJsString(menuPage.Text, "isSimsaJa"),
        "SUSINADMIN", RequireJsString(menuPage.Text, "isSusinAdmin"),
        "DEPTID", RequireJsString(menuPage.Text, "GPSaveDocDeptID"),
        "USERDEPTID", RequireJsString(menuPage.Text, "UserDeptID"),
        "$ONMENU$", "MENU_HOMS_SBOX",
        "$MENUMASK$", "4294967295",
        "$INITCALL$", "false",
        "$EFKEY$", handyK,
        "EFKEY", handyK,
        "K", handyK,
        "_NOARG", EpochMilliseconds()
    )
    apprFrameUrl := baseNiw "/bms/cz/cb/viw/retrieveApprFrame.act?" BuildFormBody(frameQuery)
    apprFrame := session.Request("GET", apprFrameUrl, "", Map("Referer", menuUrl))
    EnsureHandyPageNotExpired(apprFrame.Text)

    if !RegExMatch(apprFrame.Text,
        "is)(?:src|href)\s*=\s*[" Chr(34) "']([^" Chr(34) "']*retrieveFldrPrivate\.act[^" Chr(34) "']*)",
        &privateMatch)
        throw Error("핸디웨어 개인 결재폴더 주소를 찾지 못했습니다.")
    privateUrl := session.ResolveUrl(apprFrame.Url, HtmlEntityDecode(privateMatch[1]))
    privatePage := session.Request("GET", privateUrl, "", Map("Referer", apprFrame.Url))
    EnsureHandyPageNotExpired(privatePage.Text)

    userId := RequireJsString(privatePage.Text, "g_userid")
    deptId := RequireJsString(privatePage.Text, "g_deptid")
    userDeptId := RequireJsString(privatePage.Text, "g_userdeptid")
    exids := ExtractJsString(privatePage.Text, "g_EXIDS")
    currentK := RequireJsString(privatePage.Text, "g_K")
    noArg := EpochMilliseconds()

    treeBase := Map(
        "userId", userId,
        "deptId", deptId,
        "userDeptId", userDeptId,
        "exids", exids,
        "K", currentK,
        "actFldr", "0",
        "auditorFlag", "",
        "fMode", "appr",
        "cacheType", "1",
        "_NOARG", noArg
    )
    treeBody := BuildFormBody(treeBase)
    treeBase["RETURNURLPARAM"] := treeBody
    treeResponse := session.Request("POST",
        baseNiw "/bms/com/hs/gwweb/folder/retrieveFldrPrivateTree.act",
        BuildFormBody(treeBase), Map(
            "Content-Type", "application/x-www-form-urlencoded",
            "Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Origin", baseNiw,
            "Referer", privateUrl))
    EnsureHandyPageNotExpired(treeResponse.Text)

    return Map(
        "K", currentK,
        "UserId", userId,
        "DeptId", deptId,
        "UserDeptId", userDeptId,
        "SaveDeptId", deptId,
        "Referer", apprFrame.Url,
        "Wait", ExtractHandyFolder(treeResponse.Text, "공람대기", "3020"),
        "Complete", ExtractHandyFolder(treeResponse.Text, "공람완료", "3010")
    )
}

RequestHandyDocumentPage(session, kind, pageNumber, paginationFields := 0) {
    meta := session.HandyMeta
    isWait := kind = "wait"
    folder := meta[isWait ? "Wait" : "Complete"]
    folderName := isWait ? "공람대기" : "공람완료"
    endpoint := isWait ? "retrieveCnrsWaitDocList.act" : "retrieveCnrsComptDocList.act"
    if (pageNumber = 1) {
        noArg := EpochMilliseconds()
        nested := "fldrName=" JavaScriptEscape(folderName)
            . "&deptId=" UrlEncode(meta["DeptId"])
            . "&userId=" UrlEncode(meta["UserId"])
            . "&userDeptId=" UrlEncode(meta["UserDeptId"])
            . "&saveDeptId=" UrlEncode(meta["SaveDeptId"])
            . "&APPLID=" UrlEncode(folder["AppId"])
            . "&applId=" UrlEncode(folder["AppId"])
            . "&applType=" UrlEncode(folder["Type"])
            . "&fldrId=" UrlEncode(folder["Id"])
            . "&customFolder=false"
            . "&K=" UrlEncode(meta["K"])
            . "&_NOARG=" noArg

        fields := Map(
            "fldrName", folderName,
            "deptId", meta["DeptId"],
            "userId", meta["UserId"],
            "userDeptId", meta["UserDeptId"],
            "saveDeptId", meta["SaveDeptId"],
            "APPLID", folder["AppId"],
            "applId", folder["AppId"],
            "applType", folder["Type"],
            "fldrId", folder["Id"],
            "customFolder", "false",
            "K", meta["K"],
            "_NOARG", noArg,
            "RETURNURLPARAM", nested
        )
    } else {
        if !IsObject(paginationFields)
            throw Error("다음 페이지 조회에 필요한 폼 정보를 찾지 못했습니다.")
        fields := paginationFields.Clone()
        fields["pageIndex"] := pageNumber
        fields["pageUnit"] := "50"
        fields["target_page"] := pageNumber
    }

    url := "https://niw.humetro.busan.kr/bms/com/hs/gwweb/appr/" endpoint
    response := session.Request("POST", url, BuildFormBody(fields), Map(
        "Content-Type", "application/x-www-form-urlencoded",
        "Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language", "ko-KR,ko;q=0.9",
        "Origin", "https://niw.humetro.busan.kr",
        "Referer", pageNumber = 1 ? meta["Referer"] : url))
    EnsureHandyListSuccess(response.Text)
    totalCount := ExtractHandyTotalCount(response.Text, folderName)
    totalPages := Max(1, Ceil(totalCount / 50))
    return {
        Rows: ExtractHandyDocumentRows(response.Text, kind),
        TotalCount: totalCount,
        TotalPages: totalPages,
        PaginationFields: ExtractHandyPaginationFields(response.Text)
    }
}

ExtractHandyTotalCount(html, folderName) {
    pattern := "is)" folderName "\s*\(\s*([\d,]+)\s*\)"
    if RegExMatch(html, pattern, &match)
        return StrReplace(match[1], ",") + 0

    ; 일부 화면은 제목 안에 태그가 섞일 수 있으므로 텍스트로 한 번 더 확인한다.
    plainText := HtmlCellText(html)
    if RegExMatch(plainText, pattern, &match)
        return StrReplace(match[1], ",") + 0
    throw Error(folderName " 문서의 전체 건수를 찾지 못했습니다.")
}

ExtractHandyPaginationFields(html) {
    dq := Chr(34)
    formPattern := "is)<form\b[^>]*(?:id|name)\s*=\s*[" dq "'](?:paginationInfo|aform)[" dq "'][^>]*>(.*?)</form>"
    if !RegExMatch(html, formPattern, &formMatch)
        throw Error("공람 문서 페이지 이동 폼을 찾지 못했습니다.")

    values := Map()
    pos := 1
    while RegExMatch(formMatch[1], "is)<input\b[^>]*>", &inputMatch, pos) {
        tag := inputMatch[0]
        pos := inputMatch.Pos + inputMatch.Len
        name := ExtractHtmlAttribute(tag, "name")
        type := StrLower(ExtractHtmlAttribute(tag, "type"))
        if (name = "" || name = "docinfo" || name = "allCheckBox")
            continue
        if (type = "checkbox" || type = "radio" || type = "button" || type = "submit"
            || type = "image" || type = "file" || type = "reset")
            continue
        values[name] := HtmlEntityDecode(ExtractHtmlAttribute(tag, "value"))
    }

    ; HAR에서 페이지당 건수 선택값은 option에 selected가 없어 요청값을 명시한다.
    values["pageUnit"] := "50"
    if !values.Has("pageIndex")
        values["pageIndex"] := "1"
    if !values.Has("target_page")
        values["target_page"] := "1"
    return values
}

ExtractHandyDocumentRows(html, kind) {
    tbodies := []
    pos := 1
    while RegExMatch(html, "is)<tbody\b[^>]*>(.*?)</tbody>", &bodyMatch, pos) {
        tbodies.Push(bodyMatch[1])
        pos := bodyMatch.Pos + bodyMatch.Len
    }
    if (tbodies.Length < 2)
        throw Error("핸디웨어 문서 목록 영역을 찾지 못했습니다.")

    rows := []
    pos := 1
    while RegExMatch(tbodies[2], "is)<tr\b[^>]*>(.*?)</tr>", &rowMatch, pos) {
        rowHtml := rowMatch[1]
        pos := rowMatch.Pos + rowMatch.Len
        if !RegExMatch(rowHtml, "is)<a\b")
            continue

        cells := []
        cellPos := 1
        while RegExMatch(rowHtml, "is)<td\b[^>]*>(.*?)</td>", &cellMatch, cellPos) {
            cells.Push(HtmlCellText(cellMatch[1]))
            cellPos := cellMatch.Pos + cellMatch.Len
        }
        if (cells.Length < 9)
            continue

        rows.Push({
            Status: cells[1],
            DocumentType: cells[2],
            Title: cells[3],
            OriginalDrafter: cells[4],
            Drafter: cells[5],
            DraftDate: cells[6],
            FinalApprover: cells[7],
            Circulator: cells[8],
            CirculationDate: cells[9],
            ViewData: ExtractHandyViewData(rowHtml)
        })
    }
    return rows
}

ExtractHandyViewData(rowHtml) {
    if !RegExMatch(rowHtml, "is)<input\b[^>]*\bname\s*=\s*[" Chr(34) "']docinfo[" Chr(34) "'][^>]*>", &inputMatch)
        return Map()
    docInfo := HtmlEntityDecode(ExtractHtmlAttribute(inputMatch[0], "value"))
    if (docInfo = "")
        return Map()

    if !RegExMatch(rowHtml, "is)doCallClientApp\s*\((.*?)\)", &callMatch)
        return Map()
    quoted := []
    pos := 1
    while RegExMatch(callMatch[1], "is)([" Chr(34) "'])(.*?)\1", &argMatch, pos) {
        quoted.Push(HtmlEntityDecode(argMatch[2]))
        pos := argMatch.Pos + argMatch.Len
    }
    if (quoted.Length < 3)
        return Map()

    return Map(
        "Fields", StrSplit(docInfo, ","),
        "DocumentIndexId", quoted[1],
        "DocumentIndex", quoted[2],
        "MenuId", quoted[3]
    )
}

EnsureHandyPageNotExpired(html) {
    if RegExMatch(html, "is)<title[^>]*>\s*세션\s*에러\s*</title>")
        throw Error("HANDY_SESSION_EXPIRED")
}

EnsureHandyListSuccess(html) {
    EnsureHandyPageNotExpired(html)
    if !RegExMatch(html, "is)<tbody\b")
        throw Error("핸디웨어 목록 HTML 형식이 예상과 다릅니다.")
}

ExtractHandyFolder(treeHtml, label, expectedAppId) {
    dq := Chr(34)
    pattern := "is)new\s+WebFXTreeItem\(\s*" dq label dq "\s*,\s*" dq "([^" dq "]+)" dq
        . "\s*,\s*" dq "([^" dq "]+)" dq
    if !RegExMatch(treeHtml, pattern, &match)
        throw Error(label " 폴더를 찾지 못했습니다.")

    nodeParts := StrSplit(match[2], ",")
    if (nodeParts.Length < 4 || Trim(nodeParts[3]) != expectedAppId)
        throw Error(label " 폴더 메타데이터가 예상과 다릅니다.")
    return Map("Id", match[1], "AppId", Trim(nodeParts[3]), "Type", Trim(nodeParts[4]))
}

ExtractHiddenInputs(html) {
    values := Map()
    pos := 1
    while RegExMatch(html, "is)<input\b[^>]*>", &match, pos) {
        tag := match[0]
        name := ExtractHtmlAttribute(tag, "name")
        if (name != "")
            values[name] := HtmlEntityDecode(ExtractHtmlAttribute(tag, "value"))
        pos := match.Pos + match.Len
    }
    return values
}

ExtractHtmlAttribute(tag, name) {
    dq := Chr(34)
    if RegExMatch(tag, "is)\b" name "\s*=\s*" dq "([^" dq "]*)" dq, &match)
        return match[1]
    if RegExMatch(tag, "is)\b" name "\s*=\s*'([^']*)'", &match)
        return match[1]
    return ""
}

ExtractJsString(html, name) {
    dq := Chr(34)
    pattern := "is)(?:var\s+)?" name "\s*=\s*([" dq "'])(.*?)\1\s*;"
    return RegExMatch(html, pattern, &match) ? HtmlEntityDecode(match[2]) : ""
}

RequireJsString(html, name) {
    value := ExtractJsString(html, name)
    if (value = "")
        throw Error("핸디웨어 동적 값 '" name "'을 찾지 못했습니다.")
    return value
}

BuildFormBody(values) {
    output := ""
    for key, value in values
        output .= (output = "" ? "" : "&") UrlEncode(key) "=" UrlEncode(value)
    return output
}

EpochMilliseconds() {
    return DateDiff(A_NowUTC, "19700101000000", "Seconds") * 1000 + Mod(A_TickCount, 1000)
}

JavaScriptEscape(value) {
    output := ""
    Loop Parse value {
        code := Ord(A_LoopField)
        if ((code >= 0x30 && code <= 0x39) || (code >= 0x41 && code <= 0x5A)
            || (code >= 0x61 && code <= 0x7A) || InStr("@*_+-./", A_LoopField))
            output .= A_LoopField
        else if (code <= 0xFF)
            output .= "%" Format("{:02X}", code)
        else
            output .= "%u" Format("{:04X}", code)
    }
    return output
}

HtmlEntityDecode(value) {
    value := StrReplace(value, "&nbsp;", " ")
    value := StrReplace(value, "&#160;", " ")
    value := StrReplace(value, "&amp;", "&")
    value := StrReplace(value, "&quot;", Chr(34))
    value := StrReplace(value, "&#39;", "'")
    value := StrReplace(value, "&lt;", "<")
    value := StrReplace(value, "&gt;", ">")
    return value
}

HtmlCellText(html) {
    originalHtml := html
    html := RegExReplace(html, "is)<script\b[^>]*>.*?</script>", "")
    html := RegExReplace(html, "is)<style\b[^>]*>.*?</style>", "")
    html := RegExReplace(html, "is)<br\s*/?>", " ")
    html := RegExReplace(html, "is)<[^>]+>", " ")
    html := HtmlEntityDecode(html)
    html := RegExReplace(html, "\s+", " ")
    html := Trim(html)
    if (html = "") {
        fallback := ExtractHtmlAttribute(originalHtml, "title")
        if (fallback = "")
            fallback := ExtractHtmlAttribute(originalHtml, "alt")
        html := HtmlEntityDecode(fallback)
    }
    return Trim(html)
}

GetSecretPath() {
    candidates := [A_ScriptDir "\secret.txt", A_ScriptDir "\secret.txt.txt"]
    for candidate in candidates {
        if FileExist(candidate)
            return candidate
    }
    return A_ScriptDir "\secret.txt"
}

ReadSecrets(requireComplete := true) {
    path := GetSecretPath()
    if !FileExist(path) {
        if requireComplete
            throw Error("secret.txt를 스크립트와 같은 폴더에 저장하거나 GUI에서 계정정보를 저장하세요.")
        return Map("사번", "", "1차비번", "", "2차비번", "")
    }

    values := Map()
    text := FileRead(path, "UTF-8")
    for line in StrSplit(text, "`n", "`r") {
        line := Trim(line)
        if (line = "")
            continue
        pos := InStr(line, ":")
        if (pos <= 1)
            continue
        key := Trim(SubStr(line, 1, pos - 1))
        value := Trim(SubStr(line, pos + 1))
        values[key] := value
    }

    for key in ["사번", "1차비번", "2차비번"] {
        if !values.Has(key)
            values[key] := ""
        if requireComplete && values[key] = ""
            throw Error("secret.txt에 '" key ": 값' 항목이 필요합니다.")
    }
    return values
}

LoadSecretsIntoGui() {
    global employeeEdit, password1Edit, password2Edit

    path := GetSecretPath()
    try {
        values := ReadSecrets(false)
        employeeEdit.Value := values["사번"]
        password1Edit.Value := values["1차비번"]
        password2Edit.Value := values["2차비번"]
        LogDebug(FileExist(path) ? "계정정보 파일 불러오기 완료" : "계정정보 파일 없음", FileExist(path) ? "INFO" : "WARN")
    } catch as err {
        LogException(err, "계정정보 파일 읽기 실패")
    }
}

GetSecretsFromGui() {
    global employeeEdit, password1Edit, password2Edit

    values := Map(
        "사번", Trim(employeeEdit.Value),
        "1차비번", password1Edit.Value,
        "2차비번", password2Edit.Value
    )
    for key in ["사번", "1차비번", "2차비번"] {
        if (values[key] = "")
            throw Error("계정 정보의 '" key "' 값을 입력하세요.")
        if InStr(values[key], "`r") || InStr(values[key], "`n")
            throw Error("계정 정보에는 줄바꿈을 입력할 수 없습니다.")
    }
    return values
}

SaveSecretsFromGui(*) {
    tempPath := ""
    try {
        values := GetSecretsFromGui()
        path := GetSecretPath()
        tempPath := path ".tmp"
        content := "사번: " values["사번"] "`r`n"
            . "1차비번: " values["1차비번"] "`r`n"
            . "2차비번: " values["2차비번"] "`r`n"

        if FileExist(tempPath)
            FileDelete(tempPath)
        FileAppend(content, tempPath, "UTF-8")
        FileMove(tempPath, path, true)

        values["1차비번"] := ""
        values["2차비번"] := ""
        content := ""
        LogDebug("계정정보 파일 저장 완료")
        MsgBox("계정정보를 저장했습니다.", "계정정보", "Iconi")
    } catch as err {
        if (tempPath != "" && FileExist(tempPath))
            try FileDelete(tempPath)
        LogException(err, "계정정보 저장 실패")
        MsgBox(err.Message, "계정정보 저장 오류", "Iconx")
    }
}

LogDebug(message, level := "INFO") {
    global DEBUG_LOG
    try {
        safeMessage := StrReplace(StrReplace(message, "`r", " "), "`n", " ")
        ; 혹시 오류 메시지에 인증 관련 key=value가 포함되더라도 값을 남기지 않는다.
        safeMessage := RegExReplace(safeMessage,
            "i)(password|secondpwd|pwd|username|userid|cookie|set-cookie|pmi-sso-return2|\bK)\s*[=:]\s*[^\s,;&]+",
            "$1=[REDACTED]")
        FileAppend(FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss") " [" level "] " safeMessage "`r`n", DEBUG_LOG, "UTF-8")
    }
}

LogException(err, context := "오류") {
    detail := context ": " err.Message
    if (err.What != "")
        detail .= " | 대상=" err.What
    if (err.File != "")
        detail .= " | 파일=" err.File
    if (err.Line != 0)
        detail .= " | 줄=" err.Line
    LogDebug(detail, "ERROR")
}

CloseApplication(*) {
    global activeHttpSession
    if IsObject(activeHttpSession)
        PersistSession(activeHttpSession)
    RestoreHandyImeSubclasses()
    ExitApp()
}

RestorePersistedSession() {
    global SESSION_FILE, activeHttpSession

    if !FileExist(SESSION_FILE)
        return
    try {
        encrypted := FileRead(SESSION_FILE, "RAW")
        serialized := DpapiUnprotect(encrypted)
        session := DeserializeSession(serialized)
        serialized := ""

        if !IsSessionForCurrentAccount(session) {
            LogDebug("저장 세션의 계정이 현재 GUI 계정과 달라 복원하지 않음")
            return
        }
        activeHttpSession := session
        SetLoginStatus(session.HandyReady
            ? "저장 세션 불러옴 · XPlatform/공람 유효성 확인 전"
            : "저장 MIS 세션 불러옴 · 유효성 확인 전")
        LogDebug("DPAPI 저장 세션 복원 완료")
    } catch as err {
        LogException(err, "저장 세션 복원 실패")
    }
}

PersistSession(session) {
    global SESSION_FILE

    if !IsObject(session) || session.EmployeeId = ""
        return
    tempPath := SESSION_FILE ".tmp"
    try {
        serialized := SerializeSession(session)
        encrypted := DpapiProtect(serialized)
        serialized := ""

        if FileExist(tempPath)
            FileDelete(tempPath)
        file := FileOpen(tempPath, "w")
        if !IsObject(file)
            throw Error("세션 임시 파일을 만들지 못했습니다.")
        file.RawWrite(encrypted, encrypted.Size)
        file.Close()
        FileMove(tempPath, SESSION_FILE, true)
        LogDebug("DPAPI 세션 저장 완료")
    } catch as err {
        if (tempPath != "" && FileExist(tempPath))
            try FileDelete(tempPath)
        LogException(err, "세션 저장 실패")
    }
}

DeletePersistedSession() {
    global SESSION_FILE
    try {
        if FileExist(SESSION_FILE)
            FileDelete(SESSION_FILE)
        if FileExist(SESSION_FILE ".tmp")
            FileDelete(SESSION_FILE ".tmp")
        LogDebug("만료된 저장 세션 삭제 완료")
    } catch as err {
        LogException(err, "만료 세션 파일 삭제 실패")
    }
}

SerializeSession(session) {
    lines := ["LA10100_SESSION_V1", "EMP|" EncodeSessionField(session.EmployeeId),
        "READY|" (session.HandyReady ? "1" : "0")]

    for _, cookie in session.Cookies {
        lines.Push("COOKIE|" EncodeSessionField(cookie.Domain)
            . "|" EncodeSessionField(cookie.Path)
            . "|" EncodeSessionField(cookie.Name)
            . "|" EncodeSessionField(cookie.Value)
            . "|" (cookie.Secure ? "1" : "0")
            . "|" (cookie.HostOnly ? "1" : "0"))
    }

    if session.HandyReady && IsObject(session.HandyMeta) {
        meta := session.HandyMeta
        for key in ["K", "UserId", "DeptId", "UserDeptId", "SaveDeptId", "Referer"] {
            if meta.Has(key)
                lines.Push("META|" key "|" EncodeSessionField(meta[key]))
        }
        for folderName in ["Wait", "Complete"] {
            if !meta.Has(folderName)
                continue
            folder := meta[folderName]
            for key in ["Id", "AppId", "Type"] {
                if folder.Has(key)
                    lines.Push("META|" folderName key "|" EncodeSessionField(folder[key]))
            }
        }
    }
    output := ""
    for line in lines
        output .= (output = "" ? "" : "`n") line
    return output
}

DeserializeSession(text) {
    lines := StrSplit(text, "`n", "`r")
    if (lines.Length = 0 || lines[1] != "LA10100_SESSION_V1")
        throw Error("지원하지 않는 저장 세션 형식입니다.")

    session := HttpSession()
    ready := false
    flatMeta := Map()
    Loop lines.Length - 1 {
        line := lines[A_Index + 1]
        parts := StrSplit(line, "|")
        if (parts.Length = 0)
            continue
        switch parts[1] {
            case "EMP":
                if (parts.Length >= 2)
                    session.EmployeeId := DecodeSessionField(parts[2])
            case "READY":
                ready := parts.Length >= 2 && parts[2] = "1"
            case "COOKIE":
                if (parts.Length < 7)
                    continue
                domain := StrLower(DecodeSessionField(parts[2]))
                path := DecodeSessionField(parts[3])
                name := DecodeSessionField(parts[4])
                value := DecodeSessionField(parts[5])
                if !RegExMatch(domain, "i)(^|\.)humetro\.busan\.kr$") || SubStr(path, 1, 1) != "/" || name = ""
                    continue
                session.Cookies[domain "|" path "|" name] := {
                    Name: name,
                    Value: value,
                    Domain: domain,
                    Path: path,
                    Secure: parts[6] = "1",
                    HostOnly: parts[7] = "1"
                }
            case "META":
                if (parts.Length >= 3)
                    flatMeta[parts[2]] := DecodeSessionField(parts[3])
        }
    }

    required := ["K", "UserId", "DeptId", "UserDeptId", "SaveDeptId", "Referer",
        "WaitId", "WaitAppId", "WaitType", "CompleteId", "CompleteAppId", "CompleteType"]
    metaComplete := ready
    for key in required {
        if !flatMeta.Has(key) {
            metaComplete := false
            break
        }
    }
    if metaComplete {
        session.HandyMeta := Map(
            "K", flatMeta["K"],
            "UserId", flatMeta["UserId"],
            "DeptId", flatMeta["DeptId"],
            "UserDeptId", flatMeta["UserDeptId"],
            "SaveDeptId", flatMeta["SaveDeptId"],
            "Referer", flatMeta["Referer"],
            "Wait", Map("Id", flatMeta["WaitId"], "AppId", flatMeta["WaitAppId"], "Type", flatMeta["WaitType"]),
            "Complete", Map("Id", flatMeta["CompleteId"], "AppId", flatMeta["CompleteAppId"], "Type", flatMeta["CompleteType"])
        )
        session.HandyReady := true
    }
    if (session.EmployeeId = "" || session.Cookies.Count = 0)
        throw Error("저장 세션에 필수 정보가 없습니다.")
    return session
}

EncodeSessionField(value) {
    output := ""
    Loop Parse value
        output .= Format("{:08X}", Ord(A_LoopField))
    return output
}

DecodeSessionField(value) {
    if (Mod(StrLen(value), 8) != 0)
        throw Error("저장 세션 필드가 손상되었습니다.")
    output := ""
    fieldCount := StrLen(value) // 8
    Loop fieldCount
        output .= Chr(Integer("0x" SubStr(value, (A_Index - 1) * 8 + 1, 8)))
    return output
}

DpapiProtect(text) {
    byteCount := StrPut(text, "UTF-8") - 1
    input := Buffer(byteCount + 1, 0)
    StrPut(text, input, "UTF-8")
    return DpapiTransform(input, byteCount, true)
}

DpapiUnprotect(encrypted) {
    output := DpapiTransform(encrypted, encrypted.Size, false)
    return StrGet(output.Ptr, output.Size, "UTF-8")
}

DpapiTransform(input, inputSize, protect) {
    blobSize := A_PtrSize = 8 ? 16 : 8
    pointerOffset := A_PtrSize = 8 ? 8 : 4
    inputBlob := Buffer(blobSize, 0)
    outputBlob := Buffer(blobSize, 0)
    NumPut("UInt", inputSize, inputBlob, 0)
    NumPut("Ptr", input.Ptr, inputBlob, pointerOffset)

    functionName := protect ? "Crypt32.dll\CryptProtectData" : "Crypt32.dll\CryptUnprotectData"
    succeeded := DllCall(functionName,
        "Ptr", inputBlob.Ptr,
        "Ptr", 0,
        "Ptr", 0,
        "Ptr", 0,
        "Ptr", 0,
        "UInt", 0x1,
        "Ptr", outputBlob.Ptr,
        "Int")
    if !succeeded
        throw OSError(A_LastError, protect ? "세션 암호화 실패" : "세션 복호화 실패")

    outputSize := NumGet(outputBlob, 0, "UInt")
    outputPointer := NumGet(outputBlob, pointerOffset, "Ptr")
    try {
        output := Buffer(outputSize)
        DllCall("Kernel32.dll\RtlMoveMemory", "Ptr", output.Ptr, "Ptr", outputPointer, "UPtr", outputSize)
        return output
    } finally {
        DllCall("Kernel32.dll\LocalFree", "Ptr", outputPointer, "Ptr")
    }
}

AutoLogin(session, secrets) {
    global BASE_PORTAL, BASE_MIS

    LogDebug("HTTP 자동 로그인 시작")
    loginPage := BASE_PORTAL "/user/login.face?destination=%2Fportal%2F"
    ajaxHeaders := Map(
        "X-Requested-With", "XMLHttpRequest",
        "Referer", loginPage
    )

    session.Request("GET", loginPage)
    LogDebug("포털 로그인 페이지 연결 완료")

    firstJson := "{" JsonPair("userId", secrets["사번"]) "," JsonPair("pwd", secrets["1차비번"]) "}"
    checkUser := session.Request("POST", BASE_PORTAL "/user/checkUser.face", firstJson,
        MergeHeaders(ajaxHeaders, "Content-Type", "application/json;charset=UTF-8"))
    if (Trim(checkUser.Text) != "1")
        throw Error("포털 1차 사용자 확인에 실패했습니다.")
    LogDebug("포털 1차 사용자 확인 성공")

    checkLogin := session.Request("POST", BASE_PORTAL "/user/checkLogin.face", firstJson,
        MergeHeaders(ajaxHeaders, "Content-Type", "application/json;charset=UTF-8"))
    if !RegExMatch(checkLogin.Text, "i)" Chr(34) "str" Chr(34) "\s*:\s*" Chr(34) "success" Chr(34))
        throw Error("포털 1차 비밀번호 확인에 실패했습니다.")
    LogDebug("포털 1차 비밀번호 확인 성공")

    secondJson := "{" JsonPair("userId", secrets["사번"]) "," JsonPair("secondpwd", secrets["2차비번"]) "}"
    secondLogin := session.Request("POST", BASE_PORTAL "/user/secondLoginYn.face", secondJson,
        MergeHeaders(ajaxHeaders, "Content-Type", "application/json;charset=UTF-8"))
    if (Trim(secondLogin.Text) != "1")
        throw Error("포털 2차 비밀번호 확인에 실패했습니다.")
    LogDebug("포털 2차 비밀번호 확인 성공")

    session.Request("POST", BASE_PORTAL "/user/failReset.face", secondJson,
        MergeHeaders(ajaxHeaders, "Content-Type", "application/json;charset=UTF-8"))

    form := "username=" UrlEncode(secrets["사번"])
        . "&userId=" UrlEncode(secrets["사번"])
        . "&password=" UrlEncode(secrets["1차비번"])

    portalResult := session.Request("POST", BASE_PORTAL "/user/loginProcess.face?destination=%2Fportal%2F", form,
        Map(
            "Content-Type", "application/x-www-form-urlencoded",
            "Origin", BASE_PORTAL,
            "Referer", loginPage
        ))
    if !InStr(portalResult.Url, BASE_PORTAL "/portal/")
        throw Error("포털 최종 로그인 페이지에 도달하지 못했습니다.")
    LogDebug("포털 로그인 및 중앙 SSO 진입 성공")

    ; loginProcess의 302를 따라가면 중앙 SSO가 별도의 JSESSIONID를 발급한다.
    ; btcep, sso, mis의 JSESSIONID는 이름만 같으므로 도메인/경로별로 분리 보관해야 한다.
    if !session.HasCookieForUrl("https://sso.humetro.busan.kr/sso/pmi-sso2.jsp", "JSESSIONID")
        throw Error("중앙 SSO 세션을 받지 못했습니다.")
    LogDebug("중앙 SSO 세션 확인 완료")

    session.Request("GET", BASE_MIS "/index.jsp?gv_selSystGubn=LA")
    if !session.HasCookieForUrl(BASE_MIS "/ssoLogin.do", "JSESSIONID")
        throw Error("MIS 세션을 받지 못했습니다.")
    LogDebug("MIS 세션 확인 완료")

    session.Request("GET", BASE_MIS "/xui/install.jsp?gv_selSystGubn=LA")

    ; 이 요청의 리다이렉트 체인은 다음 순서로 진행된다.
    ; MIS -> sso/pmi-sso2.jsp -> MIS?pmi-sso-return2 -> 최종 설치 페이지
    ; 중앙 SSO가 기존 MIS JSESSIONID에 사용자 인증 상태를 연결한다.
    ssoPage := session.Request("GET",
        BASE_MIS "/xui/install/x_installChromeSSO.jsp?gv_selSystGubn=LA&gv_userBrowser=Edg")

    if !RegExMatch(ssoPage.Text, "i)var\s+userId\s*=\s*'([^']*)'", &match)
        throw Error("MIS SSO 응답에서 사용자 식별자를 찾지 못했습니다.")
    if (Trim(match[1]) != Trim(secrets["사번"]))
        throw Error("MIS SSO 사용자 식별자가 로그인 계정과 일치하지 않습니다.")
    LogDebug("MIS SSO 사용자 일치 확인 완료")

    initResponse := session.Request("POST", BASE_MIS "/ssoLogin.do", BuildSsoLoginXml(secrets["사번"]),
        Map("Content-Type", "text/xml;charset=UTF-8"))
    EnsureXpSuccess(initResponse.Text, true)
    LogDebug("MIS XPlatform 세션 초기화 성공")
}

QueryViaSession(session, startDate, endDate) {
    global BASE_MIS
    LogDebug("HTTP 세션으로 LA10100.searchExcel 요청")
    response := session.Request("POST", BASE_MIS "/selectList.do", BuildQueryXml(startDate, endDate),
        Map("Content-Type", "text/xml;charset=UTF-8"))
    return response.Text
}

QueryViaWinInet(startDate, endDate) {
    global BASE_MIS
    LogDebug("WinINet 기존 세션으로 LA10100.searchExcel 요청")
    http := ComObject("MSXML2.XMLHTTP.6.0")
    http.Open("POST", BASE_MIS "/selectList.do", false)
    http.SetRequestHeader("Content-Type", "text/xml;charset=UTF-8")
    http.Send(BuildQueryXml(startDate, endDate))
    if (http.Status != 200)
        throw Error("기존 MIS 세션 조회 HTTP 오류: " http.Status)
    return http.ResponseText
}

BuildSsoLoginXml(employeeId) {
    trans := BuildTransInfo("ssoLogin", "ssoLogin.do", "ds_in", "ds_out3", true)
    input := "<Dataset id=" Q("ds_in") ">"
        . "<ColumnInfo>"
        . BuildColumn("IN_USERID") BuildColumn("IN_PASSWORD") BuildColumn("IN_CERT_NUMB")
        . "</ColumnInfo><Rows><Row type=" Q("insert") ">"
        . "<Col id=" Q("IN_USERID") ">" XmlEscape(employeeId) "</Col>"
        . "</Row></Rows></Dataset>"
    return XpRoot(BuildParameters(Map("queryId", "login.userSSOSelect")) trans input)
}

BuildQueryXml(startDate, endDate) {
    params := Map(
        "queryId", "LA10100.searchExcel",
        "IN_START_DATE", startDate,
        "IN_END_DATE", endDate,
        "IN_LINE_CODE", "",
        "IN_STST_CODE", "",
        "IN_FNST_CODE", "",
        "IN_REQU_BSCD", "",
        "IN_WORK_CODE", "",
        "IN_STUS", ""
    )
    ; 입력 Dataset은 없지만 XPlatform transaction()과 같은 빈 전송정보 Dataset을 포함한다.
    trans := BuildTransInfo("searchExcel", "selectList.do", "", "", false)
    return XpRoot(BuildParameters(params) trans)
}

BuildTransInfo(serviceId, url, inputName, outputName, includeRow) {
    xml := "<Dataset id=" Q("__DS_TRANS_INFO__") "><ColumnInfo>"
        . BuildColumn("strSvcID") BuildColumn("strURL")
        . BuildColumn("strInDatasets") BuildColumn("strOutDatasets")
        . "</ColumnInfo><Rows>"
    if includeRow {
        xml .= "<Row type=" Q("insert") ">"
            . "<Col id=" Q("strSvcID") ">" XmlEscape(serviceId) "</Col>"
            . "<Col id=" Q("strURL") ">" XmlEscape(url) "</Col>"
            . "<Col id=" Q("strInDatasets") ">" XmlEscape(inputName) "</Col>"
            . "<Col id=" Q("strOutDatasets") ">" XmlEscape(outputName) "</Col>"
            . "</Row>"
    }
    return xml "</Rows></Dataset>"
}

BuildColumn(id) {
    return "<Column id=" Q(id) " type=" Q("STRING") " size=" Q("256") "/>"
}

BuildParameters(values) {
    xml := "<Parameters>"
    for key, value in values
        xml .= "<Parameter id=" Q(key) ">" XmlEscape(value) "</Parameter>"
    return xml "</Parameters>"
}

XpRoot(innerXml) {
    global XP_NAMESPACE
    return "<?xml version=" Q("1.0") " encoding=" Q("UTF-8") "?>"
        . "<Root xmlns=" Q(XP_NAMESPACE) " ver=" Q("5000") ">"
        . innerXml "</Root>"
}

EnsureXpSuccess(xmlText, isSsoInit := false) {
    doc := LoadXml(xmlText)
    codeNode := doc.SelectSingleNode("//*[local-name()='Parameter' and @id='ErrorCode']")
    msgNode := doc.SelectSingleNode("//*[local-name()='Parameter' and @id='ErrorMsg']")
    if !codeNode
        throw Error("XPlatform 응답에 ErrorCode가 없습니다.")

    code := Trim(codeNode.Text)
    message := msgNode ? Trim(msgNode.Text) : "알 수 없는 오류"
    if (code = "0")
        return
    if (code = "-99999")
        throw Error("MIS 세션이 없거나 만료되었습니다.")
    if isSsoInit && InStr(message, "통합 로그인")
        throw Error("MIS 통합 SSO 초기화에 실패했습니다.")
    throw Error("XPlatform 오류 " code ": " message)
}

ExtractMatches(xmlText, driverName, partial) {
    doc := LoadXml(xmlText)
    rows := doc.SelectNodes("//*[local-name()='Dataset' and @id='ds_out']/*[local-name()='Rows']/*[local-name()='Row']")
    items := []

    for row in rows {
        values := Map()
        cols := row.SelectNodes("*[local-name()='Col']")
        for col in cols
            values[col.GetAttribute("id")] := col.Text

        actualName := Trim(GetMap(values, "DRIV_NAME"))
        matched := partial ? InStr(StrLower(actualName), StrLower(driverName)) > 0
            : StrLower(actualName) = StrLower(driverName)
        if !matched
            continue

        items.Push({
            Dept: GetMap(values, "CNAP_BSNM"),
            Approver: GetMap(values, "CNAP_NAME"),
            ApprovalNo: GetMap(values, "APPR_NUMB"),
            WorkType: GetMap(values, "WORK_CODE"),
            Details: GetMap(values, "PRMT_CTNT")
        })
    }
    return {Total: rows.Length, Items: items}
}

LoadXml(text) {
    text := LTrim(text, Chr(0xFEFF))
    doc := ComObject("MSXML2.DOMDocument.6.0")
    doc.Async := false
    doc.ValidateOnParse := false
    if !doc.LoadXML(text)
        throw Error("XML 응답을 해석하지 못했습니다.")
    return doc
}

GetMap(values, key) {
    return values.Has(key) ? values[key] : ""
}

Q(value) {
    return Chr(34) value Chr(34)
}

XmlEscape(value) {
    value := StrReplace(value, "&", "&amp;")
    value := StrReplace(value, "<", "&lt;")
    value := StrReplace(value, ">", "&gt;")
    value := StrReplace(value, Chr(34), "&quot;")
    return StrReplace(value, "'", "&apos;")
}

JsonPair(key, value) {
    return JsonQuote(key) ":" JsonQuote(value)
}

JsonQuote(value) {
    slash := Chr(92)
    value := StrReplace(value, slash, slash slash)
    value := StrReplace(value, Chr(34), slash Chr(34))
    value := StrReplace(value, "`r", slash "r")
    value := StrReplace(value, "`n", slash "n")
    value := StrReplace(value, "`t", slash "t")
    return Chr(34) value Chr(34)
}

UrlEncode(value) {
    byteCount := StrPut(value, "UTF-8")
    utf8Buffer := Buffer(byteCount)
    StrPut(value, utf8Buffer, "UTF-8")
    output := ""
    Loop byteCount - 1 {
        byte := NumGet(utf8Buffer, A_Index - 1, "UChar")
        if ((byte >= 0x30 && byte <= 0x39)
            || (byte >= 0x41 && byte <= 0x5A)
            || (byte >= 0x61 && byte <= 0x7A)
            || byte = 0x2D || byte = 0x2E || byte = 0x5F || byte = 0x7E)
            output .= Chr(byte)
        else
            output .= "%" Format("{:02X}", byte)
    }
    return output
}

MergeHeaders(source, name, value) {
    merged := Map()
    for key, item in source
        merged[key] := item
    merged[name] := value
    return merged
}

class HttpSession {
    __New() {
        this.Cookies := Map()
        this.EmployeeId := ""
        this.HandyReady := false
        this.HandyMeta := Map()
        this.Http := ComObject("WinHttp.WinHttpRequest.5.1")
        this.Http.Option[3] := false  ; WinHTTP 자동 쿠키 교환을 끄고 직접 관리한다.
        this.Http.Option[4] := 13056  ; 사내 인증서 체인 오류 허용
        this.UserAgent := "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            . "(KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0"
    }

    Request(method, url, body := "", headers := 0, maxRedirects := 12) {
        if !IsObject(headers)
            headers := Map()

        currentMethod := StrUpper(method)
        currentUrl := url
        currentBody := body
        currentHeaders := headers

        Loop maxRedirects + 1 {
            uri := this.ParseUrl(currentUrl)
            if !this.AllowedHost(uri.Host)
                throw Error("허용되지 않은 호스트 요청을 차단했습니다: " uri.Host)

            LogDebug("HTTP 요청: " currentMethod " " uri.Host uri.Path)

            http := this.Http
            http.Open(currentMethod, currentUrl, false)
            http.Option[6] := false
            http.SetTimeouts(15000, 15000, 30000, 120000)
            http.SetRequestHeader("User-Agent", this.UserAgent)
            http.SetRequestHeader("Accept", "*/*")

            cookieHeader := this.BuildCookieHeader(uri)
            if (cookieHeader != "")
                http.SetRequestHeader("Cookie", cookieHeader)
            for name, value in currentHeaders
                http.SetRequestHeader(name, value)

            if (currentMethod = "GET" || currentMethod = "HEAD")
                http.Send()
            else
                http.Send(currentBody)

            status := http.Status
            this.CaptureCookies(uri, http.GetAllResponseHeaders())
            LogDebug("HTTP 응답: " status " " uri.Host uri.Path)

            if (status = 301 || status = 302 || status = 303 || status = 307 || status = 308) {
                try location := http.GetResponseHeader("Location")
                catch
                    throw Error("리다이렉트 Location 헤더가 없습니다.")
                currentUrl := this.ResolveUrl(currentUrl, location)
                redirectUri := this.ParseUrl(currentUrl)
                LogDebug("HTTP 리다이렉트: " status " -> " redirectUri.Host redirectUri.Path)
                if (status = 303 || ((status = 301 || status = 302) && currentMethod = "POST")) {
                    currentMethod := "GET"
                    currentBody := ""
                }
                ; Origin/Referer/Content-Type을 다른 호스트로 전달하지 않는다.
                currentHeaders := Map()
                continue
            }

            if (status < 200 || status >= 400)
                throw Error("HTTP 오류 " status ": " uri.Host uri.Path)

            return {Status: status, Text: http.ResponseText, Url: currentUrl}
        }
        throw Error("리다이렉트 횟수 제한을 초과했습니다.")
    }

    AllowedHost(host) {
        host := StrLower(host)
        return host = "humetro.busan.kr"
            || this.DomainMatches(host, "humetro.busan.kr")
    }

    ParseUrl(url) {
        if !RegExMatch(url, "i)^(https?)://([^/:?#]+)(?::\d+)?([^?#]*)", &m)
            throw Error("올바르지 않은 URL입니다.")
        path := m[3] = "" ? "/" : m[3]
        return {Scheme: StrLower(m[1]), Host: StrLower(m[2]), Path: path}
    }

    CaptureCookies(uri, allHeaders) {
        for line in StrSplit(allHeaders, "`n", "`r") {
            if RegExMatch(line, "i)^Set-Cookie:\s*(.*)$", &m)
                this.StoreCookie(uri, m[1])
        }
    }

    StoreCookie(uri, rawCookie) {
        parts := StrSplit(rawCookie, ";")
        first := Trim(parts[1])
        equals := InStr(first, "=")
        if (equals <= 1)
            return

        name := Trim(SubStr(first, 1, equals - 1))
        value := SubStr(first, equals + 1)
        domain := uri.Host
        hostOnly := true
        path := this.DefaultCookiePath(uri.Path)
        secure := false
        deleteCookie := false

        Loop parts.Length - 1 {
            attribute := Trim(parts[A_Index + 1])
            pos := InStr(attribute, "=")
            attrName := StrLower(Trim(pos ? SubStr(attribute, 1, pos - 1) : attribute))
            attrValue := pos ? Trim(SubStr(attribute, pos + 1)) : ""
            switch attrName {
                case "domain":
                    domain := StrLower(LTrim(attrValue, "."))
                    hostOnly := false
                case "path":
                    if (SubStr(attrValue, 1, 1) = "/")
                        path := attrValue
                case "secure": secure := true
                case "max-age":
                    if (attrValue = "0")
                        deleteCookie := true
            }
        }

        if !this.DomainMatches(uri.Host, domain)
            return
        key := domain "|" path "|" name
        if deleteCookie {
            if this.Cookies.Has(key)
                this.Cookies.Delete(key)
            return
        }
        this.Cookies[key] := {
            Name: name, Value: value, Domain: domain, Path: path,
            Secure: secure, HostOnly: hostOnly
        }
    }

    HasCookieForUrl(url, name) {
        uri := this.ParseUrl(url)
        for _, cookie in this.Cookies {
            if (cookie.Name != name)
                continue
            domainOk := cookie.HostOnly
                ? uri.Host = cookie.Domain
                : this.DomainMatches(uri.Host, cookie.Domain)
            if (domainOk
                && InStr(uri.Path, cookie.Path, true, 1) = 1
                && (!cookie.Secure || uri.Scheme = "https"))
                return true
        }
        return false
    }

    HasCookieAtPath(domain, path, name) {
        domain := StrLower(domain)
        for _, cookie in this.Cookies {
            if (StrLower(cookie.Domain) = domain && cookie.Path = path && cookie.Name = name)
                return true
        }
        return false
    }

    BuildCookieHeader(uri) {
        eligible := []
        for _, cookie in this.Cookies {
            domainOk := cookie.HostOnly
                ? uri.Host = cookie.Domain
                : this.DomainMatches(uri.Host, cookie.Domain)
            if !domainOk || InStr(uri.Path, cookie.Path, true, 1) != 1 || (cookie.Secure && uri.Scheme != "https")
                continue

            insertAt := eligible.Length + 1
            for index, existing in eligible {
                if (StrLen(cookie.Path) > StrLen(existing.Path)) {
                    insertAt := index
                    break
                }
            }
            eligible.InsertAt(insertAt, cookie)
        }

        output := ""
        for cookie in eligible {
            if (output != "")
                output .= "; "
            output .= cookie.Name "=" cookie.Value
        }
        return output
    }

    DefaultCookiePath(requestPath) {
        slash := InStr(requestPath, "/",, -1)
        return slash <= 1 ? "/" : SubStr(requestPath, 1, slash)
    }

    DomainMatches(host, domain) {
        if (host = domain)
            return true
        difference := StrLen(host) - StrLen(domain)
        return difference > 0
            && SubStr(host, difference + 1) = domain
            && SubStr(host, difference, 1) = "."
    }

    ResolveUrl(baseUrl, location) {
        location := Trim(location)
        if RegExMatch(location, "i)^https?://")
            return location

        base := this.ParseUrl(baseUrl)
        origin := base.Scheme "://" base.Host
        if (SubStr(location, 1, 2) = "//")
            return base.Scheme ":" location
        if (SubStr(location, 1, 1) = "/")
            return origin location

        slash := InStr(base.Path, "/",, -1)
        directory := slash ? SubStr(base.Path, 1, slash) : "/"
        return origin directory location
    }
}
