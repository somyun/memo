# 메모 데이터 변경 시 위젯 즉시 갱신 (Trigger)

메모 데이터가 Firestore에 저장, 수정, 또는 삭제될 때 Jetpack Glance 위젯을 수동으로 트리거하여 즉시 반영되도록 구현합니다.

## User Review Required

- **갱신 방식**: 성능 최적화(방법 B)를 위해 수정된 메모 ID와 위젯이 참조하는 메모 ID를 비교하여 필요한 위젯만 갱신하는 방식을 제안합니다. 다만, 삭제 시에는 어떤 위젯이 해당 메모를 보고 있었는지 알기 어려우므로 전체 업데이트를 병행합니다.
- **적용 위치**: `MemoRepository`에 통합하여 데이터 변경과 위젯 갱신 로직을 한 곳에서 관리하는 것이 유지보수에 유리하다고 판단했습니다.

## Proposed Changes

### [Core Data Layer]

데이터 변경 시 위젯 업데이트를 수행하는 유틸리티 메서드를 추가하고, Repository 내의 저장/삭제 로직에서 이를 호출합니다.

#### [MemoRepository.kt](file:///C:/Users/Jinny/Documents/memo-android/app/src/main/java/com/somyun/memo/data/MemoRepository.kt)

- `updateWidgets` 메서드 추가 (GlanceAppWidgetManager 사용)
- `saveMemo` 및 `deleteMemo` 완료 후 `updateWidgets` 호출

```kotlin
// 추가되는 유틸리티 (Repository 내부 혹은 별도 클래스)
private suspend fun updateWidgets(context: android.content.Context, memoId: String? = null) {
    val manager = androidx.glance.appwidget.GlanceAppWidgetManager(context)
    val glanceIds = manager.getGlanceIds(com.somyun.memo.widget.MemoWidget::class.java)
    val prefs = context.getSharedPreferences("widget_prefs", android.content.Context.MODE_PRIVATE)

    for (id in glanceIds) {
        val appWidgetId = manager.getAppWidgetId(id)
        val widgetMemoId = prefs.getString("widget_memo_id_$appWidgetId", null)

        // memoId가 null이면 전체 갱신(삭제 시),
        // memoId가 지정되어 있으면 해당 메모를 표시 중인 위젯만 갱신
        if (memoId == null || widgetMemoId == memoId) {
            com.somyun.memo.widget.MemoWidget().update(context, id)
        }
    }
}
```

---

### [UI / ViewModel Layer]

ViewModel과 ShareReceiverActivity는 이미 Repository를 사용하고 있으므로, Repository의 변경사항을 통해 자연스럽게 위젯이 업데이트됩니다.

#### [MemoViewModel.kt](file:///C:/Users/Jinny/Documents/memo-android/app/src/main/java/com/somyun/memo/ui/MemoViewModel.kt)

- `saveMemo` 호출 시 `applicationContext`를 전달할 수 있도록 Repository 메서드 시그니처 수정이 필요할 수 있습니다. (혹은 Repository가 Context를 주입받도록 변경)

#### [ShareReceiverActivity.kt](file:///C:/Users/Jinny/Documents/memo-android/app/src/main/java/com/somyun/memo/ShareReceiverActivity.kt)

- Repository의 `saveMemo` 호출 시 위젯 갱신이 자동으로 일어납니다.

## Verification Plan

### Manual Verification
1. **메모 수정**: 앱에서 메모 텍스트를 수정하고 1.4초 후(debounce) 홈 화면의 위젯이 즉시 바뀌는지 확인.
2. **이미지/파일 첨부**: 앱 또는 공유 기능을 통해 파일을 첨부했을 때 위젯의 '마지막 수정 시간'이 갱신되는지 확인.
3. **메모 삭제**: 위젯에 표시 중인 메모를 앱에서 삭제했을 때 위젯이 초기 상태('메모를 선택하세요' 또는 최근 메모)로 돌아가는지 확인.
