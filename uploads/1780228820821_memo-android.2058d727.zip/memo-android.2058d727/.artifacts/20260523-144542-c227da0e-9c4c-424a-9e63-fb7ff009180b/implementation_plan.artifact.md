# Fix Crash During Fast Typing

The app crashes when typing memo content quickly. The crash is caused by an `IllegalArgumentException` in the `scrollToCursor` function when it tries to calculate the cursor rectangle using an outdated `TextLayoutResult`. Additionally, frequent list reordering while typing contributes to UI instability.

## User Review Required

- **Debounced Sorting**: I plan to change the `MemoViewModel` so that it doesn't update the `updated` timestamp on every keystroke. This prevents the memo from jumping to the top of the list while the user is still typing. The memo will move to the top only after the user stops typing for 1.4 seconds (when the save operation occurs).

## Proposed Changes

### UI Components

#### [MemoListScreen.kt](file:///C:/Users/Jinny/Documents/memo-android/app/src/main/java/com/somyun/memo/ui/MemoListScreen.kt)

- Add bounds checking and `try-catch` in `scrollToCursor` to prevent crashes when `textLayoutResult` is out of sync with the current cursor position.
- Ensure that the cursor offset used for calculation does not exceed the text length known by the current `layoutResult`.

```kotlin
    val scrollToCursor = {
        coroutineScope.launch {
            delay(100)
            val layoutResult = textLayoutResult
            if (layoutResult != null) {
                // Ensure offset is within bounds of the layoutResult text
                val currentTextLength = layoutResult.layoutInput.text.length
                val cursorOffset = textFieldValue.selection.end.coerceIn(0, currentTextLength)

                try {
                    val cursorRect = layoutResult.getCursorRect(cursorOffset)
                    // ... existing scroll logic ...
                } catch (e: Exception) {
                    Log.e("MemoCard", "Failed to get cursor rect: ${e.message}")
                }
            }
        }
    }
```

---

### Logic & Data

#### [MemoViewModel.kt](file:///C:/Users/Jinny/Documents/memo-android/app/src/main/java/com/somyun/memo/ui/MemoViewModel.kt)

- Modify `updateMemoText` to not update the `updated` timestamp immediately.
- Update the `updated` timestamp only inside `debounceSave` right before saving to Firestore.
- This prevents the memo from jumping positions in the sorted list on every character typed.

```kotlin
    fun updateMemoText(memo: Memo, newText: String) {
        val updated = memo.copy(text = newText) // Don't change 'updated' here
        updateLocalMemo(updated)
        debounceSave(updated)
    }

    private fun debounceSave(memo: Memo) {
        saveJob?.cancel()
        setStatus("저장 중...")
        saveJob = viewModelScope.launch {
            delay(1400)
            val finalMemo = memo.copy(updated = System.currentTimeMillis()) // Update timestamp on save
            repository.saveMemo(finalMemo)
            setStatus("저장됨")
            clearStatusAfterDelay()
        }
    }
```

---

## Verification Plan

### Automated Tests
- Run existing unit tests to ensure no regressions:
  `./gradlew test`

### Manual Verification
- Deploy the app to a device/emulator.
- Open a memo and type very quickly.
- Verify that the app no longer crashes.
- Verify that the memo does not jump to the top of the list until you stop typing for a short while.
- Verify that the cursor remains visible and the card scrolls correctly if it's large.
