import fs from "node:fs/promises";
import path from "node:path";
import { CdpClient, getTargets, pickKreamPage } from "./cdp_lib.mjs";

function parseArgs(argv) {
  const args = {
    port: 9222,
    productId: null,
    url: null,
    size: null,
    sizeIndex: null,
    quantity: null,
    output: null,
    executeClick: false,
    timeoutMs: 10000,
  };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--port") args.port = Number(argv[++i]);
    else if (arg === "--product-id") args.productId = argv[++i];
    else if (arg === "--url") args.url = argv[++i];
    else if (arg === "--size") args.size = argv[++i];
    else if (arg === "--size-index") args.sizeIndex = Number(argv[++i]);
    else if (arg === "--quantity") args.quantity = Number(argv[++i]);
    else if (arg === "--output") args.output = argv[++i];
    else if (arg === "--timeout-ms") args.timeoutMs = Number(argv[++i]);
    else if (arg === "--execute-click") args.executeClick = true;
  }
  if ((!args.size && !Number.isInteger(args.sizeIndex)) || !Number.isFinite(args.quantity)) {
    throw new Error("Pass --size XS --quantity 1 or --size-index 0 --quantity 1");
  }
  if (!args.executeClick) {
    throw new Error("This script clicks '신청 계속'. Pass --execute-click to confirm the single click.");
  }
  return args;
}

function inventoryUrlFromArgs(args) {
  if (args.url) {
    const url = new URL(args.url);
    if (url.pathname.startsWith("/products/")) {
      url.pathname = url.pathname.replace("/products/", "/inventory/");
    }
    return url.toString();
  }
  if (args.productId) {
    return `https://www.kream.co.kr/inventory/${encodeURIComponent(args.productId)}`;
  }
  return null;
}

function sanitizeHeaders(headers = {}) {
  const blocked = new Set(["authorization", "cookie", "set-cookie", "x-kream-device-id"]);
  const sanitized = {};
  for (const [key, value] of Object.entries(headers)) {
    if (!blocked.has(key.toLowerCase())) sanitized[key] = value;
  }
  return sanitized;
}

function isReviewRequest(url) {
  return url.includes("/api/seller/inventory/stock_request/review");
}

const args = parseArgs(process.argv.slice(2));
const target = pickKreamPage(await getTargets(args.port));
if (!target) {
  console.error("No KREAM page target found.");
  process.exit(1);
}

const cdp = new CdpClient(target.webSocketDebuggerUrl);
const requests = new Map();
const reviewResponses = [];

await cdp.open();

try {
  await cdp.send("Page.enable");
  await cdp.send("Runtime.enable");
  await cdp.send("Network.enable");

  cdp.on("Network.requestWillBeSent", (params) => {
    const url = params.request?.url ?? "";
    if (!isReviewRequest(url)) return;
    requests.set(params.requestId, {
      requestId: params.requestId,
      url,
      method: params.request.method,
      requestHeaders: sanitizeHeaders(params.request.headers),
      postData: params.request.postData ? JSON.parse(params.request.postData) : null,
      wallTime: params.wallTime,
    });
  });

  cdp.on("Network.responseReceived", async (params) => {
    const url = params.response?.url ?? "";
    if (!isReviewRequest(url)) return;
    const request = requests.get(params.requestId) ?? {};
    const item = {
      ...request,
      status: params.response.status,
      statusText: params.response.statusText,
      responseHeaders: sanitizeHeaders(params.response.headers),
      responseBody: null,
    };
    reviewResponses.push({ requestId: params.requestId, item });
  });

  const targetUrl = inventoryUrlFromArgs(args);
  if (targetUrl) {
    await cdp.send("Page.navigate", { url: targetUrl });
    await new Promise((resolve) => setTimeout(resolve, 5000));
  }

  const clickResult = await cdp.evaluate(`new Promise((resolve) => {
    const size = ${JSON.stringify(args.size)};
    const sizeIndex = ${JSON.stringify(args.sizeIndex)};
    const quantity = ${JSON.stringify(args.quantity)};
    const normalize = (text) => String(text || "").replace(/\\s+/g, " ").trim();
    const rowSize = (el) => normalize(el.querySelector(".size")?.innerText || el.innerText);
    const items = Array.from(document.querySelectorAll(".inventory_size_item"));
    const item = Number.isInteger(sizeIndex)
      ? items[sizeIndex]
      : items.find((el) => rowSize(el) === size);
    if (!item) {
      resolve({ ok: false, error: "size_not_found", requestedSize: size, requestedSizeIndex: sizeIndex, available: items.map((el) => rowSize(el)) });
      return;
    }
    const actualSize = rowSize(item);
    const input = item.querySelector("input.counter_quantity_input");
    if (!input) {
      resolve({ ok: false, error: "input_not_found" });
      return;
    }
    input.focus();
    input.value = String(quantity);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    setTimeout(() => {
      const continueEl = Array.from(document.querySelectorAll("a, button"))
        .find((el) => normalize(el.innerText).includes("신청 계속"));
      if (!continueEl) {
        resolve({ ok: false, error: "continue_not_found" });
        return;
      }
      const before = {
        className: String(continueEl.className || ""),
        disabledAttr: continueEl.hasAttribute("disabled"),
        text: normalize(continueEl.innerText),
      };
      continueEl.click();
      setTimeout(() => {
        const bodyText = normalize(document.body.innerText);
        const toastCandidates = Array.from(document.querySelectorAll("*"))
          .filter((el) => /toast|snackbar|notification|alert|message|layer|modal/i.test(String(el.className || "")) || el.getAttribute("role") === "alert")
          .map((el) => ({
            tag: el.tagName.toLowerCase(),
            text: normalize(el.innerText),
            className: String(el.className || ""),
            role: el.getAttribute("role"),
          }))
          .filter((candidate) => candidate.text)
          .slice(0, 60);
        const nuxt = document.querySelector("#__nuxt")?.__vue_app__?.$nuxt;
        const inventory = nuxt?.$pinia?.state?.value?.inventory;
        resolve({
          ok: true,
          href: location.href,
          size: actualSize,
          quantity,
          buttonBeforeClick: before,
          bodyContainsRestricted: bodyText.includes("신규 보관 신청이 제한된 카테고리의 상품입니다"),
          bodyContainsRateLimit: bodyText.includes("허용된 요청 횟수를 초과했습니다"),
          toastCandidates,
          review: inventory?.review ? {
            id: inventory.review.id,
            total_quantity: inventory.review.total_quantity,
            allowed_payment_methods: inventory.review.allowed_payment_methods,
            hasReturnAddress: Boolean(inventory.review.return_address),
            itemCount: Array.isArray(inventory.review.items) ? inventory.review.items.length : null,
          } : null,
        });
      }, 1800);
    }, 250);
  })`);

  await new Promise((resolve) => setTimeout(resolve, args.timeoutMs));

  for (const response of reviewResponses) {
    try {
      const body = await cdp.send("Network.getResponseBody", { requestId: response.requestId });
      response.item.responseBody = body.base64Encoded ? "[base64 omitted]" : body.body;
    } catch (error) {
      response.item.responseBodyError = String(error);
    }
  }

  const pageState = await cdp.evaluate(`(() => {
    const normalize = (text) => String(text || "").replace(/\\s+/g, " ").trim();
    const text = normalize(document.body?.innerText || "");
    const nuxt = document.querySelector("#__nuxt")?.__vue_app__?.$nuxt;
    const inventory = nuxt?.$pinia?.state?.value?.inventory;
    return {
      href: location.href,
      title: document.title,
      textSample: text.slice(0, 1800),
      bodyContainsRestricted: text.includes("신규 보관 신청이 제한된 카테고리의 상품입니다"),
      bodyContainsRateLimit: text.includes("허용된 요청 횟수를 초과했습니다"),
      review: inventory?.review ? {
        id: inventory.review.id,
        total_quantity: inventory.review.total_quantity,
        allowed_payment_methods: inventory.review.allowed_payment_methods,
        hasReturnAddress: Boolean(inventory.review.return_address),
        itemCount: Array.isArray(inventory.review.items) ? inventory.review.items.length : null,
      } : null,
    };
  })()`);

  const result = {
    capturedAt: new Date().toISOString(),
    targetUrl: targetUrl ?? target.url,
    clickResult,
    reviewRequests: reviewResponses.map((entry) => entry.item),
    pageState,
  };

  if (args.output) {
    const outputPath = path.resolve(args.output);
    await fs.mkdir(path.dirname(outputPath), { recursive: true });
    await fs.writeFile(outputPath, JSON.stringify(result, null, 2), "utf8");
    console.log(`Wrote ${outputPath}`);
  }

  console.log(JSON.stringify(result, null, 2));
} finally {
  await cdp.close();
}
