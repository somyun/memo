(() => {
  const appEl = document.querySelector("#__nuxt") || document.querySelector("[data-v-app]") || document.body.firstElementChild;
  const app = appEl?.__vue_app__;
  const root = app?._instance;

  function cleanValue(value) {
    if (typeof value === "string") return value.length > 160 ? `${value.slice(0, 160)}...` : value;
    if (typeof value === "number" || typeof value === "boolean" || value == null) return value;
    if (Array.isArray(value)) return value.slice(0, 10).map(cleanValue);
    if (typeof value === "function") return "[function]";
    if (typeof value === "object") {
      const out = {};
      for (const key of Object.keys(value).slice(0, 20)) {
        if (/token|cookie|auth|password|secret|session/i.test(key)) continue;
        try {
          out[key] = cleanValue(value[key]);
        } catch {
          out[key] = "[unreadable]";
        }
      }
      return out;
    }
    return String(value);
  }

  function componentName(instance) {
    return instance?.type?.name || instance?.type?.__name || instance?.type?.__file || instance?.vnode?.type?.name || "(anonymous)";
  }

  const nodes = [];
  function walk(instance, depth = 0) {
    if (!instance || nodes.length >= 160) return;
    const name = componentName(instance);
    const props = cleanValue(instance.props || {});
    const setupStateKeys = Object.keys(instance.setupState || {}).filter((key) => !/token|cookie|auth|password|secret|session/i.test(key));
    const dataKeys = Object.keys(instance.data || {}).filter((key) => !/token|cookie|auth|password|secret|session/i.test(key));
    const exposedKeys = instance.exposed ? Object.keys(instance.exposed).filter((key) => !/token|cookie|auth|password|secret|session/i.test(key)) : [];

    const interesting = /inventory|stock|product|counter|size|order|sell|deposit|보관|신청/i.test(
      `${name} ${JSON.stringify(props)} ${setupStateKeys.join(" ")} ${dataKeys.join(" ")}`
    );

    if (interesting || depth < 4) {
      nodes.push({
        depth,
        name,
        props,
        setupStateKeys,
        setupStateSample: cleanValue(Object.fromEntries(setupStateKeys.slice(0, 25).map((key) => [key, instance.setupState[key]]))),
        dataKeys,
        dataSample: cleanValue(Object.fromEntries(dataKeys.slice(0, 25).map((key) => [key, instance.data[key]]))),
        exposedKeys,
      });
    }

    if (instance.subTree?.component) walk(instance.subTree.component, depth + 1);
    const children = instance.subTree?.children;
    if (Array.isArray(children)) {
      for (const child of children) {
        if (child?.component) walk(child.component, depth + 1);
      }
    }
  }

  walk(root);

  return {
    url: location.href,
    hasApp: Boolean(app),
    nodeCount: nodes.length,
    nodes,
  };
})()
