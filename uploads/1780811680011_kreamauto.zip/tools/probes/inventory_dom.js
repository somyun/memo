(() => {
  function visibleText(el) {
    return (el?.innerText || el?.textContent || "").replace(/\s+/g, " ").trim();
  }

  const inputs = Array.from(document.querySelectorAll("input.counter_quantity_input"));
  const rows = inputs.map((input, index) => {
    let node = input;
    const ancestors = [];
    for (let depth = 0; node && depth < 8; depth += 1) {
      ancestors.push({
        depth,
        tag: node.tagName?.toLowerCase(),
        className: String(node.className || ""),
        text: visibleText(node).slice(0, 300),
      });
      node = node.parentElement;
    }

    const row = input.closest("li, .inventory_item, .counter_item, .size_item, .product_item, .item, div");
    return {
      index,
      value: input.value,
      placeholder: input.placeholder,
      disabled: input.disabled,
      className: String(input.className || ""),
      rowText: visibleText(row).slice(0, 300),
      ancestors,
    };
  });

  const continueEl = Array.from(document.querySelectorAll("a, button"))
    .find((el) => visibleText(el).includes("신청 계속"));

  const nuxtData = Array.from(document.scripts)
    .filter((script) => /__NUXT__|application\/json/i.test(script.id + " " + script.type + " " + script.textContent.slice(0, 200)))
    .map((script) => ({
      id: script.id,
      type: script.type,
      textSample: script.textContent.slice(0, 1000),
      length: script.textContent.length,
    }));

  return {
    url: location.href,
    title: document.title,
    inputs: rows,
    continue: continueEl ? {
      tag: continueEl.tagName.toLowerCase(),
      text: visibleText(continueEl),
      className: String(continueEl.className || ""),
      href: continueEl.href || null,
      disabled: continueEl.disabled || continueEl.getAttribute("aria-disabled") === "true",
      outerHTML: continueEl.outerHTML.slice(0, 1000),
    } : null,
    bodyText: visibleText(document.body).slice(0, 1500),
    nuxtData,
  };
})()
