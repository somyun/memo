(() => {
  const terms = [
    "inventory",
    "api/",
    "보관",
    "신청",
    "제한",
    "허용된 요청",
    "신규 보관",
    "storage",
    "warehouse",
    "stock",
  ];

  const script = document.getElementById("__NUXT_DATA__");
  const raw = script ? script.textContent : "";
  let parsed = null;
  try {
    parsed = JSON.parse(raw);
  } catch (error) {
    return { error: String(error), rawLength: raw.length };
  }

  const matches = [];
  const seen = new Set();

  function walk(value, path) {
    if (matches.length >= 500) return;
    if (typeof value === "string") {
      for (const term of terms) {
        if (value.includes(term)) {
          const key = `${path}:${value}`;
          if (!seen.has(key)) {
            seen.add(key);
            matches.push({ path, term, value: value.slice(0, 500) });
          }
          break;
        }
      }
      return;
    }
    if (!value || typeof value !== "object") return;
    if (Array.isArray(value)) {
      value.forEach((item, index) => walk(item, `${path}[${index}]`));
      return;
    }
    for (const [key, item] of Object.entries(value)) {
      walk(item, `${path}.${key}`);
    }
  }

  walk(parsed, "$");

  return {
    rawLength: raw.length,
    matchCount: matches.length,
    matches,
  };
})()
