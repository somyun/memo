(async () => {
  const url = "https://www.kream.co.kr/_nuxt/BHKnEZlV.js";
  const terms = [
    "inventory",
    "stockRequest",
    "quantities",
    "신규 보관",
    "허용된 요청",
    "제한",
    "/api/",
    "deposit",
    "request",
    "continue",
    "quantity",
    "product_option",
  ];

  const content = await (await fetch(url)).text();
  function snippet(index, width = 420) {
    return content.slice(Math.max(0, index - width), Math.min(content.length, index + width)).replace(/\s+/g, " ");
  }

  const matches = [];
  for (const term of terms) {
    let fromIndex = 0;
    let count = 0;
    while (count < 20) {
      const index = content.indexOf(term, fromIndex);
      if (index === -1) break;
      matches.push({ term, index, snippet: snippet(index) });
      fromIndex = index + term.length;
      count += 1;
    }
  }

  const apiPaths = [];
  for (let index = content.indexOf("/api/"); index !== -1; index = content.indexOf("/api/", index + 5)) {
    let start = index;
    let end = index;
    while (start > 0 && !["\"", "'", "`"].includes(content[start - 1])) start -= 1;
    while (end < content.length && !["\"", "'", "`"].includes(content[end])) end += 1;
    apiPaths.push(content.slice(start, end));
  }

  return {
    url,
    size: content.length,
    apiPaths: Array.from(new Set(apiPaths)).slice(0, 100),
    matchCount: matches.length,
    matches,
  };
})()
