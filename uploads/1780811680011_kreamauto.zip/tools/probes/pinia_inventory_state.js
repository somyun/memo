(() => {
  const nuxt = document.querySelector("#__nuxt")?.__vue_app__?.$nuxt;
  const state = nuxt?.$pinia?.state?.value || {};

  function clean(value, depth = 0, seen = new WeakSet()) {
    if (typeof value === "string") return value.length > 300 ? `${value.slice(0, 300)}...` : value;
    if (typeof value === "number" || typeof value === "boolean" || value == null) return value;
    if (typeof value === "function") return "[function]";
    if (Array.isArray(value)) return value.slice(0, 30).map((item) => clean(item, depth + 1, seen));
    if (typeof value === "object") {
      if (seen.has(value)) return "[circular]";
      seen.add(value);
      if (depth >= 4) return `[object:${Object.keys(value).slice(0, 30).join(",")}]`;
      const out = {};
      for (const key of Object.keys(value).slice(0, 120)) {
        if (/token|cookie|auth|password|secret|session/i.test(key)) continue;
        out[key] = clean(value[key], depth + 1, seen);
      }
      return out;
    }
    return String(value);
  }

  return {
    storeKeys: Object.keys(state),
    inventory: clean(state.inventory),
    product: clean(state.product),
    product95: clean(state.product95),
    catalog: clean(state.catalog),
  };
})()
