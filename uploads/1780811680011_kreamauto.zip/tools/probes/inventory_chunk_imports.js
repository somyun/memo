(async () => {
  const url = "https://www.kream.co.kr/_nuxt/BHKnEZlV.js";
  const content = await (await fetch(url)).text();
  const importLines = content
    .slice(0, 2500)
    .split(";")
    .filter((line) => line.includes("from\"./") || line.includes("from './") || line.includes("import"))
    .map((line) => `${line};`);

  const functionSnippets = [];
  for (const term of ["fetchReviewInventory", "updateQuantity", "setQuantities", "totalQuantity", "fetchProductDetail"]) {
    const index = content.indexOf(term);
    functionSnippets.push({
      term,
      index,
      snippet: index >= 0
        ? content.slice(Math.max(0, index - 900), Math.min(content.length, index + 1200)).replace(/\s+/g, " ")
        : null,
    });
  }

  return {
    url,
    size: content.length,
    firstChars: content.slice(0, 2500),
    importLines,
    functionSnippets,
  };
})()
