(async () => {
  const url = "https://www.kream.co.kr/_nuxt/qqIrI4hF.js";
  const terms = [
    "fetchReviewInventory",
    "updateQuantity",
    "setQuantities",
    "totalQuantity",
    "payment",
    "stockRequest",
    "review",
    "inventory",
    "/api/",
    "shipping_memo",
    "product_option",
  ];
  const content = await (await fetch(url)).text();
  function snippet(index, width = 700) {
    return content.slice(Math.max(0, index - width), Math.min(content.length, index + width)).replace(/\s+/g, " ");
  }
  const matches = [];
  for (const term of terms) {
    let fromIndex = 0;
    let count = 0;
    while (count < 30) {
      const index = content.indexOf(term, fromIndex);
      if (index === -1) break;
      matches.push({ term, index, snippet: snippet(index) });
      fromIndex = index + term.length;
      count += 1;
    }
  }
  const apiPaths = [];
  for (let index = content.indexOf("/api/"); index !== -1; index = content.indexOf("/api/", index + 5)) {
    let start = index;
    let end = index;
    while (start > 0 && !["\"", "'", "`"].includes(content[start - 1])) start -= 1;
    while (end < content.length && !["\"", "'", "`"].includes(content[end])) end += 1;
    apiPaths.push(content.slice(start, end));
  }
  return {
    url,
    size: content.length,
    firstChars: content.slice(0, 2500),
    apiPaths: Array.from(new Set(apiPaths)),
    matchCount: matches.length,
    matches,
  };
})()
