(() => {
  function safeString(value) {
    if (typeof value === "string") return value.slice(0, 300);
    if (typeof value === "number" || typeof value === "boolean" || value === null) return value;
    if (Array.isArray(value)) return `[array:${value.length}]`;
    if (value && typeof value === "object") return `[object:${Object.keys(value).slice(0, 20).join(",")}]`;
    return typeof value;
  }

  function summarizeObject(obj, depth = 0, seen = new WeakSet()) {
    if (!obj || typeof obj !== "object") return safeString(obj);
    if (seen.has(obj)) return "[circular]";
    seen.add(obj);
    if (depth >= 2) return safeString(obj);
    const out = {};
    for (const key of Object.keys(obj).slice(0, 80)) {
      if (/token|cookie|auth|password|secret/i.test(key)) continue;
      try {
        out[key] = summarizeObject(obj[key], depth + 1, seen);
      } catch {
        out[key] = "[unreadable]";
      }
    }
    return out;
  }

  const root = document.querySelector("#__nuxt, #__layout, .inventory_box, .inventory_stock_size") || document.body;
  const vueKeys = [];
  let node = root;
  for (let i = 0; node && i < 8; i += 1) {
    vueKeys.push({
      tag: node.tagName?.toLowerCase(),
      className: String(node.className || ""),
      keys: Object.keys(node).filter((key) => key.startsWith("__vue") || key.includes("Vue")),
    });
    node = node.parentElement;
  }

  const allWithVue = Array.from(document.querySelectorAll("*"))
    .map((el) => ({
      tag: el.tagName.toLowerCase(),
      className: String(el.className || ""),
      text: (el.innerText || "").replace(/\s+/g, " ").trim().slice(0, 80),
      keys: Object.keys(el).filter((key) => key.startsWith("__vue") || key.includes("Vue")),
    }))
    .filter((item) => item.keys.length)
    .slice(0, 40);

  const nuxtKeys = Object.keys(window.__NUXT__ || {});
  const nuxtSummary = summarizeObject(window.__NUXT__ || {});

  return {
    url: location.href,
    nuxtKeys,
    nuxtSummary,
    rootVueKeys: vueKeys,
    allWithVue,
  };
})()
