(() => {
  const candidates = Array.from(document.querySelectorAll("*"))
    .filter((el) => el.__vue_app__)
    .map((el) => {
      const app = el.__vue_app__;
      return {
        tag: el.tagName.toLowerCase(),
        id: el.id,
        className: String(el.className || ""),
        text: (el.innerText || "").replace(/\s+/g, " ").trim().slice(0, 120),
        appKeys: Object.keys(app),
        appOwnKeys: Reflect.ownKeys(app).map(String),
        hasInstance: Boolean(app._instance),
        instanceKeys: app._instance ? Object.keys(app._instance) : [],
      };
    });
  return { candidates };
})()
