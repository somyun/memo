(async () => {
  const terms = [
    "inventory",
    "stockRequest",
    "quantities",
    "신규 보관",
    "허용된 요청",
    "제한",
    "/api/",
    "deposit",
    "warehouse",
    "storage",
  ];

  const urls = Array.from(new Set([
    ...Array.from(document.scripts).map((script) => script.src).filter(Boolean),
    ...performance.getEntriesByType("resource").map((entry) => entry.name).filter(Boolean),
  ])).filter((url) => url.includes("/_nuxt/") && url.endsWith(".js"));

  function snippet(content, index, width = 260) {
    return content.slice(Math.max(0, index - width), Math.min(content.length, index + width)).replace(/\s+/g, " ");
  }

  const results = [];
  for (const url of urls) {
    let content = "";
    try {
      const response = await fetch(url);
      content = await response.text();
    } catch (error) {
      results.push({ url, error: String(error) });
      continue;
    }

    const matches = [];
    for (const term of terms) {
      let fromIndex = 0;
      while (matches.length < 40) {
        const index = content.indexOf(term, fromIndex);
        if (index === -1) break;
        matches.push({ term, index, snippet: snippet(content, index) });
        fromIndex = index + term.length;
      }
    }

    if (matches.length) {
      results.push({ url, size: content.length, matches });
    }
  }

  return {
    url: location.href,
    scriptCount: urls.length,
    resultCount: results.length,
    results,
  };
})()
