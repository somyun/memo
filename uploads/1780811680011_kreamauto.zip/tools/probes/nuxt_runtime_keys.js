(() => {
  const app = document.querySelector("#__nuxt")?.__vue_app__;
  const nuxt = app?.$nuxt;
  function summarize(value, depth = 0, seen = new WeakSet()) {
    if (typeof value === "string") return value.slice(0, 200);
    if (typeof value === "number" || typeof value === "boolean" || value == null) return value;
    if (typeof value === "function") return "[function]";
    if (Array.isArray(value)) return `[array:${value.length}]`;
    if (typeof value === "object") {
      if (seen.has(value)) return "[circular]";
      seen.add(value);
      if (depth >= 2) return `[object:${Object.keys(value).slice(0, 20).join(",")}]`;
      const out = {};
      for (const key of Object.keys(value).slice(0, 80)) {
        if (/token|cookie|auth|password|secret|session/i.test(key)) continue;
        try {
          out[key] = summarize(value[key], depth + 1, seen);
        } catch {
          out[key] = "[unreadable]";
        }
      }
      return out;
    }
    return String(value);
  }

  return {
    hasNuxt: Boolean(nuxt),
    nuxtKeys: nuxt ? Object.keys(nuxt) : [],
    nuxtOwnKeys: nuxt ? Reflect.ownKeys(nuxt).map(String) : [],
    nuxtSummary: summarize(nuxt),
  };
})()
