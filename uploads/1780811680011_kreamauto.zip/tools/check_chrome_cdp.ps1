param(
    [int]$Port = 9222
)

$ErrorActionPreference = "Stop"
$baseUrl = "http://127.0.0.1:$Port"

try {
    $version = Invoke-RestMethod -Uri "$baseUrl/json/version" -TimeoutSec 3
    $targets = Invoke-RestMethod -Uri "$baseUrl/json/list" -TimeoutSec 3
} catch {
    Write-Error "CDP connection failed on $baseUrl. Start Chrome with tools/start_kream_chrome.ps1 first. $_"
    exit 1
}

Write-Host "Chrome DevTools Protocol is reachable."
Write-Host "Browser: $($version.Browser)"
Write-Host "Protocol-Version: $($version.'Protocol-Version')"
Write-Host "webSocketDebuggerUrl: $($version.webSocketDebuggerUrl)"
Write-Host ""
Write-Host "Targets:"

foreach ($target in $targets) {
    Write-Host "- $($target.type): $($target.title) [$($target.url)]"
}
