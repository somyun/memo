import fs from "node:fs/promises";
import path from "node:path";
import { CdpClient, getTargets, pickKreamPage } from "./cdp_lib.mjs";

function parseArgs(argv) {
  const args = {
    port: 9222,
    productId: null,
    url: null,
    timeoutMs: 12000,
    output: null,
  };

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--port") args.port = Number(argv[++i]);
    else if (arg === "--product-id") args.productId = argv[++i];
    else if (arg === "--url") args.url = argv[++i];
    else if (arg === "--timeout-ms") args.timeoutMs = Number(argv[++i]);
    else if (arg === "--output") args.output = argv[++i];
  }

  return args;
}

function inventoryUrlFromArgs(args) {
  if (args.url) {
    const url = new URL(args.url);
    if (url.pathname.startsWith("/products/")) {
      url.pathname = url.pathname.replace("/products/", "/inventory/");
    }
    return url.toString();
  }

  if (!args.productId) {
    throw new Error("Pass --product-id 66326 or --url https://www.kream.co.kr/products/66326");
  }

  return `https://www.kream.co.kr/inventory/${encodeURIComponent(args.productId)}`;
}

function sanitizeHeaders(headers = {}) {
  const blocked = new Set(["authorization", "cookie", "set-cookie", "x-kream-device-id"]);
  const sanitized = {};
  for (const [key, value] of Object.entries(headers)) {
    if (!blocked.has(key.toLowerCase())) {
      sanitized[key] = value;
    }
  }
  return sanitized;
}

function isInterestingRequest(url) {
  return /kream\.co\.kr|kream-api|api/i.test(url);
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const targetUrl = inventoryUrlFromArgs(args);
  const targets = await getTargets(args.port);
  const target = pickKreamPage(targets);

  if (!target) {
    throw new Error("No KREAM page target found. Start Chrome first.");
  }

  const cdp = new CdpClient(target.webSocketDebuggerUrl);
  const requests = new Map();
  const responses = [];

  await cdp.open();
  try {
    await cdp.send("Page.enable");
    await cdp.send("Runtime.enable");
    await cdp.send("Network.enable");

    cdp.on("Network.requestWillBeSent", (params) => {
      if (!isInterestingRequest(params.request?.url ?? "")) return;
      requests.set(params.requestId, {
        requestId: params.requestId,
        method: params.request.method,
        url: params.request.url,
        type: params.type,
        wallTime: params.wallTime,
        requestHeaders: sanitizeHeaders(params.request.headers),
        postDataPresent: Boolean(params.request.postData),
      });
    });

    cdp.on("Network.responseReceived", (params) => {
      const request = requests.get(params.requestId);
      if (!request && !isInterestingRequest(params.response?.url ?? "")) return;
      responses.push({
        ...request,
        status: params.response.status,
        statusText: params.response.statusText,
        mimeType: params.response.mimeType,
        responseUrl: params.response.url,
        responseHeaders: sanitizeHeaders(params.response.headers),
      });
    });

    await cdp.send("Page.navigate", { url: targetUrl });
    await new Promise((resolve) => setTimeout(resolve, args.timeoutMs));

    const pageInfo = await cdp.evaluate(`(() => {
      const text = document.body ? document.body.innerText : "";
      const buttons = Array.from(document.querySelectorAll("button"))
        .map((button, index) => ({
          index,
          text: button.innerText.trim(),
          disabled: button.disabled,
          className: String(button.className || ""),
          ariaLabel: button.getAttribute("aria-label"),
          dataAttrs: Array.from(button.attributes)
            .filter((attr) => attr.name.startsWith("data-"))
            .map((attr) => [attr.name, attr.value]),
        }))
        .filter((button) => button.text || button.ariaLabel || /btn|button/i.test(button.className));
      const inputs = Array.from(document.querySelectorAll("input, textarea, select"))
        .map((input, index) => ({
          index,
          tag: input.tagName.toLowerCase(),
          type: input.getAttribute("type"),
          name: input.getAttribute("name"),
          placeholder: input.getAttribute("placeholder"),
          valuePresent: Boolean(input.value),
          disabled: input.disabled,
          readOnly: input.readOnly,
          className: String(input.className || ""),
        }));
      const clickableText = Array.from(document.querySelectorAll("a, button, [role='button'], label"))
        .map((el, index) => ({
          index,
          tag: el.tagName.toLowerCase(),
          text: el.innerText.trim(),
          className: String(el.className || ""),
          href: el.href || null,
        }))
        .filter((item) => item.text)
        .slice(0, 200);
      const toastCandidates = Array.from(document.querySelectorAll("*"))
        .filter((el) => /toast|snackbar|notification|alert|message|layer|modal/i.test(String(el.className || "")) || el.getAttribute("role") === "alert")
        .map((el) => ({
          tag: el.tagName.toLowerCase(),
          text: el.innerText.trim(),
          className: String(el.className || ""),
          role: el.getAttribute("role"),
        }))
        .filter((item) => item.text)
        .slice(0, 50);
      return {
        href: location.href,
        title: document.title,
        readyState: document.readyState,
        textSample: text.slice(0, 2500),
        textLength: text.length,
        hasContinueText: text.includes("신청계속"),
        hasRestrictedCategoryText: text.includes("신규 보관 신청이 제한된 카테고리의 상품입니다"),
        hasRateLimitText: text.includes("허용된 요청 횟수를 초과했습니다"),
        buttons,
        inputs,
        clickableText,
        toastCandidates,
      };
    })()`);

    const result = {
      capturedAt: new Date().toISOString(),
      targetUrl,
      pageInfo,
      network: responses,
    };

    if (args.output) {
      const outputPath = path.resolve(args.output);
      await fs.mkdir(path.dirname(outputPath), { recursive: true });
      await fs.writeFile(outputPath, JSON.stringify(result, null, 2), "utf8");
      console.log(`Wrote ${outputPath}`);
    }

    console.log(JSON.stringify(result, null, 2));
  } finally {
    await cdp.close();
  }
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
