import fs from "node:fs/promises";
import path from "node:path";
import { CdpClient, getTargets, pickKreamPage } from "./cdp_lib.mjs";

function parseArgs(argv) {
  const args = { port: 9222, output: null };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--port") args.port = Number(argv[++i]);
    else if (arg === "--output") args.output = argv[++i];
  }
  return args;
}

async function writeJson(filePath, value) {
  if (!filePath) return;
  const resolved = path.resolve(filePath);
  await fs.mkdir(path.dirname(resolved), { recursive: true });
  await fs.writeFile(resolved, JSON.stringify(value, null, 2), "utf8");
}

const args = parseArgs(process.argv.slice(2));
const target = pickKreamPage(await getTargets(args.port));
if (!target) {
  console.error("No KREAM page target found.");
  process.exit(1);
}

const cdp = new CdpClient(target.webSocketDebuggerUrl);
await cdp.open();

try {
  await cdp.send("Runtime.enable");
  const result = await cdp.evaluate(`(() => {
    const normalize = (text) => String(text || "").replace(/\\s+/g, " ").trim();
    const text = normalize(document.body?.innerText || "");
    const labelFor = (input) => {
      const id = input.getAttribute("id");
      if (id) {
        const explicit = document.querySelector(\`label[for="\${CSS.escape(id)}"]\`);
        if (explicit) return normalize(explicit.innerText);
      }
      const wrappingLabel = input.closest("label");
      if (wrappingLabel) return normalize(wrappingLabel.innerText);
      const row = input.closest("li, .input_box, .input_item, .form_item, .payment_item, .address_item, .item");
      return row ? normalize(row.innerText).slice(0, 120) : "";
    };
    const summarizeInput = (input) => ({
      tag: input.tagName.toLowerCase(),
      type: input.getAttribute("type") || input.tagName.toLowerCase(),
      name: input.getAttribute("name"),
      id: input.getAttribute("id"),
      label: labelFor(input),
      placeholder: input.getAttribute("placeholder"),
      autocomplete: input.getAttribute("autocomplete"),
      disabled: input.disabled || input.hasAttribute("disabled"),
      checked: "checked" in input ? Boolean(input.checked) : null,
      valuePresent: Boolean(input.value),
      valueLength: input.value ? String(input.value).length : 0,
    });
    const summarizeAction = (el) => ({
      tag: el.tagName.toLowerCase(),
      text: normalize(el.innerText || el.getAttribute("aria-label") || el.getAttribute("title")),
      className: String(el.className || ""),
      role: el.getAttribute("role"),
      type: el.getAttribute("type"),
      disabled: el.disabled || el.hasAttribute("disabled") || String(el.className || "").includes("disabled"),
      hrefPath: el.href ? new URL(el.href).pathname : null,
    });
    const headings = Array.from(document.querySelectorAll("h1,h2,h3,h4,.title,.section_title,.sub_title"))
      .map((el) => ({ tag: el.tagName.toLowerCase(), text: normalize(el.innerText), className: String(el.className || "") }))
      .filter((item) => item.text)
      .slice(0, 80);
    const actions = Array.from(document.querySelectorAll("button,a"))
      .map(summarizeAction)
      .filter((item) => item.text)
      .slice(0, 120);
    const inputs = Array.from(document.querySelectorAll("input,select,textarea"))
      .map(summarizeInput)
      .slice(0, 120);
    const nuxt = document.querySelector("#__nuxt")?.__vue_app__?.$nuxt;
    const inventory = nuxt?.$pinia?.state?.value?.inventory;
    const review = inventory?.review;
    const stockRequest = inventory?.stockRequest;
    return {
      capturedAt: new Date().toISOString(),
      href: location.href,
      title: document.title,
      hasReviewPageText: text.includes("신청 내역"),
      hasDepositPaymentButton: text.includes("보증금 결제하기"),
      hasConfirmEndpointText: text.includes("confirm"),
      textSample: text.slice(0, 2200),
      headings,
      actions,
      inputs,
      pinia: {
        review: review ? {
          id: review.id,
          totalQuantity: review.total_quantity,
          deposit: review.deposit,
          totalAmount: review.total_amount,
          allowedPaymentMethods: review.allowed_payment_methods,
          itemCount: Array.isArray(review.items) ? review.items.length : null,
          items: Array.isArray(review.items) ? review.items.map((item) => ({
            productId: item.product_id,
            productName: item.product?.name,
            translatedName: item.product?.translated_name,
            option: item.option,
            quantity: item.quantity,
            productOptionId: item.product_option?.id,
          })) : null,
          hasReturnAddress: Boolean(review.return_address),
          returnAddressKeys: review.return_address ? Object.keys(review.return_address) : [],
          paymentMethod: review.payment_method ?? null,
        } : null,
        stockRequest: stockRequest ? {
          keys: Object.keys(stockRequest),
          id: stockRequest.id ?? null,
          status: stockRequest.status ?? null,
        } : null,
      },
    };
  })()`);

  await writeJson(args.output, result);
  if (args.output) console.log(`Wrote ${path.resolve(args.output)}`);
  console.log(JSON.stringify(result, null, 2));
} finally {
  await cdp.close();
}
