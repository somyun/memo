import fs from "node:fs/promises";
import { CdpClient, getTargets, pickKreamPage } from "./cdp_lib.mjs";

function parseArgs(argv) {
  const args = { port: 9222, expression: null, file: null };
  for (let i = 0; i < argv.length; i += 1) {
    if (argv[i] === "--port") args.port = Number(argv[++i]);
    else if (argv[i] === "--expression") args.expression = argv[++i];
    else if (argv[i] === "--file") args.file = argv[++i];
  }
  return args;
}

const args = parseArgs(process.argv.slice(2));
let expression = args.expression;

if (args.file) {
  expression = await fs.readFile(args.file, "utf8");
}

if (!expression) {
  console.error("Pass --expression or --file.");
  process.exit(1);
}

const target = pickKreamPage(await getTargets(args.port));
if (!target) {
  console.error("No page target found.");
  process.exit(1);
}

const cdp = new CdpClient(target.webSocketDebuggerUrl);
await cdp.open();

try {
  await cdp.send("Runtime.enable");
  const result = await cdp.evaluate(expression);
  console.log(typeof result === "string" ? result : JSON.stringify(result, null, 2));
} finally {
  await cdp.close();
}
