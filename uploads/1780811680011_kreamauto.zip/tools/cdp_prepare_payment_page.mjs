import fs from "node:fs/promises";
import path from "node:path";
import { CdpClient, getTargets, pickKreamPage } from "./cdp_lib.mjs";

function parseArgs(argv) {
  const args = {
    port: 9222,
    output: null,
    clickPayment: false,
    checkAgreements: false,
    waitMs: 2000,
  };

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--port") args.port = Number(argv[++i]);
    else if (arg === "--output") args.output = argv[++i];
    else if (arg === "--wait-ms") args.waitMs = Number(argv[++i]);
    else if (arg === "--click-payment") args.clickPayment = true;
    else if (arg === "--check-agreements") args.checkAgreements = true;
  }

  return args;
}

async function sleep(ms) {
  await new Promise((resolve) => setTimeout(resolve, ms));
}

async function writeJson(filePath, value) {
  if (!filePath) return;
  const resolved = path.resolve(filePath);
  await fs.mkdir(path.dirname(resolved), { recursive: true });
  await fs.writeFile(resolved, JSON.stringify(value, null, 2), "utf8");
}

async function captureState(cdp) {
  return cdp.evaluate(`(() => {
    const normalize = (text) => String(text || "").replace(/\\s+/g, " ").trim();
    const text = normalize(document.body?.innerText || "");
    const summarizeAction = (el) => ({
      tag: el.tagName.toLowerCase(),
      text: normalize(el.innerText || el.getAttribute("aria-label") || el.getAttribute("title")),
      className: String(el.className || ""),
      type: el.getAttribute("type"),
      role: el.getAttribute("role"),
      disabled: el.disabled || el.hasAttribute("disabled") || String(el.className || "").includes("disabled"),
    });
    const actions = Array.from(document.querySelectorAll("button,a"))
      .map(summarizeAction)
      .filter((item) => item.text)
      .slice(0, 120);
    const inputs = Array.from(document.querySelectorAll("input"))
      .map((input) => ({
        type: input.getAttribute("type") || "text",
        checked: "checked" in input ? Boolean(input.checked) : null,
        disabled: input.disabled || input.hasAttribute("disabled"),
        className: String(input.className || ""),
        valuePresent: Boolean(input.value),
      }))
      .slice(0, 120);
    const possibleAgreementRows = Array.from(document.querySelectorAll("label, li, .item, .display_item, .checkbox_item, .agreement"))
      .map((el) => normalize(el.innerText))
      .filter((row) => row.includes("[필수]") || row.includes("동의") || row.includes("확인"))
      .slice(0, 40);
    const agreementInputs = Array.from(document.querySelectorAll("input[type='checkbox']"));
    const readyDepositButtons = actions
      .filter((item) => item.text.includes("보증금 결제하기") && !item.disabled);
    const finalPaymentAction = readyDepositButtons.at(-1)
      || actions.find((item) => /결제|신청/.test(item.text) && !item.disabled);
    return {
      capturedAt: new Date().toISOString(),
      href: location.href,
      title: document.title,
      hasReviewPageText: text.includes("신청 내역"),
      hasDepositPaymentButton: text.includes("보증금 결제하기"),
      hasFinalPaymentText: text.includes("결제하기") && !text.includes("보증금 결제하기"),
      textSample: text
        .replace(/\\d{2,4}-\\d{3,4}-\\d{4}/g, "[phone]")
        .replace(/\\(\\d{5}\\)\\s*[^\\n]+/g, "[address]")
        .slice(0, 2200),
      actions,
      inputs,
      possibleAgreementRows,
      agreementCount: agreementInputs.length,
      checkedAgreementCount: agreementInputs.filter((input) => input.checked).length,
      readyDepositButtons,
      finalPaymentAction: finalPaymentAction || null,
    };
  })()`);
}

async function clickDepositButton(cdp) {
  return cdp.evaluate(`(() => {
    const normalize = (text) => String(text || "").replace(/\\s+/g, " ").trim();
    const button = Array.from(document.querySelectorAll("button,a"))
      .find((el) => normalize(el.innerText).includes("보증금 결제하기"));
    if (!button) return { ok: false, error: "deposit_button_not_found" };
    const before = {
      text: normalize(button.innerText),
      className: String(button.className || ""),
      disabled: button.disabled || button.hasAttribute("disabled") || String(button.className || "").includes("disabled"),
    };
    if (before.disabled) return { ok: false, error: "deposit_button_disabled", before };
    button.click();
    return { ok: true, before };
  })()`);
}

async function checkAgreementBoxes(cdp) {
  return cdp.evaluate(`new Promise(async (resolve) => {
    const sleep = (ms) => new Promise((done) => setTimeout(done, ms));
    const normalize = (text) => String(text || "").replace(/\\s+/g, " ").trim();
    const clicked = [];
    for (const input of Array.from(document.querySelectorAll("input[type='checkbox']"))) {
      if (input.checked || input.disabled) continue;
      const label = input.parentElement?.classList?.contains("label")
        ? input.parentElement
        : input.closest("label") || (input.id ? document.querySelector(\`label[for="\${CSS.escape(input.id)}"]\`) : null);
      const row = label || input.closest("li, .item, .display_item, .checkbox_item, .agreement");
      const rowText = normalize(row?.innerText || "");
      if (rowText && !rowText.includes("[필수]") && !rowText.includes("동의") && !rowText.includes("확인")) continue;
      (label || input).click();
      clicked.push({ via: label ? "label" : "input", text: rowText.slice(0, 160) });
      await sleep(650);
    }

    await sleep(750);
    resolve({
      ok: true,
      clicked,
      states: Array.from(document.querySelectorAll("input[type='checkbox']")).map((input, index) => ({
        index,
        checked: input.checked,
      })),
    });
  })`);
}

const args = parseArgs(process.argv.slice(2));
const target = pickKreamPage(await getTargets(args.port));
if (!target) {
  console.error("No KREAM page target found.");
  process.exit(1);
}

const cdp = new CdpClient(target.webSocketDebuggerUrl);
const blockedConfirmRequests = [];

await cdp.open();

try {
  await cdp.send("Runtime.enable");
  await cdp.send("Network.enable");
  await cdp.send("Fetch.enable", {
    patterns: [{
      urlPattern: "*api/seller/inventory/stock_request/confirm*",
      requestStage: "Request",
    }],
  });

  cdp.on("Fetch.requestPaused", async (params) => {
    blockedConfirmRequests.push({
      url: params.request.url.split("?")[0],
      method: params.request.method,
      blockedAt: new Date().toISOString(),
    });
    await cdp.send("Fetch.failRequest", {
      requestId: params.requestId,
      errorReason: "Aborted",
    });
  });

  const before = await captureState(cdp);
  let paymentClick = null;
  let agreementCheck = null;

  if (args.clickPayment) {
    paymentClick = await clickDepositButton(cdp);
    await sleep(args.waitMs);
  }

  const afterPaymentClick = await captureState(cdp);

  if (args.checkAgreements) {
    agreementCheck = await checkAgreementBoxes(cdp);
    await sleep(args.waitMs);
  }

  const afterAgreements = await captureState(cdp);
  const result = {
    capturedAt: new Date().toISOString(),
    before,
    paymentClick,
    afterPaymentClick,
    agreementCheck,
    afterAgreements,
    blockedConfirmRequests,
  };

  await writeJson(args.output, result);
  if (args.output) console.log(`Wrote ${path.resolve(args.output)}`);
  console.log(JSON.stringify(result, null, 2));
} finally {
  try {
    await cdp.send("Fetch.disable");
  } catch {
    // Ignore cleanup errors.
  }
  await cdp.close();
}
