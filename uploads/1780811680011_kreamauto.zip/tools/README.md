# KREAM Automation Tools

## Start Chrome with DevTools Protocol

Run this from PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\start_kream_chrome.ps1
```

Default behavior:

- opens `https://www.kream.co.kr/login`
- uses remote debugging port `9222`
- uses a dedicated Chrome profile at `%LOCALAPPDATA%\KreamAutomationChrome`
- keeps the user's normal Chrome profile separate

Custom example:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\start_kream_chrome.ps1 -Port 9222 -Url "https://www.kream.co.kr/login"
```

## Check CDP Connectivity

Run this from PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\check_chrome_cdp.ps1 9222
```

The Python checker is also available when Python runs on the same Windows network namespace as Chrome:

```powershell
python .\tools\check_chrome_cdp.py 9222
```

The script prints the Chrome version endpoint and open browser targets. Later automation scripts and the AutoHotkey v2 app will use this same endpoint.

Note: when this repository is accessed from WSL, `127.0.0.1:9222` may not be reachable from Linux even though it is reachable from Windows. AutoHotkey v2 runs on Windows, so the PowerShell check is the relevant validation for the app.

## Configure Automatic Login

Create a local secret file. Do not commit it:

```powershell
New-Item -ItemType Directory -Force .\secrets
Copy-Item .\secrets\kream-login.example.json .\secrets\kream-login.json
notepad .\secrets\kream-login.json
```

Set `provider`, `username`, and `password` in `secrets/kream-login.json`.

- Use `"provider": "naver"` for the KREAM `네이버로 로그인` flow.
- Use `"provider": "kream"` for the KREAM email/password form.

Run after starting Chrome:

```powershell
npm run cdp:login
```

The login script fills the selected login form. It does not read browser cookies, saved passwords, or local storage. If KREAM or Naver shows CAPTCHA, OTP, device verification, or another challenge, complete that step manually.

## Capture Inventory Page Structure

Run after logging in:

```powershell
npm run cdp:capture -- --product-id 66326 --output .\analysis\inventory-66326.json
```

This navigates the current KREAM tab to `https://www.kream.co.kr/inventory/{id}` and records sanitized DOM and Network metadata. Cookie and authorization headers are omitted.

## Run Controlled Continue Attempts

Single attempt:

```powershell
npm run cdp:retry-continue -- --product-id 66326 --size M --quantity 1 --max-attempts 1 --execute-click --output .\analysis\retry-66326.jsonl
```

Multiple controlled attempts use `8s` after the observed `400` availability response and `11s` after the observed `429` rate-limit response by default. Override them when needed:

```powershell
npm run cdp:retry-continue -- --product-id 66326 --size M --quantity 1 --max-attempts 3 --retry-delay-ms 8000 --rate-limit-cooldown-ms 11000 --execute-click --output .\analysis\retry-66326.jsonl
```

Behavior:

- stops immediately on `200` review success
- treats `400 / code 9999 / 신규 보관 신청이 제한된 카테고리...` as retryable
- waits the configured `400` delay before retrying the availability response
- treats `허용된 요청 횟수를 초과했습니다...` as rate-limited and waits the configured `429` cooldown before the next attempt
- prefers server `Retry-After` when present
- never calls the final confirm/payment endpoint

Use `--size-index 0` for products whose size label contains spaces and is difficult to quote in a shell.

After a successful review response, capture the visible 신청 내역 page state:

```powershell
npm run cdp:capture-review-page -- --output .\analysis\review-page-55703.json
```

## Run Parallel Product Attempts

Use independent Chrome tabs per product. This prevents page state from mixing across products:

```powershell
npm run cdp:batch-retry-continue -- --product-ids 838316,232758,238462 --size M --quantity 1 --max-attempts 1 --concurrency 3 --execute-click --output .\analysis\batch-838316-232758-238462.jsonl
```

Behavior:

- creates one CDP-controlled tab per concurrent product
- sets the configured size and quantity in each tab
- clicks `신청 계속` and logs a sanitized response summary
- does not call final confirm/payment
- closes worker tabs after each product completes

## AutoHotkey v2 GUI

Run:

```powershell
"C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe" .\KreamAutomation.ahk
```

The GUI wraps the same CDP scripts:

- `Chrome 시작`: starts the dedicated Chrome profile
- `CDP 확인`: verifies `127.0.0.1:9222`
- `자동 로그인`: reads `secrets/kream-login.json` and fills the configured login form
- `페이지 캡처`: captures the current inventory page structure
- `단일 시도`: clicks `신청 계속` once and classifies the response
- `반복 시작`: runs controlled attempts with configurable `400` and `429` wait times
- `중지`: terminates the current child process

For `ONE SIZE` or other labels that are hard to quote, leave size empty and set `사이즈 index` to `0`.
