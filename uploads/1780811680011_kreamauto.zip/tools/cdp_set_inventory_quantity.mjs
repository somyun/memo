import { CdpClient, getTargets, pickKreamPage } from "./cdp_lib.mjs";

function parseArgs(argv) {
  const args = { port: 9222, size: null, sizeIndex: null, quantity: null };
  for (let i = 0; i < argv.length; i += 1) {
    if (argv[i] === "--port") args.port = Number(argv[++i]);
    else if (argv[i] === "--size") args.size = argv[++i];
    else if (argv[i] === "--size-index") args.sizeIndex = Number(argv[++i]);
    else if (argv[i] === "--quantity") args.quantity = Number(argv[++i]);
  }
  if ((!args.size && !Number.isInteger(args.sizeIndex)) || !Number.isFinite(args.quantity)) {
    throw new Error("Pass --size XS --quantity 1 or --size-index 0 --quantity 1");
  }
  return args;
}

const args = parseArgs(process.argv.slice(2));
const target = pickKreamPage(await getTargets(args.port));
if (!target) {
  console.error("No KREAM page target found.");
  process.exit(1);
}

const expression = `new Promise((resolve) => {
  const size = ${JSON.stringify(args.size)};
  const sizeIndex = ${JSON.stringify(args.sizeIndex)};
  const quantity = ${JSON.stringify(args.quantity)};
  const normalize = (text) => String(text || "").replace(/\\s+/g, " ").trim();
  const rowSize = (el) => normalize(el.querySelector(".size")?.innerText || el.innerText);
  const items = Array.from(document.querySelectorAll(".inventory_size_item"));
  const item = Number.isInteger(sizeIndex)
    ? items[sizeIndex]
    : items.find((el) => rowSize(el) === size);
  if (!item) {
    resolve({ ok: false, error: "size_not_found", requestedSize: size, requestedSizeIndex: sizeIndex, available: items.map((el) => rowSize(el)) });
    return;
  }
  const actualSize = rowSize(item);
  const input = item.querySelector("input.counter_quantity_input");
  if (!input) {
    resolve({ ok: false, error: "input_not_found", itemText: normalize(item.innerText) });
    return;
  }
  input.focus();
  input.value = String(quantity);
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
  setTimeout(() => {
    const continueEl = Array.from(document.querySelectorAll("a, button"))
      .find((el) => normalize(el.innerText).includes("신청 계속"));
    const nuxt = document.querySelector("#__nuxt")?.__vue_app__?.$nuxt;
    const inventory = nuxt?.$pinia?.state?.value?.inventory;
    resolve({
      ok: true,
      size: actualSize,
      quantity,
      inputValue: input.value,
      itemText: normalize(item.innerText),
      continue: continueEl ? {
        tag: continueEl.tagName.toLowerCase(),
        text: normalize(continueEl.innerText),
        className: String(continueEl.className || ""),
        disabledAttr: continueEl.hasAttribute("disabled"),
        ariaDisabled: continueEl.getAttribute("aria-disabled"),
        href: continueEl.href || null,
      } : null,
      quantities: inventory?.quantities?.map((row) => ({
        option: row.option,
        productOptionId: row.product_option?.id,
        quantity: row.quantity,
        maxQty: row.max_qty,
      })),
    });
  }, 200);
})`;

const cdp = new CdpClient(target.webSocketDebuggerUrl);
await cdp.open();

try {
  await cdp.send("Runtime.enable");
  const result = await cdp.evaluate(expression);
  console.log(JSON.stringify(result, null, 2));
} finally {
  await cdp.close();
}
