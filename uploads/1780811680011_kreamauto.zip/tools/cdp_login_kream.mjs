import fs from "node:fs/promises";
import path from "node:path";
import { CdpClient, getTargets, pickKreamPage } from "./cdp_lib.mjs";

function parseArgs(argv) {
  const args = {
    port: 9222,
    secret: "secrets/kream-login.json",
    timeoutMs: null,
  };

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--port") args.port = Number(argv[++i]);
    else if (arg === "--secret") args.secret = argv[++i];
    else if (arg === "--timeout-ms") args.timeoutMs = Number(argv[++i]);
  }

  return args;
}

async function readSecret(filePath) {
  const resolved = path.resolve(filePath);
  let parsed;
  try {
    parsed = JSON.parse(await fs.readFile(resolved, "utf8"));
  } catch (error) {
    throw new Error(`Cannot read login secret at ${resolved}. Copy secrets/kream-login.example.json to secrets/kream-login.json first. ${error}`);
  }

  if (!parsed.username || !parsed.password) {
    throw new Error(`Login secret ${resolved} must include username and password.`);
  }

  const provider = String(parsed.provider || "naver").toLowerCase();
  if (!["naver", "kream"].includes(provider)) {
    throw new Error('Login secret provider must be "naver" or "kream".');
  }

  return {
    provider,
    loginUrl: parsed.loginUrl || "https://www.kream.co.kr/login",
    username: String(parsed.username),
    password: String(parsed.password),
    postLoginUrl: parsed.postLoginUrl || "https://www.kream.co.kr/",
    timeoutMs: Number(parsed.timeoutMs) || 30000,
  };
}

async function sleep(ms) {
  await new Promise((resolve) => setTimeout(resolve, ms));
}

async function getPageState(cdp) {
  return cdp.evaluate(`(() => {
    const normalize = (text) => String(text || "").replace(/\\s+/g, " ").trim();
    const text = normalize(document.body?.innerText || "");
    return {
      href: location.href,
      title: document.title,
      loggedIn: text.includes("로그아웃"),
      hasLogoutText: text.includes("로그아웃"),
      hasKreamLoginText: text.includes("이메일 주소") || text.includes("네이버로 로그인"),
      hasNaverLoginText: text.includes("네이버 로그인") || text.includes("아이디") && text.includes("비밀번호"),
      needsManualStep: text.includes("인증") || text.includes("보안") || text.includes("captcha") || text.includes("자동입력") || text.includes("OTP"),
      textSample: text.slice(0, 900),
    };
  })()`);
}

async function fillKreamLogin(cdp, secret) {
  return cdp.evaluate(`new Promise((resolve) => {
    const username = ${JSON.stringify(secret.username)};
    const password = ${JSON.stringify(secret.password)};
    const normalize = (text) => String(text || "").replace(/\\s+/g, " ").trim();
    const setNativeValue = (el, value) => {
      const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const descriptor = Object.getOwnPropertyDescriptor(proto, "value");
      descriptor?.set?.call(el, value);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    };

    const inputs = Array.from(document.querySelectorAll("input"));
    const userInput = inputs.find((el) => {
      const type = String(el.getAttribute("type") || "").toLowerCase();
      const placeholder = String(el.getAttribute("placeholder") || "").toLowerCase();
      return type === "email" || placeholder.includes("email") || placeholder.includes("kream");
    });
    const passwordInput = inputs.find((el) => String(el.getAttribute("type") || "").toLowerCase() === "password");
    if (!userInput || !passwordInput) {
      resolve({
        ok: false,
        error: "kream_login_inputs_not_found",
        href: location.href,
        inputSummary: inputs.map((el) => ({
          type: el.getAttribute("type"),
          placeholder: el.getAttribute("placeholder"),
          autocomplete: el.getAttribute("autocomplete"),
        })),
      });
      return;
    }

    userInput.focus();
    setNativeValue(userInput, username);
    passwordInput.focus();
    setNativeValue(passwordInput, password);

    setTimeout(() => {
      const candidates = Array.from(document.querySelectorAll("button,a"));
      const loginButton = candidates.find((el) => normalize(el.innerText) === "로그인")
        || candidates.find((el) => normalize(el.innerText).includes("로그인") && !normalize(el.innerText).includes("네이버") && !normalize(el.innerText).includes("Apple"));
      if (!loginButton) {
        resolve({ ok: false, error: "kream_login_button_not_found", href: location.href });
        return;
      }
      const before = {
        text: normalize(loginButton.innerText),
        className: String(loginButton.className || ""),
        disabled: loginButton.disabled || loginButton.hasAttribute("disabled") || String(loginButton.className || "").includes("disabled"),
      };
      loginButton.click();
      resolve({ ok: true, provider: "kream", href: location.href, buttonBeforeClick: before });
    }, 300);
  })`);
}

async function clickNaverLogin(cdp) {
  return cdp.evaluate(`new Promise((resolve) => {
    const normalize = (text) => String(text || "").replace(/\\s+/g, " ").trim();
    const button = Array.from(document.querySelectorAll("button,a"))
      .find((el) => normalize(el.innerText).includes("네이버로 로그인"));
    if (!button) {
      resolve({ ok: false, error: "naver_login_button_not_found", href: location.href });
      return;
    }
    const before = {
      text: normalize(button.innerText),
      className: String(button.className || ""),
      href: button.href || null,
    };
    button.click();
    resolve({ ok: true, provider: "naver", href: location.href, buttonBeforeClick: before });
  })`);
}

async function fillNaverLogin(cdp, secret) {
  return cdp.evaluate(`new Promise((resolve) => {
    const username = ${JSON.stringify(secret.username)};
    const password = ${JSON.stringify(secret.password)};
    const setNativeValue = (el, value) => {
      const descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
      descriptor?.set?.call(el, value);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    };

    const idInput = document.querySelector("#id") || document.querySelector("input[name='id']");
    const pwInput = document.querySelector("#pw") || document.querySelector("input[name='pw']") || document.querySelector("input[type='password']");
    if (!idInput || !pwInput) {
      resolve({
        ok: false,
        error: "naver_login_inputs_not_found",
        href: location.href,
        inputSummary: Array.from(document.querySelectorAll("input")).map((el) => ({
          id: el.id,
          name: el.getAttribute("name"),
          type: el.getAttribute("type"),
          placeholder: el.getAttribute("placeholder"),
        })),
      });
      return;
    }

    idInput.focus();
    setNativeValue(idInput, username);
    pwInput.focus();
    setNativeValue(pwInput, password);

    setTimeout(() => {
      const loginButton = document.querySelector("#log\\.login")
        || document.querySelector("button[type='submit']")
        || document.querySelector("input[type='submit']");
      if (!loginButton) {
        resolve({ ok: false, error: "naver_login_submit_not_found", href: location.href });
        return;
      }
      loginButton.click();
      resolve({ ok: true, provider: "naver", href: location.href });
    }, 300);
  })`);
}

const args = parseArgs(process.argv.slice(2));
const secret = await readSecret(args.secret);
const timeoutMs = Number(args.timeoutMs) || secret.timeoutMs;

const target = pickKreamPage(await getTargets(args.port));
if (!target) {
  console.error("No KREAM page target found. Start Chrome first with tools/start_kream_chrome.ps1.");
  process.exit(1);
}

const cdp = new CdpClient(target.webSocketDebuggerUrl);
await cdp.open();

try {
  await cdp.send("Page.enable");
  await cdp.send("Runtime.enable");
  await cdp.send("Page.navigate", { url: secret.loginUrl });
  await sleep(3000);

  const steps = [];
  const initialState = await getPageState(cdp);
  if (initialState.loggedIn) {
    steps.push({ ok: true, provider: secret.provider, skipped: true, reason: "already_logged_in" });
  } else if (secret.provider === "kream") {
    steps.push(await fillKreamLogin(cdp, secret));
  } else {
    steps.push(await clickNaverLogin(cdp));
    await sleep(3000);
    steps.push(await fillNaverLogin(cdp, secret));
  }

  await sleep(timeoutMs);
  let pageState = await getPageState(cdp);

  if (pageState.loggedIn && secret.postLoginUrl && pageState.href.includes("/login")) {
    await cdp.send("Page.navigate", { url: secret.postLoginUrl });
    await sleep(1500);
    pageState = await getPageState(cdp);
  }

  console.log(JSON.stringify({
    attemptedAt: new Date().toISOString(),
    secretPath: path.resolve(args.secret),
    provider: secret.provider,
    steps,
    pageState,
  }, null, 2));
} finally {
  await cdp.close();
}
