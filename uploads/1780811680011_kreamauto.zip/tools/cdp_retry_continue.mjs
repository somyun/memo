import fs from "node:fs/promises";
import path from "node:path";
import { CdpClient, getTargets, pickKreamPage } from "./cdp_lib.mjs";

function parseArgs(argv) {
  const args = {
    port: 9222,
    productId: null,
    url: null,
    size: null,
    sizeIndex: null,
    quantity: null,
    output: null,
    maxAttempts: 1,
    retryDelayMs: 8000,
    rateLimitCooldownMs: 11000,
    pageLoadMs: 5000,
    responseWaitMs: 5000,
    executeClick: false,
  };

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--port") args.port = Number(argv[++i]);
    else if (arg === "--product-id") args.productId = argv[++i];
    else if (arg === "--url") args.url = argv[++i];
    else if (arg === "--size") args.size = argv[++i];
    else if (arg === "--size-index") args.sizeIndex = Number(argv[++i]);
    else if (arg === "--quantity") args.quantity = Number(argv[++i]);
    else if (arg === "--output") args.output = argv[++i];
    else if (arg === "--max-attempts") args.maxAttempts = Number(argv[++i]);
    else if (arg === "--retry-delay-ms") args.retryDelayMs = Number(argv[++i]);
    else if (arg === "--rate-limit-cooldown-ms") args.rateLimitCooldownMs = Number(argv[++i]);
    else if (arg === "--page-load-ms") args.pageLoadMs = Number(argv[++i]);
    else if (arg === "--response-wait-ms") args.responseWaitMs = Number(argv[++i]);
    else if (arg === "--execute-click") args.executeClick = true;
  }

  if ((!args.size && !Number.isInteger(args.sizeIndex)) || !Number.isFinite(args.quantity)) {
    throw new Error("Pass --size M --quantity 1 or --size-index 0 --quantity 1.");
  }
  if (!Number.isInteger(args.maxAttempts) || args.maxAttempts < 1) {
    throw new Error("--max-attempts must be a positive integer.");
  }
  if (!Number.isFinite(args.retryDelayMs) || args.retryDelayMs < 0) {
    throw new Error("--retry-delay-ms must be a non-negative number.");
  }
  if (!Number.isFinite(args.rateLimitCooldownMs) || args.rateLimitCooldownMs < 0) {
    throw new Error("--rate-limit-cooldown-ms must be a non-negative number.");
  }
  if (!args.executeClick) {
    throw new Error("This script clicks '신청 계속'. Pass --execute-click to confirm.");
  }

  return args;
}

function inventoryUrlFromArgs(args) {
  if (args.url) {
    const url = new URL(args.url);
    if (url.pathname.startsWith("/products/")) {
      url.pathname = url.pathname.replace("/products/", "/inventory/");
    }
    return url.toString();
  }
  if (args.productId) {
    return `https://www.kream.co.kr/inventory/${encodeURIComponent(args.productId)}`;
  }
  return null;
}

function sanitizeHeaders(headers = {}) {
  const blocked = new Set(["authorization", "cookie", "set-cookie", "x-kream-device-id"]);
  const sanitized = {};
  for (const [key, value] of Object.entries(headers)) {
    if (!blocked.has(key.toLowerCase())) sanitized[key] = value;
  }
  return sanitized;
}

function isReviewRequest(url) {
  return url.includes("/api/seller/inventory/stock_request/review");
}

function getHeader(headers, name) {
  const target = name.toLowerCase();
  for (const [key, value] of Object.entries(headers || {})) {
    if (key.toLowerCase() === target) return value;
  }
  return null;
}

function retryAfterToMs(value) {
  if (!value) return null;
  const numeric = Number(value);
  if (Number.isFinite(numeric)) return Math.max(0, numeric * 1000);
  const dateMs = Date.parse(value);
  if (Number.isFinite(dateMs)) return Math.max(0, dateMs - Date.now());
  return null;
}

function parseBody(body) {
  if (!body || body === "[base64 omitted]") return null;
  try {
    return JSON.parse(body);
  } catch {
    return null;
  }
}

function summarizeReviewResponse(item) {
  const body = parseBody(item?.responseBody);
  const retryAfterMs = retryAfterToMs(getHeader(item?.responseHeaders, "Retry-After"));
  const message = body?.message ?? null;
  const code = body?.code ?? null;
  const status = item?.status ?? null;
  const isSuccess = item?.method === "POST" && status >= 200 && status < 300;
  const isRestrictedCategory = item?.method === "POST"
    && status === 400
    && code === 9999
    && typeof message === "string"
    && message.includes("신규 보관 신청이 제한된 카테고리");
  const isRateLimit = typeof message === "string"
    && message.includes("허용된 요청 횟수를 초과했습니다");
  const isServerError = item?.method === "POST" && status >= 500;

  let outcome = "unknown";
  if (isSuccess) outcome = "success";
  else if (isServerError) outcome = "server_error";
  else if (isRateLimit) outcome = "hard_cooldown";
  else if (isRestrictedCategory) outcome = "retryable_restricted_category";
  else if (item?.method === "POST" && status >= 400) outcome = "error";

  return {
    outcome,
    method: item?.method ?? null,
    status,
    code,
    message,
    alertType: body?.alert_type ?? null,
    retryAfterMs,
    url: item?.url ? item.url.split("?")[0] : null,
    requestItemSummary: item?.postData?.items?.map((row) => ({
      productId: row.product_id,
      option: row.option,
      quantity: row.quantity,
      productOptionId: row.product_option?.id,
    })) ?? null,
    successSummary: isSuccess ? {
      reviewId: body?.id ?? null,
      totalQuantity: body?.total_quantity ?? null,
      deposit: body?.deposit ?? null,
      totalAmount: body?.total_amount ?? null,
      itemCount: Array.isArray(body?.items) ? body.items.length : null,
    } : null,
  };
}

async function appendJsonLine(filePath, value) {
  if (!filePath) return;
  const resolved = path.resolve(filePath);
  await fs.mkdir(path.dirname(resolved), { recursive: true });
  await fs.appendFile(resolved, `${JSON.stringify(value)}\n`, "utf8");
}

async function sleep(ms) {
  await new Promise((resolve) => setTimeout(resolve, ms));
}

async function setQuantityAndClick(cdp, args) {
  return cdp.evaluate(`new Promise((resolve) => {
    const size = ${JSON.stringify(args.size)};
    const sizeIndex = ${JSON.stringify(args.sizeIndex)};
    const quantity = ${JSON.stringify(args.quantity)};
    const normalize = (text) => String(text || "").replace(/\\s+/g, " ").trim();
    const rowSize = (el) => normalize(el.querySelector(".size")?.innerText || el.innerText);
    const items = Array.from(document.querySelectorAll(".inventory_size_item"));
    const item = Number.isInteger(sizeIndex)
      ? items[sizeIndex]
      : items.find((el) => rowSize(el) === size);
    if (!item) {
      resolve({ ok: false, error: "size_not_found", requestedSize: size, requestedSizeIndex: sizeIndex, available: items.map((el) => rowSize(el)) });
      return;
    }

    const actualSize = rowSize(item);
    const input = item.querySelector("input.counter_quantity_input");
    if (!input) {
      resolve({ ok: false, error: "input_not_found", size: actualSize });
      return;
    }

    input.focus();
    input.value = String(quantity);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));

    setTimeout(() => {
      const continueEl = Array.from(document.querySelectorAll("a, button"))
        .find((el) => normalize(el.innerText).includes("신청 계속"));
      if (!continueEl) {
        resolve({ ok: false, error: "continue_not_found", size: actualSize });
        return;
      }
      const before = {
        className: String(continueEl.className || ""),
        disabledAttr: continueEl.hasAttribute("disabled"),
        text: normalize(continueEl.innerText),
      };
      continueEl.click();
      resolve({ ok: true, size: actualSize, quantity, buttonBeforeClick: before, href: location.href });
    }, 250);
  })`);
}

async function capturePageState(cdp) {
  return cdp.evaluate(`(() => {
    const normalize = (text) => String(text || "").replace(/\\s+/g, " ").trim();
    const text = normalize(document.body?.innerText || "");
    const toastCandidates = Array.from(document.querySelectorAll("*"))
      .filter((el) => /toast|snackbar|notification|alert|message|layer|modal/i.test(String(el.className || "")) || el.getAttribute("role") === "alert")
      .map((el) => ({
        text: normalize(el.innerText),
        className: String(el.className || ""),
        role: el.getAttribute("role"),
      }))
      .filter((item) => item.text)
      .slice(0, 20);
    const nuxt = document.querySelector("#__nuxt")?.__vue_app__?.$nuxt;
    const inventory = nuxt?.$pinia?.state?.value?.inventory;
    return {
      href: location.href,
      title: document.title,
      hasReviewPageText: text.includes("신청 내역") && text.includes("보증금 결제하기"),
      hasRestrictedText: text.includes("신규 보관 신청이 제한된 카테고리의 상품입니다"),
      hasRateLimitText: text.includes("허용된 요청 횟수를 초과했습니다"),
      toastCandidates,
      review: inventory?.review ? {
        id: inventory.review.id,
        totalQuantity: inventory.review.total_quantity,
        itemCount: Array.isArray(inventory.review.items) ? inventory.review.items.length : null,
        hasReturnAddress: Boolean(inventory.review.return_address),
      } : null,
    };
  })()`);
}

const args = parseArgs(process.argv.slice(2));
const targetUrl = inventoryUrlFromArgs(args);
const target = pickKreamPage(await getTargets(args.port));
if (!target) {
  console.error("No KREAM page target found.");
  process.exit(1);
}

const cdp = new CdpClient(target.webSocketDebuggerUrl);
const requests = new Map();
const responses = [];

await cdp.open();

try {
  await cdp.send("Page.enable");
  await cdp.send("Runtime.enable");
  await cdp.send("Network.enable");

  cdp.on("Network.requestWillBeSent", (params) => {
    const url = params.request?.url ?? "";
    if (!isReviewRequest(url)) return;
    let postData = null;
    if (params.request.postData) {
      try {
        postData = JSON.parse(params.request.postData);
      } catch {
        postData = "[unparsed]";
      }
    }
    requests.set(params.requestId, {
      requestId: params.requestId,
      url,
      method: params.request.method,
      requestHeaders: sanitizeHeaders(params.request.headers),
      postData,
      wallTime: params.wallTime,
    });
  });

  cdp.on("Network.responseReceived", (params) => {
    const url = params.response?.url ?? "";
    if (!isReviewRequest(url)) return;
    const request = requests.get(params.requestId) ?? {};
    responses.push({
      requestId: params.requestId,
      item: {
        ...request,
        status: params.response.status,
        statusText: params.response.statusText,
        responseHeaders: sanitizeHeaders(params.response.headers),
        responseBody: null,
      },
    });
  });

  if (targetUrl) {
    await cdp.send("Page.navigate", { url: targetUrl });
    await sleep(args.pageLoadMs);
  }

  let finalOutcome = "exhausted";

  for (let attempt = 1; attempt <= args.maxAttempts; attempt += 1) {
    const startedAt = new Date().toISOString();
    const responseStartIndex = responses.length;
    const click = await setQuantityAndClick(cdp, args);
    await sleep(args.responseWaitMs);

    const attemptResponses = responses.slice(responseStartIndex);
    for (const response of attemptResponses) {
      try {
        const body = await cdp.send("Network.getResponseBody", { requestId: response.requestId });
        response.item.responseBody = body.base64Encoded ? "[base64 omitted]" : body.body;
      } catch (error) {
        response.item.responseBodyError = String(error);
      }
    }

    const postResponses = attemptResponses
      .map((entry) => entry.item)
      .filter((item) => item.method === "POST");
    const primaryResponse = postResponses.at(-1) ?? null;
    const responseSummary = primaryResponse ? summarizeReviewResponse(primaryResponse) : null;
    const pageState = await capturePageState(cdp);

    let outcome = responseSummary?.outcome ?? "no_review_response";
    if (!click.ok) outcome = click.error;
    if (pageState.hasRateLimitText && outcome !== "success") outcome = "hard_cooldown";

    const record = {
      attempt,
      maxAttempts: args.maxAttempts,
      startedAt,
      finishedAt: new Date().toISOString(),
      targetUrl: targetUrl ?? target.url,
      click,
      outcome,
      response: responseSummary,
      pageState,
    };

    console.log(JSON.stringify(record, null, 2));
    await appendJsonLine(args.output, record);

    if (outcome === "success") {
      finalOutcome = "success";
      break;
    }

    if (outcome === "hard_cooldown") {
      const serverDelayMs = responseSummary?.retryAfterMs;
      const waitMs = serverDelayMs ?? args.rateLimitCooldownMs;
      if (!Number.isFinite(waitMs) || attempt >= args.maxAttempts) {
        finalOutcome = "hard_cooldown";
        break;
      }
      await sleep(waitMs);
      continue;
    }

    if (outcome === "retryable_restricted_category" && attempt < args.maxAttempts) {
      const waitMs = responseSummary?.retryAfterMs ?? args.retryDelayMs;
      await sleep(waitMs);
      continue;
    }

    if (attempt >= args.maxAttempts) {
      finalOutcome = outcome;
      break;
    }

    finalOutcome = outcome;
    break;
  }

  console.log(JSON.stringify({ finalOutcome, finishedAt: new Date().toISOString() }, null, 2));
} finally {
  await cdp.close();
}
