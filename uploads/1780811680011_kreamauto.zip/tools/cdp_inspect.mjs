import { CdpClient, getTargets, getVersion, pickKreamPage } from "./cdp_lib.mjs";

const port = Number(process.argv[2] ?? 9222);

const version = await getVersion(port);
const targets = await getTargets(port);
const target = pickKreamPage(targets);

if (!target) {
  console.error("No page target found. Start Chrome with tools/start_kream_chrome.ps1 first.");
  process.exit(1);
}

console.log(`Browser: ${version.Browser}`);
console.log(`Selected target: ${target.title} [${target.url}]`);

const cdp = new CdpClient(target.webSocketDebuggerUrl);
await cdp.open();

try {
  await cdp.send("Runtime.enable");
  await cdp.send("Page.enable");

  const pageInfo = await cdp.evaluate(`(() => {
    const text = document.body ? document.body.innerText : "";
    const anchors = Array.from(document.querySelectorAll("a[href]"))
      .slice(0, 80)
      .map((a) => ({ text: a.innerText.trim(), href: a.href }))
      .filter((a) => a.text || a.href.includes("kream.co.kr"));
    const buttons = Array.from(document.querySelectorAll("button"))
      .slice(0, 80)
      .map((button) => ({
        text: button.innerText.trim(),
        disabled: button.disabled,
        className: button.className,
        ariaLabel: button.getAttribute("aria-label"),
      }));
    const inputs = Array.from(document.querySelectorAll("input, textarea, select"))
      .slice(0, 80)
      .map((input) => ({
        tag: input.tagName.toLowerCase(),
        type: input.getAttribute("type"),
        name: input.getAttribute("name"),
        placeholder: input.getAttribute("placeholder"),
        valuePresent: Boolean(input.value),
        autocomplete: input.getAttribute("autocomplete"),
      }));
    const hasLoginText = /로그인|네이버|NAVER/.test(text);
    const hasLogoutText = /로그아웃/.test(text);
    const hasMyText = /마이|MY|판매|구매|관심/.test(text);
    return {
      href: location.href,
      title: document.title,
      readyState: document.readyState,
      bodyTextSample: text.slice(0, 1200),
      textLength: text.length,
      loginHeuristic: {
        hasLoginText,
        hasLogoutText,
        hasMyText,
      },
      anchors,
      buttons,
      inputs,
    };
  })()`);

  console.log(JSON.stringify(pageInfo, null, 2));
} finally {
  await cdp.close();
}
