import fs from "node:fs/promises";
import path from "node:path";
import { CdpClient, getTargets, pickKreamPage } from "./cdp_lib.mjs";

function parseArgs(argv) {
  const args = {
    port: 9222,
    terms: [
      "inventory",
      "stockRequest",
      "quantities",
      "신규 보관",
      "허용된 요청",
      "제한",
      "/api/",
      "deposit",
      "warehouse",
      "storage",
    ],
    output: null,
  };
  for (let i = 0; i < argv.length; i += 1) {
    if (argv[i] === "--port") args.port = Number(argv[++i]);
    else if (argv[i] === "--term") args.terms.push(argv[++i]);
    else if (argv[i] === "--output") args.output = argv[++i];
  }
  return args;
}

function flattenResources(node, out = []) {
  if (node.resources) out.push(...node.resources);
  if (node.childFrames) {
    for (const child of node.childFrames) flattenResources(child, out);
  }
  return out;
}

function snippet(content, index, width = 320) {
  const start = Math.max(0, index - width);
  const end = Math.min(content.length, index + width);
  return content.slice(start, end).replace(/\s+/g, " ");
}

const args = parseArgs(process.argv.slice(2));
const target = pickKreamPage(await getTargets(args.port));
if (!target) {
  console.error("No KREAM page target found.");
  process.exit(1);
}

const cdp = new CdpClient(target.webSocketDebuggerUrl);
await cdp.open();

try {
  await cdp.send("Page.enable");
  const tree = await cdp.send("Page.getResourceTree");
  const frameId = tree.frameTree.frame.id;
  const resources = flattenResources(tree.frameTree)
    .filter((resource) => resource.url.includes("/_nuxt/") && resource.url.endsWith(".js"));

  const results = [];
  for (const resource of resources) {
    let content = "";
    try {
      const body = await cdp.send("Page.getResourceContent", { frameId, url: resource.url });
      content = body.content || "";
    } catch (error) {
      results.push({ url: resource.url, error: String(error) });
      continue;
    }

    const matches = [];
    for (const term of args.terms) {
      let fromIndex = 0;
      while (matches.length < 30) {
        const index = content.indexOf(term, fromIndex);
        if (index === -1) break;
        matches.push({ term, index, snippet: snippet(content, index) });
        fromIndex = index + term.length;
      }
    }

    if (matches.length) {
      results.push({
        url: resource.url,
        size: content.length,
        matches,
      });
    }
  }

  const output = {
    searchedAt: new Date().toISOString(),
    url: target.url,
    resourceCount: resources.length,
    resultCount: results.length,
    results,
  };

  if (args.output) {
    const outputPath = path.resolve(args.output);
    await fs.mkdir(path.dirname(outputPath), { recursive: true });
    await fs.writeFile(outputPath, JSON.stringify(output, null, 2), "utf8");
    console.log(`Wrote ${outputPath}`);
  }

  console.log(JSON.stringify(output, null, 2));
} finally {
  await cdp.close();
}
