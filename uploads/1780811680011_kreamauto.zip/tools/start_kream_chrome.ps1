param(
    [int]$Port = 9222,
    [string]$Url = "https://www.kream.co.kr/login",
    [string]$ProfileDir = "$env:LOCALAPPDATA\KreamAutomationChrome"
)

$ErrorActionPreference = "Stop"

function Test-PortOpen {
    param([string]$HostName, [int]$PortNumber)

    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $result = $client.BeginConnect($HostName, $PortNumber, $null, $null)
        $connected = $result.AsyncWaitHandle.WaitOne(300)
        if (-not $connected) {
            return $false
        }
        $client.EndConnect($result)
        return $true
    } catch {
        return $false
    } finally {
        $client.Close()
    }
}

$chromeCandidates = @(
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
)

$chromePath = $chromeCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $chromePath) {
    throw "Chrome executable was not found. Install Chrome or update this script with the correct chrome.exe path."
}

New-Item -ItemType Directory -Force -Path $ProfileDir | Out-Null

if (Test-PortOpen -HostName "127.0.0.1" -PortNumber $Port) {
    Write-Host "Chrome DevTools Protocol already appears to be listening on port $Port."
    Write-Host "CDP version endpoint: http://127.0.0.1:$Port/json/version"
    Write-Host "Target URL: $Url"
    Start-Process -FilePath $chromePath -ArgumentList @("--user-data-dir=$ProfileDir", $Url) | Out-Null
    exit 0
}

$chromeArgs = @(
    "--remote-debugging-address=127.0.0.1",
    "--remote-debugging-port=$Port",
    "--user-data-dir=$ProfileDir",
    "--no-first-run",
    "--no-default-browser-check",
    $Url
)

Start-Process -FilePath $chromePath -ArgumentList $chromeArgs | Out-Null

Write-Host "Started Chrome for KREAM automation."
Write-Host "Chrome path: $chromePath"
Write-Host "Profile dir: $ProfileDir"
Write-Host "CDP version endpoint: http://127.0.0.1:$Port/json/version"
Write-Host "Opened URL: $Url"
