#!/usr/bin/env python3
import json
import sys
import urllib.error
import urllib.request


def fetch_json(url: str):
    with urllib.request.urlopen(url, timeout=3) as response:
        return json.loads(response.read().decode("utf-8"))


def main() -> int:
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 9222
    base_url = f"http://127.0.0.1:{port}"

    try:
        version = fetch_json(f"{base_url}/json/version")
        targets = fetch_json(f"{base_url}/json/list")
    except urllib.error.URLError as exc:
        print(f"CDP connection failed on {base_url}: {exc}", file=sys.stderr)
        return 1

    print("Chrome DevTools Protocol is reachable.")
    print(f"Browser: {version.get('Browser', 'unknown')}")
    print(f"Protocol-Version: {version.get('Protocol-Version', 'unknown')}")
    print(f"webSocketDebuggerUrl: {version.get('webSocketDebuggerUrl', 'missing')}")
    print("")
    print("Targets:")
    for target in targets:
        target_type = target.get("type", "unknown")
        title = target.get("title", "")
        url = target.get("url", "")
        print(f"- {target_type}: {title} [{url}]")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
