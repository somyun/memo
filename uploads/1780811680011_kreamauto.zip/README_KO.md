# KREAM 보관 신청 도구 실행 안내

## 실행

`KreamAutomation.exe`를 실행합니다.

## 필요 조건

- Chrome 설치
- Node.js 설치
- `secrets/kream-login.json` 파일 준비

`secrets/kream-login.example.json`을 복사해 `kream-login.json`으로 만든 뒤 계정 정보를 입력하세요.

## 기본 전략

- 기본 전략은 `focus`입니다.
- `focus`: 한 품목을 성공 또는 종료 조건까지 집중 시도합니다.
- `round-robin`: 품목별로 1회씩 순환 시도합니다.
- `parallel`: 진단용 병렬 실행입니다. 계정 단위 제한 때문에 운영 기본값으로 사용하지 않습니다.

## 안전 기준

이 도구는 `/stock_request/review` 성공 감지와 신청내역 페이지 진입 보조까지 수행합니다.
실제 최종 결제 확정 요청은 자동 실행하지 않습니다.

## 로그

JSONL 로그는 `analysis` 폴더에 저장됩니다.
500 또는 요청 실패 진단 시 `networkRequests`, `networkResponses`, `networkFailures` 항목을 확인하세요.
