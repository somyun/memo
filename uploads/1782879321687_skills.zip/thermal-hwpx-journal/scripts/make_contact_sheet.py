#!/usr/bin/env python3
import argparse
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


def main() -> None:
    parser = argparse.ArgumentParser(description="Create an enlarged contact sheet for thermal image reading.")
    parser.add_argument("--input-dir", required=True)
    parser.add_argument("--pattern", default="*X.JPG")
    parser.add_argument("--output", required=True)
    parser.add_argument("--cols", type=int, default=2)
    parser.add_argument("--scale", type=float, default=1.25)
    args = parser.parse_args()

    files = sorted(Path(args.input_dir).glob(args.pattern))
    if not files:
        raise SystemExit(f"No images matched {args.pattern!r} in {args.input_dir}")

    images = [Image.open(path).convert("RGB") for path in files]
    width, height = images[0].size
    tile_w, tile_h = int(width * args.scale), int(height * args.scale)
    label_h = 32
    rows = (len(images) + args.cols - 1) // args.cols
    sheet = Image.new("RGB", (args.cols * tile_w, rows * (tile_h + label_h)), "white")
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.load_default()

    for idx, (path, image) in enumerate(zip(files, images)):
        x = (idx % args.cols) * tile_w
        y = (idx // args.cols) * (tile_h + label_h)
        draw.text((x + 8, y + 8), path.name, fill=(0, 0, 0), font=font)
        sheet.paste(image.resize((tile_w, tile_h)), (x, y + label_h))

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    sheet.save(args.output, quality=95)
    print(args.output)


if __name__ == "__main__":
    main()
