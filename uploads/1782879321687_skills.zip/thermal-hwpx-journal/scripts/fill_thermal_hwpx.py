#!/usr/bin/env python3
import argparse
import csv
import re
import shutil
import tempfile
from datetime import date, datetime
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZIP_STORED, ZipFile

from lxml import etree

NS = {
    "hp": "http://www.hancom.co.kr/hwpml/2011/paragraph",
    "hc": "http://www.hancom.co.kr/hwpml/2011/core",
    "opf": "http://www.idpf.org/2007/opf/",
}


def parse_args():
    parser = argparse.ArgumentParser(description="Fill a thermal inspection HWPX table from image pairs and temperature CSV.")
    parser.add_argument("--input-dir", required=True, help="Folder containing one .hwpx and paired X/Y images.")
    parser.add_argument("--hwpx", help="Specific HWPX path. Defaults to the only .hwpx in input-dir.")
    parser.add_argument("--values-csv", required=True, help="CSV with columns base,R,S,T. Empty cells are preserved blank.")
    parser.add_argument("--date", default=date.today().isoformat(), help="Date used in output filename, YYYY-MM-DD.")
    parser.add_argument("--output", help="Output .hwpx. Defaults to input filename with date-like part replaced.")
    parser.add_argument("--work-dir", default=None, help="ASCII scratch directory. Defaults to a temp directory.")
    return parser.parse_args()


def find_hwpx(input_dir: Path, explicit: str | None) -> Path:
    if explicit:
        path = Path(explicit)
        if not path.is_file():
            raise SystemExit(f"HWPX not found: {path}")
        return path
    files = sorted(input_dir.glob("*.hwpx"))
    if len(files) != 1:
        raise SystemExit(f"Expected exactly one .hwpx in {input_dir}, found {len(files)}")
    return files[0]


def image_base(path: Path) -> str | None:
    stem = path.stem
    if not stem:
        return None
    suffix = stem[-1].upper()
    if suffix not in {"X", "Y"}:
        return None
    return stem[:-1]


def find_pairs(input_dir: Path):
    pairs: dict[str, dict[str, Path]] = {}
    for path in input_dir.iterdir():
        if not path.is_file() or path.suffix.lower() not in {".jpg", ".jpeg", ".png", ".bmp"}:
            continue
        base = image_base(path)
        if not base:
            continue
        pairs.setdefault(base, {})[path.stem[-1].upper()] = path
    complete = []
    for base in sorted(pairs):
        if "X" in pairs[base] and "Y" in pairs[base]:
            complete.append((base, pairs[base]["Y"], pairs[base]["X"]))
    if not complete:
        raise SystemExit("No complete X/Y image pairs found")
    return complete


def read_values(csv_path: Path):
    values = {}
    with csv_path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        required = {"base", "R", "S", "T"}
        if not reader.fieldnames or not required.issubset(reader.fieldnames):
            raise SystemExit("values CSV must contain columns: base,R,S,T")
        for row in reader:
            base = row["base"].strip()
            values[base] = [row["R"].strip(), row["S"].strip(), row["T"].strip()]
    return values


def unpack(hwpx: Path, output_dir: Path) -> None:
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True)
    with ZipFile(hwpx, "r") as archive:
        archive.extractall(output_dir)


def pack(input_dir: Path, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    files = sorted(path for path in input_dir.rglob("*") if path.is_file())
    with ZipFile(output, "w", ZIP_DEFLATED) as archive:
        mimetype = input_dir / "mimetype"
        archive.write(mimetype, "mimetype", compress_type=ZIP_STORED)
        for path in files:
            rel = path.relative_to(input_dir).as_posix()
            if rel == "mimetype":
                continue
            archive.write(path, rel, compress_type=ZIP_DEFLATED)


def text_of(node) -> str:
    return "".join(node.xpath(".//hp:t/text()", namespaces=NS))


def find_table(root):
    for table in root.xpath(".//hp:tbl", namespaces=NS):
        text = text_of(table)
        if "전기설비온도측정표" in text or "PT,CT" in text or "PT, CT" in text:
            rows_with_images = table.xpath(
                "./hp:tr[hp:tc/hp:cellAddr[@colAddr='5'] and hp:tc/hp:cellAddr[@colAddr='6']]",
                namespaces=NS,
            )
            if rows_with_images:
                return table
    raise SystemExit("Could not find the thermal temperature table")


def addr(cell):
    node = cell.find("hp:cellAddr", namespaces=NS)
    return int(node.get("rowAddr")), int(node.get("colAddr"))


def cells_by_addr(table):
    result = {}
    for cell in table.xpath("./hp:tr/hp:tc", namespaces=NS):
        result[addr(cell)] = cell
    return result


def set_cell_text(cell, value: str) -> None:
    text_nodes = cell.xpath(".//hp:t", namespaces=NS)
    if not text_nodes:
        run = cell.find(".//hp:run", namespaces=NS)
        if run is None:
            raise SystemExit("Cannot insert text into a cell without hp:run")
        text_nodes = [etree.SubElement(run, f"{{{NS['hp']}}}t")]
    text_nodes[0].text = value
    for node in text_nodes[1:]:
        node.text = ""


def manifest_map(unpacked: Path):
    content = unpacked / "Contents" / "content.hpf"
    tree = etree.parse(str(content))
    items = {}
    for item in tree.xpath(".//opf:item", namespaces=NS):
        item_id = item.get("id")
        href = item.get("href")
        if item_id and href and href.startswith("BinData/"):
            items[item_id] = unpacked / href
    return items


def update_shape_comment(pic, filename: str, image_path: Path) -> None:
    comment = pic.find("hp:shapeComment", namespaces=NS)
    if comment is None:
        comment = etree.SubElement(pic, f"{{{NS['hp']}}}shapeComment")
    try:
        from PIL import Image

        with Image.open(image_path) as image:
            width, height = image.size
    except Exception:
        width, height = 0, 0
    comment.text = f"그림입니다.\n원본 그림의 이름: {filename}\n원본 그림의 크기: 가로 {width}pixel, 세로 {height}pixel"


def replace_cell_image(cell, source: Path, manifest: dict[str, Path]) -> None:
    img = cell.find(".//hc:img", namespaces=NS)
    if img is None:
        raise SystemExit("Expected existing image in picture cell")
    image_id = img.get("binaryItemIDRef")
    if image_id not in manifest:
        raise SystemExit(f"Image id {image_id!r} not found in content.hpf")
    shutil.copyfile(source, manifest[image_id])
    pic = cell.find(".//hp:pic", namespaces=NS)
    if pic is not None:
        update_shape_comment(pic, source.name, source)


def data_rows(table):
    rows = []
    for row in table.xpath("./hp:tr", namespaces=NS):
        row_cells = row.xpath("./hp:tc", namespaces=NS)
        cols = {addr(cell)[1] for cell in row_cells}
        if 5 in cols and 6 in cols:
            row_addr = min(addr(cell)[0] for cell in row_cells)
            if row_addr >= 6:
                rows.append(row_addr)
    return sorted(set(rows))


def dated_output_name(input_name: str, when: date) -> str:
    date_pattern = re.compile(r"(?P<year>20\d{2})(?P<sep>[.\-_])(?P<month>\d{1,2})(?:(?P=sep)(?P<day>\d{1,2}))?")

    def repl(match):
        sep = match.group("sep")
        if match.group("day") is not None:
            return f"{when.year:04d}{sep}{when.month:02d}{sep}{when.day:02d}"
        return f"{when.year:04d}{sep}{when.month:02d}"

    new_name, count = date_pattern.subn(repl, input_name, count=1)
    if count:
        return new_name
    stem = Path(input_name).stem
    suffix = Path(input_name).suffix
    return f"{stem}({when.year:04d}.{when.month:02d}.{when.day:02d}){suffix}"


def main() -> None:
    args = parse_args()
    input_dir = Path(args.input_dir)
    hwpx = find_hwpx(input_dir, args.hwpx)
    pairs = find_pairs(input_dir)
    values = read_values(Path(args.values_csv))
    when = datetime.strptime(args.date, "%Y-%m-%d").date()

    missing = [base for base, _, _ in pairs if base not in values]
    if missing:
        raise SystemExit(f"Missing CSV values for image pair(s): {', '.join(missing)}")

    if args.work_dir:
        work_root = Path(args.work_dir)
        work_root.mkdir(parents=True, exist_ok=True)
        temp_context = None
    else:
        temp_context = tempfile.TemporaryDirectory(prefix="thermal_hwpx_", dir="C:/tmp" if Path("C:/tmp").exists() else None)
        work_root = Path(temp_context.name)

    try:
        unpacked = work_root / "unpacked"
        unpack(hwpx, unpacked)

        section = unpacked / "Contents" / "section0.xml"
        parser = etree.XMLParser(remove_blank_text=False)
        tree = etree.parse(str(section), parser)
        table = find_table(tree.getroot())
        by_addr = cells_by_addr(table)
        rows = data_rows(table)
        if len(rows) != len(pairs):
            raise SystemExit(f"Table has {len(rows)} image rows but folder has {len(pairs)} image pairs")

        manifest = manifest_map(unpacked)
        for row_addr, (base, visible, thermal) in zip(rows, pairs):
            for offset, value in enumerate(values[base]):
                set_cell_text(by_addr[(row_addr, 2 + offset)], value)
            replace_cell_image(by_addr[(row_addr, 5)], visible, manifest)
            replace_cell_image(by_addr[(row_addr, 6)], thermal, manifest)

        tree.write(str(section), encoding="UTF-8", xml_declaration=True, pretty_print=True)

        output = Path(args.output) if args.output else hwpx.with_name(dated_output_name(hwpx.name, when))
        pack(unpacked, output)
        print(f"Wrote: {output}")
    finally:
        if temp_context is not None:
            temp_context.cleanup()


if __name__ == "__main__":
    main()
