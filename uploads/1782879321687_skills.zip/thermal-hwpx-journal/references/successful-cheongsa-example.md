# Successful Cheongsa Example

This is the concrete workflow that produced a valid result for:

`C:\SynologyDrive\업무\자동화\열화상\청사전기실\output`

The folder contained:

- One HWPX template: `청사 전기실 1년점검표(2024.06.).hwpx`
- Image pairs `RB02110X/Y.JPG` through `RB02122X/Y.JPG`

The target table was:

- Title: `전기설비온도측정표(변압기,PT,CT)`
- Shape: 20 rows x 8 columns
- Data rows: table row addresses `6` through `18`
- Result columns: `2,3,4` for `R,S,T`
- Photo columns: `5` visible (`Y`), `6` thermal (`X`)

Read temperatures:

```csv
base,R,S,T
RB02110,37.3,38.5,36.8
RB02111,35.1,35.7,34.8
RB02112,34.6,35.6,34.4
RB02113,33.7,34.3,33.8
RB02114,30.2,30.4,30.2
RB02115,31.2,31.3,31.1
RB02116,28.9,,28.9
RB02117,28.8,,28.8
RB02118,29.1,,28.9
RB02119,28.9,,28.9
RB02120,30.6,31.1,30.9
RB02121,30.1,30.2,30.1
RB02122,31.7,31.7,31.7
```

The valid output filename was:

`청사 전기실 1년점검표(2026.06.).hwpx`

Validation passed with `hwpxskill/scripts/validate.py` and `hwpxskill/scripts/page_guard.py`.
