---
name: thermal-hwpx-journal
description: Fill Korean electrical thermal inspection HWPX logs from paired visible/thermal images. Use when a folder contains one .hwpx annual inspection report and paired image files where names ending in X are thermal images and names ending in Y are visible images, and Codex must update the 전기설비온도측정표 table with temperature readings and embedded photos, then save a dated copy.
---

# Thermal HWPX Journal

Use this skill to update an HWPX electrical inspection report from paired thermal/visible photos.

## Core Workflow

1. Locate the working folder and confirm it contains one `.hwpx` file plus paired images.
   - Treat names ending in `X` as thermal images.
   - Treat names ending in `Y` as visible images.
   - Sort pairs by base filename and match them to table rows in that order.
2. Inspect the thermal `X` images and read the displayed temperature labels.
   - Read labels left-to-right as `R,S,T`.
   - If only one or two labels are present, leave the unmatched diagonal-formatted cells blank.
   - Do not infer unclear digits. Create enlarged contact sheets or inspect individual images.
3. Prepare a CSV with one row per pair:

```csv
base,R,S,T
RB02110,37.3,38.5,36.8
RB02111,35.1,35.7,34.8
RB02116,28.9,,28.9
```

4. Run `scripts/fill_thermal_hwpx.py` from this skill. It:
   - Finds the `전기설비온도측정표` table.
   - Clears/replaces measurement-result text in columns `R/S/T`.
   - Preserves cell formatting, including diagonal border cells.
   - Replaces existing embedded table images by preserving image IDs and copying `Y` into the visible-photo column and `X` into the thermal-photo column.
   - Updates picture comments with the source filenames.
   - Saves a new `.hwpx` whose date-like filename part is updated to the requested date.

Example:

```powershell
$py = "C:\Users\bysub\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
& $py "C:\Users\bysub\.codex\skills\thermal-hwpx-journal\scripts\fill_thermal_hwpx.py" `
  --input-dir "C:\SynologyDrive\업무\자동화\열화상\청사전기실\output" `
  --values-csv "C:\tmp\thermal-values.csv" `
  --date "2026-06-03"
```

If Python has trouble writing to a Korean path, write to `C:\tmp` with `--output` and copy the completed file back with PowerShell `Copy-Item`.

5. Validate the result.
   - Prefer `hwpxskill` validation if available:

```powershell
& $py "C:\Users\bysub\.codex\skills\hwpxskill\scripts\validate.py" "result.hwpx"
& $py "C:\Users\bysub\.codex\skills\hwpxskill\scripts\page_guard.py" --reference "template.hwpx" --output "result.hwpx"
```

   - At minimum, re-open the resulting HWPX or unpack it and summarize the target table.

## Contact Sheet Aid

Use `scripts/make_contact_sheet.py` to create enlarged sheets for manual reading:

```powershell
& $py "C:\Users\bysub\.codex\skills\thermal-hwpx-journal\scripts\make_contact_sheet.py" `
  --input-dir "C:\SynologyDrive\업무\자동화\열화상\청사전기실\output" `
  --pattern "*X.JPG" `
  --output "C:\tmp\thermal-contact.jpg"
```

Inspect the generated image with `view_image` and record readings in the CSV.

## Important Rules

- Do not create new table rows unless the user explicitly asks. The row count and picture slots should already match the image pairs.
- Do not remove diagonal-border cell formatting; leave those cells blank.
- Do not rely on existing measurement values in the HWPX. Replace them with readings from the current thermal photos.
- Preserve the source HWPX. Always save a new dated copy.
- Use ASCII scratch paths such as `C:\tmp\thermal_hwpx_work` when unpacking or repacking HWPX files.
