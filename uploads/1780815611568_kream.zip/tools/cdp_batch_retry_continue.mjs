import fs from "node:fs/promises";
import path from "node:path";
import { CdpClient, getTargets, getVersion } from "./cdp_lib.mjs";

function parseArgs(argv) {
  const args = {
    port: 9222,
    productIds: [],
    size: "M",
    sizeIndex: null,
    quantity: 1,
    output: "analysis/batch-retry-current.jsonl",
    maxAttempts: 1,
    maxDurationMs: null,
    retryDelayMs: 8000,
    rateLimitCooldownMs: 11000,
    pageLoadMs: 5000,
    responseWaitMs: 5000,
    concurrency: null,
    strategy: "focus",
    clickMode: "js",
    humanLog: false,
    keepSuccessTab: false,
    executeClick: false,
  };

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--port") args.port = Number(argv[++i]);
    else if (arg === "--product-ids") args.productIds = argv[++i].split(",").map((id) => id.trim()).filter(Boolean);
    else if (arg === "--product-id") args.productIds.push(argv[++i]);
    else if (arg === "--size") args.size = argv[++i];
    else if (arg === "--size-index") args.sizeIndex = Number(argv[++i]);
    else if (arg === "--quantity") args.quantity = Number(argv[++i]);
    else if (arg === "--output") args.output = argv[++i];
    else if (arg === "--max-attempts") args.maxAttempts = Number(argv[++i]);
    else if (arg === "--max-duration-ms") args.maxDurationMs = Number(argv[++i]);
    else if (arg === "--retry-delay-ms") args.retryDelayMs = Number(argv[++i]);
    else if (arg === "--rate-limit-cooldown-ms") args.rateLimitCooldownMs = Number(argv[++i]);
    else if (arg === "--page-load-ms") args.pageLoadMs = Number(argv[++i]);
    else if (arg === "--response-wait-ms") args.responseWaitMs = Number(argv[++i]);
    else if (arg === "--concurrency") args.concurrency = Number(argv[++i]);
    else if (arg === "--strategy") args.strategy = argv[++i];
    else if (arg === "--click-mode") args.clickMode = argv[++i];
    else if (arg === "--human-log") args.humanLog = true;
    else if (arg === "--keep-success-tab") args.keepSuccessTab = true;
    else if (arg === "--execute-click") args.executeClick = true;
  }

  if (args.productIds.length === 0) throw new Error("Pass --product-ids 838316,232758,238462.");
  if ((!args.size && !Number.isInteger(args.sizeIndex)) || !Number.isFinite(args.quantity) || args.quantity < 1) {
    throw new Error("Pass --size M --quantity 1 or --size-index 0 --quantity 1.");
  }
  if (!Number.isInteger(args.maxAttempts) || args.maxAttempts < 1) throw new Error("--max-attempts must be a positive integer.");
  if (args.maxDurationMs !== null && (!Number.isFinite(args.maxDurationMs) || args.maxDurationMs < 1)) {
    throw new Error("--max-duration-ms must be a positive number.");
  }
  if (!Number.isFinite(args.retryDelayMs) || args.retryDelayMs < 0) throw new Error("--retry-delay-ms must be non-negative.");
  if (!Number.isFinite(args.rateLimitCooldownMs) || args.rateLimitCooldownMs < 0) throw new Error("--rate-limit-cooldown-ms must be non-negative.");
  if (args.concurrency !== null && (!Number.isInteger(args.concurrency) || args.concurrency < 1)) {
    throw new Error("--concurrency must be a positive integer.");
  }
  if (!["focus", "round-robin", "parallel"].includes(args.strategy)) {
    throw new Error("--strategy must be one of: focus, round-robin, parallel.");
  }
  if (!["js", "mouse"].includes(args.clickMode)) {
    throw new Error("--click-mode must be one of: js, mouse.");
  }
  if (!args.executeClick) throw new Error("This script clicks '신청 계속'. Pass --execute-click to confirm.");

  args.concurrency = args.concurrency ?? (args.strategy === "parallel" ? args.productIds.length : 1);
  return args;
}

function sanitizeHeaders(headers = {}) {
  const blocked = new Set(["authorization", "cookie", "set-cookie", "x-kream-device-id"]);
  const sanitized = {};
  for (const [key, value] of Object.entries(headers)) {
    if (!blocked.has(key.toLowerCase())) sanitized[key] = value;
  }
  return sanitized;
}

function isReviewRequest(url) {
  return url.includes("/api/seller/inventory/stock_request/review");
}

function isStockRequest(url) {
  return url.includes("/api/seller/inventory/stock_request/");
}

function getHeader(headers, name) {
  const target = name.toLowerCase();
  for (const [key, value] of Object.entries(headers || {})) {
    if (key.toLowerCase() === target) return value;
  }
  return null;
}

function retryAfterToMs(value) {
  if (!value) return null;
  const numeric = Number(value);
  if (Number.isFinite(numeric)) return Math.max(0, numeric * 1000);
  const dateMs = Date.parse(value);
  if (Number.isFinite(dateMs)) return Math.max(0, dateMs - Date.now());
  return null;
}

function parseBody(body) {
  if (!body || body === "[base64 omitted]") return null;
  try {
    return JSON.parse(body);
  } catch {
    return null;
  }
}

function summarizeInitiator(initiator) {
  if (!initiator) return null;
  const stackFrames = [];
  let current = initiator.stack;
  while (current) {
    for (const frame of current.callFrames ?? []) {
      stackFrames.push({
        functionName: frame.functionName || null,
        url: frame.url ? frame.url.split("?")[0] : null,
        lineNumber: frame.lineNumber,
        columnNumber: frame.columnNumber,
      });
      if (stackFrames.length >= 8) break;
    }
    if (stackFrames.length >= 8) break;
    current = current.parent;
  }
  return {
    type: initiator.type ?? null,
    url: initiator.url ? initiator.url.split("?")[0] : null,
    lineNumber: initiator.lineNumber ?? null,
    columnNumber: initiator.columnNumber ?? null,
    stackFrames,
  };
}

function summarizeReviewResponse(item) {
  const body = parseBody(item?.responseBody);
  const retryAfterMs = retryAfterToMs(getHeader(item?.responseHeaders, "Retry-After"));
  const message = body?.message ?? null;
  const code = body?.code ?? null;
  const status = item?.status ?? null;
  const isPostLike = item?.method === "POST" || (item?.method == null && isReviewRequest(item?.url ?? ""));
  const isSuccess = isPostLike && status >= 200 && status < 300;
  const isRestrictedCategory = isPostLike
    && status === 400
    && code === 9999
    && typeof message === "string"
    && message.includes("신규 보관 신청이 제한된 카테고리");
  const isRateLimit = typeof message === "string"
    && message.includes("허용된 요청 횟수를 초과했습니다");
  const isServerError = isPostLike && status >= 500;

  let outcome = "unknown";
  if (isSuccess) outcome = "success";
  else if (isServerError) outcome = "server_error";
  else if (isRateLimit) outcome = "hard_cooldown";
  else if (isRestrictedCategory) outcome = "retryable_restricted_category";
  else if (isPostLike && status >= 400) outcome = "error";

  return {
    outcome,
    method: item?.method ?? null,
    status,
    code,
    message,
    alertType: body?.alert_type ?? null,
    retryAfterMs,
    url: item?.url ? item.url.split("?")[0] : null,
    requestItemSummary: item?.postData?.items?.map((row) => ({
      productId: row.product_id,
      option: row.option,
      quantity: row.quantity,
      productOptionId: row.product_option?.id,
    })) ?? null,
    successSummary: isSuccess ? {
      reviewId: body?.id ?? null,
      totalQuantity: body?.total_quantity ?? null,
      deposit: body?.deposit ?? null,
      totalAmount: body?.total_amount ?? null,
      itemCount: Array.isArray(body?.items) ? body.items.length : null,
      hasReturnAddress: Boolean(body?.return_address),
      hasPaymentMethod: Boolean(body?.payment_method),
    } : null,
  };
}

async function appendJsonLine(filePath, value) {
  if (!filePath) return;
  const resolved = path.resolve(filePath);
  await fs.mkdir(path.dirname(resolved), { recursive: true });
  await fs.appendFile(resolved, `${JSON.stringify(value)}\n`, "utf8");
}

function logHuman(args, value) {
  if (!args.humanLog) return;
  console.log(humanLine(value));
}

function formatKoreanTime(value = new Date()) {
  return new Date(value).toLocaleTimeString("ko-KR", { hour12: false, timeZone: "Asia/Seoul" });
}

function humanLine(value) {
  const time = `[${formatKoreanTime(value.finishedAt ?? value.startedAt ?? new Date())}]`;
  if (value.type === "batch_started") {
    const strategy = value.strategy === "round-robin" ? "품목별 순환"
      : value.strategy === "parallel" ? "병렬 진단"
        : "한 품목 집중";
    return `${time} 신청 준비 완료 - 전략: ${strategy}, 상품: ${value.productIds.join(", ")}`;
  }
  if (value.type === "batch_completed") {
    return `${time} 작업 완료`;
  }
  if (!value.productId) return `${time} 진행 중`;

  const statusMap = {
    success: "신청성공",
    success_duplicate_review_requests: "신청성공(중복요청 감지)",
    retryable_restricted_category: "신규신청제한",
    hard_cooldown: "허용시도제한",
    server_error: "서버오류",
    review_request_failed: "요청실패",
    duplicate_review_requests_failed: "중복요청실패",
    pending_review_response: "응답대기",
    no_review_response: "응답없음",
    duration_exhausted: "시간종료",
    exhausted: "시도종료",
    size_not_found: "사이즈 없음",
    input_not_found: "수량 입력 실패",
    continue_not_found: "신청 버튼 없음",
  };
  const label = statusMap[value.outcome] ?? value.outcome ?? "알 수 없음";
  const status = value.response?.status ? ` (${value.response.status})` : "";
  const reviewId = value.response?.successSummary?.reviewId ? ` / 신청번호 ${value.response.successSummary.reviewId}` : "";
  const duplicate = value.reviewPostRequestCount > 1 ? ` / 요청 ${value.reviewPostRequestCount}회` : "";
  return `${time} ${value.productId} ${label}${status}${reviewId}${duplicate}`;
}

async function sleep(ms) {
  await new Promise((resolve) => setTimeout(resolve, ms));
}

function remainingDurationMs(args) {
  if (!args.deadlineMs) return null;
  return Math.max(0, args.deadlineMs - Date.now());
}

async function sleepWithinDeadline(ms, args) {
  const remainingMs = remainingDurationMs(args);
  if (remainingMs !== null && remainingMs <= 0) return false;
  await sleep(remainingMs === null ? ms : Math.min(ms, remainingMs));
  return remainingDurationMs(args) !== 0;
}

async function createPageTarget(port, url = "about:blank") {
  const version = await getVersion(port);
  const browser = new CdpClient(version.webSocketDebuggerUrl);
  await browser.open();
  try {
    const created = await browser.send("Target.createTarget", { url });
    await sleep(300);
    const targets = await getTargets(port);
    const target = targets.find((item) => item.id === created.targetId);
    if (!target?.webSocketDebuggerUrl) throw new Error(`Created target not found: ${created.targetId}`);
    return target;
  } finally {
    await browser.close();
  }
}

async function closeTarget(port, targetId) {
  const version = await getVersion(port);
  const browser = new CdpClient(version.webSocketDebuggerUrl);
  await browser.open();
  try {
    await browser.send("Target.closeTarget", { targetId });
  } finally {
    await browser.close();
  }
}

async function setQuantityAndClick(cdp, args) {
  const result = await cdp.evaluate(`new Promise((resolve) => {
    const size = ${JSON.stringify(args.size)};
    const sizeIndex = ${JSON.stringify(args.sizeIndex)};
    const quantity = ${JSON.stringify(args.quantity)};
    const clickMode = ${JSON.stringify(args.clickMode)};
    const normalize = (text) => String(text || "").replace(/\\s+/g, " ").trim();
    const rowSize = (el) => normalize(el.querySelector(".size")?.innerText || el.innerText);
    const items = Array.from(document.querySelectorAll(".inventory_size_item"));
    const item = Number.isInteger(sizeIndex)
      ? items[sizeIndex]
      : items.find((el) => rowSize(el) === size);
    if (!item) {
      resolve({
        ok: false,
        error: "size_not_found",
        requestedSize: size,
        requestedSizeIndex: sizeIndex,
        available: items.map((el) => rowSize(el)),
      });
      return;
    }

    const actualSize = rowSize(item);
    const input = item.querySelector("input.counter_quantity_input");
    if (!input) {
      resolve({ ok: false, error: "input_not_found", size: actualSize });
      return;
    }

    input.focus();
    input.value = String(quantity);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));

    setTimeout(() => {
      const continueEl = Array.from(document.querySelectorAll("a, button"))
        .find((el) => normalize(el.innerText).includes("신청 계속"));
      if (!continueEl) {
        resolve({ ok: false, error: "continue_not_found", size: actualSize });
        return;
      }
      const before = {
        className: String(continueEl.className || ""),
        disabledAttr: continueEl.hasAttribute("disabled"),
        text: normalize(continueEl.innerText),
      };
      const rect = continueEl.getBoundingClientRect();
      const clickPoint = {
        x: rect.left + (rect.width / 2),
        y: rect.top + (rect.height / 2),
        width: rect.width,
        height: rect.height,
      };
      if (clickMode === "js") continueEl.click();
      resolve({ ok: true, size: actualSize, quantity, buttonBeforeClick: before, clickMode, clickPoint, href: location.href });
    }, 250);
  })`);
  if (!result?.ok || args.clickMode !== "mouse") return result;

  await cdp.send("Page.bringToFront");
  await cdp.send("Input.dispatchMouseEvent", {
    type: "mouseMoved",
    x: result.clickPoint.x,
    y: result.clickPoint.y,
  });
  await cdp.send("Input.dispatchMouseEvent", {
    type: "mousePressed",
    x: result.clickPoint.x,
    y: result.clickPoint.y,
    button: "left",
    buttons: 1,
    clickCount: 1,
  });
  await cdp.send("Input.dispatchMouseEvent", {
    type: "mouseReleased",
    x: result.clickPoint.x,
    y: result.clickPoint.y,
    button: "left",
    buttons: 0,
    clickCount: 1,
  });
  return { ...result, mouseDispatched: true };
}

async function capturePageState(cdp) {
  return cdp.evaluate(`(() => {
    const normalize = (text) => String(text || "").replace(/\\s+/g, " ").trim();
    const text = normalize(document.body?.innerText || "");
    const nuxt = document.querySelector("#__nuxt")?.__vue_app__?.$nuxt;
    const inventory = nuxt?.$pinia?.state?.value?.inventory;
    const productTitle = Array.from(document.querySelectorAll("h1,h2,h3,p,span,div"))
      .map((el) => normalize(el.innerText))
      .find((value) => value && value.length > 8 && !value.includes("고객센터")) || null;
    return {
      href: location.href,
      title: document.title,
      productTitle,
      hasReviewPageText: text.includes("신청 내역") && text.includes("보증금 결제하기"),
      hasRestrictedText: text.includes("신규 보관 신청이 제한된 카테고리의 상품입니다"),
      hasRateLimitText: text.includes("허용된 요청 횟수를 초과했습니다"),
      review: inventory?.review ? {
        id: inventory.review.id,
        totalQuantity: inventory.review.total_quantity,
        itemCount: Array.isArray(inventory.review.items) ? inventory.review.items.length : null,
        hasReturnAddress: Boolean(inventory.review.return_address),
        hasPaymentMethod: Boolean(inventory.review.payment_method),
      } : null,
    };
  })()`);
}

async function runProductWorker(productId, args) {
  const targetUrl = `https://www.kream.co.kr/inventory/${encodeURIComponent(productId)}`;
  const target = await createPageTarget(args.port, "about:blank");
  const cdp = new CdpClient(target.webSocketDebuggerUrl);
  const requests = new Map();
  const requestEvents = [];
  const responses = [];
  const failedRequests = [];
  let keepTargetOpen = false;
  await cdp.open();

  try {
    await cdp.send("Page.enable");
    await cdp.send("Runtime.enable");
    await cdp.send("Network.enable");
    await cdp.send("Network.setCacheDisabled", { cacheDisabled: true });

    cdp.on("Network.requestWillBeSent", (params) => {
      const url = params.request?.url ?? "";
      if (!isStockRequest(url)) return;
      let postData = null;
      if (params.request.postData) {
        try {
          postData = JSON.parse(params.request.postData);
        } catch {
          postData = "[unparsed]";
        }
      }
      requests.set(params.requestId, {
        requestId: params.requestId,
        url,
        method: params.request.method,
        requestHeaders: sanitizeHeaders(params.request.headers),
        postData,
        wallTime: params.wallTime,
        timestamp: params.timestamp,
        initiator: summarizeInitiator(params.initiator),
      });
      requestEvents.push(requests.get(params.requestId));
    });

    cdp.on("Network.responseReceived", (params) => {
      const url = params.response?.url ?? "";
      if (!isStockRequest(url)) return;
      const request = requests.get(params.requestId) ?? {
        requestId: params.requestId,
        url,
        method: params.response?.requestHeaders?.method ?? null,
        requestHeaders: {},
        postData: null,
        wallTime: null,
      };
      responses.push({
        requestId: params.requestId,
        item: {
          ...request,
          status: params.response.status,
          statusText: params.response.statusText,
          responseHeaders: sanitizeHeaders(params.response.headers),
          responseBody: null,
        },
      });
    });

    cdp.on("Network.loadingFailed", (params) => {
      const request = requests.get(params.requestId);
      if (!request) return;
      failedRequests.push({
        requestId: params.requestId,
        url: request.url,
        method: request.method,
        errorText: params.errorText,
        canceled: params.canceled,
        blockedReason: params.blockedReason ?? null,
      });
    });

    await cdp.send("Page.navigate", { url: targetUrl });
    await sleep(args.pageLoadMs);

    let finalOutcome = "exhausted";
    let lastRecord = null;
    for (let attempt = 1; attempt <= args.maxAttempts; attempt += 1) {
      if (remainingDurationMs(args) === 0) {
        finalOutcome = "duration_exhausted";
        break;
      }

      const startedAt = new Date().toISOString();
      const responseStartIndex = responses.length;
      const requestStartIndex = requestEvents.length;
      const failedStartIndex = failedRequests.length;
      const click = await setQuantityAndClick(cdp, args);
      await sleep(args.responseWaitMs);

      const attemptResponses = responses.slice(responseStartIndex);
      for (const response of attemptResponses) {
        try {
          const body = await cdp.send("Network.getResponseBody", { requestId: response.requestId });
          response.item.responseBody = body.base64Encoded ? "[base64 omitted]" : body.body;
        } catch (error) {
          response.item.responseBodyError = String(error);
        }
      }

      const postResponses = attemptResponses
        .map((entry) => entry.item)
        .filter((item) => isReviewRequest(item.url ?? "") && (item.method === "POST" || item.method == null));
      const primaryResponse = postResponses.at(-1) ?? null;
      const responseSummary = primaryResponse ? summarizeReviewResponse(primaryResponse) : null;
      const networkResponses = attemptResponses.map((entry) => summarizeReviewResponse(entry.item));
      const networkRequests = requestEvents.slice(requestStartIndex).map((item) => ({
        requestId: item.requestId,
        method: item.method,
        url: item.url ? item.url.split("?")[0] : null,
        wallTime: item.wallTime ?? null,
        timestamp: item.timestamp ?? null,
        initiator: item.initiator ?? null,
        hasPostData: Boolean(item.postData),
        postDataSummary: item.postData?.items?.map((row) => ({
          productId: row.product_id,
          option: row.option,
          quantity: row.quantity,
          productOptionId: row.product_option?.id,
        })) ?? null,
      }));
      const networkFailures = failedRequests.slice(failedStartIndex).map((item) => ({
        method: item.method,
        url: item.url ? item.url.split("?")[0] : null,
        errorText: item.errorText,
        canceled: item.canceled,
        blockedReason: item.blockedReason,
      }));
      const answeredRequestIds = new Set(attemptResponses.map((entry) => entry.requestId));
      const failedRequestIds = new Set(failedRequests.slice(failedStartIndex).map((item) => item.requestId));
      const pendingReviewRequests = requestEvents
        .slice(requestStartIndex)
        .filter((item) => isReviewRequest(item.url ?? "")
          && item.method === "POST"
          && !answeredRequestIds.has(item.requestId)
          && !failedRequestIds.has(item.requestId))
        .map((item) => ({
          method: item.method,
          url: item.url ? item.url.split("?")[0] : null,
          postDataSummary: item.postData?.items?.map((row) => ({
            productId: row.product_id,
            option: row.option,
            quantity: row.quantity,
            productOptionId: row.product_option?.id,
          })) ?? null,
        }));
      const reviewPostRequestCount = requestEvents
        .slice(requestStartIndex)
        .filter((item) => isReviewRequest(item.url ?? "") && item.method === "POST")
        .length;
      const pageState = await capturePageState(cdp);

      let outcome = responseSummary?.outcome ?? "no_review_response";
      if (!click.ok) outcome = click.error;
      if (pendingReviewRequests.length > 0 && outcome === "no_review_response") outcome = "pending_review_response";
      if (networkFailures.some((item) => isReviewRequest(item.url ?? "") && item.method === "POST") && outcome === "no_review_response") {
        outcome = "review_request_failed";
      }
      if (reviewPostRequestCount > 1 && outcome === "success") {
        outcome = "success_duplicate_review_requests";
      } else if (reviewPostRequestCount > 1 && outcome === "review_request_failed") {
        outcome = "duplicate_review_requests_failed";
      }
      if (pageState.hasRateLimitText && !String(outcome).startsWith("success")) outcome = "hard_cooldown";

      const record = {
        productId,
        attempt,
        maxAttempts: args.maxAttempts,
        startedAt,
        finishedAt: new Date().toISOString(),
        targetUrl,
        tabTargetId: target.id,
        click,
        outcome,
        response: responseSummary,
        reviewPostRequestCount,
        networkRequests,
        networkResponses,
        networkFailures,
        pendingReviewRequests,
        pageState,
      };
      lastRecord = record;

      await appendJsonLine(args.output, record);
      if (args.humanLog) logHuman(args, record);
      else console.log(JSON.stringify(record));

      if (outcome === "success") {
        finalOutcome = "success";
        break;
      }

      if (outcome === "hard_cooldown") {
        const waitMs = responseSummary?.retryAfterMs ?? args.rateLimitCooldownMs;
        if (attempt >= args.maxAttempts) {
          finalOutcome = "hard_cooldown";
          break;
        }
        if (!await sleepWithinDeadline(waitMs, args)) {
          finalOutcome = "duration_exhausted";
          break;
        }
        continue;
      }

      if (outcome === "retryable_restricted_category" && attempt < args.maxAttempts) {
        const waitMs = responseSummary?.retryAfterMs ?? args.retryDelayMs;
        if (!await sleepWithinDeadline(waitMs, args)) {
          finalOutcome = "duration_exhausted";
          break;
        }
        continue;
      }

      if (outcome === "no_review_response" && attempt < args.maxAttempts) {
        if (!await sleepWithinDeadline(args.retryDelayMs, args)) {
          finalOutcome = "duration_exhausted";
          break;
        }
        if (remainingDurationMs(args) === 0) {
          finalOutcome = "duration_exhausted";
          break;
        }
        await cdp.send("Page.navigate", { url: targetUrl });
        if (!await sleepWithinDeadline(args.pageLoadMs, args)) {
          finalOutcome = "duration_exhausted";
          break;
        }
        continue;
      }

      if (outcome === "pending_review_response") {
        finalOutcome = "pending_review_response";
        break;
      }

      finalOutcome = outcome;
      break;
    }

    keepTargetOpen = args.keepSuccessTab && ["success", "success_duplicate_review_requests"].includes(finalOutcome);
    if (keepTargetOpen) {
      await cdp.send("Page.bringToFront");
    }

    return {
      productId,
      finalOutcome,
      targetUrl,
      tabTargetId: target.id,
      keptOpen: keepTargetOpen,
      lastStatus: lastRecord?.response?.status ?? null,
      lastRetryAfterMs: lastRecord?.response?.retryAfterMs ?? null,
      finishedAt: new Date().toISOString(),
    };
  } finally {
    await cdp.close();
    if (!keepTargetOpen) {
      await closeTarget(args.port, target.id);
    }
  }
}

async function runPool(items, concurrency, worker) {
  const results = [];
  let nextIndex = 0;
  const runners = Array.from({ length: Math.min(concurrency, items.length) }, async () => {
    while (nextIndex < items.length) {
      const index = nextIndex;
      nextIndex += 1;
      results[index] = await worker(items[index]);
    }
  });
  await Promise.all(runners);
  return results;
}

function shouldStopAccountQueue(result) {
  return [
    "success",
    "success_duplicate_review_requests",
    "duration_exhausted",
    "pending_review_response",
    "review_request_failed",
    "duplicate_review_requests_failed",
    "server_error",
  ].includes(result.finalOutcome);
}

function nextAccountDelayMs(result, args) {
  if (result.finalOutcome === "hard_cooldown") return result.lastRetryAfterMs ?? args.rateLimitCooldownMs;
  if (result.finalOutcome === "retryable_restricted_category") return result.lastRetryAfterMs ?? args.retryDelayMs;
  if (result.finalOutcome === "no_review_response") return args.retryDelayMs;
  return 0;
}

async function runFocusQueue(productIds, args) {
  const results = [];
  for (const productId of productIds) {
    if (remainingDurationMs(args) === 0) break;
    const result = await runProductWorker(productId, args);
    results.push(result);
    if (shouldStopAccountQueue(result)) break;
  }
  return results;
}

async function runRoundRobinQueue(productIds, args) {
  const results = [];
  const attemptsByProductId = new Map(productIds.map((productId) => [productId, 0]));
  let index = 0;
  while (remainingDurationMs(args) !== 0) {
    const available = productIds.filter((productId) => attemptsByProductId.get(productId) < args.maxAttempts);
    if (available.length === 0) break;

    const productId = available[index % available.length];
    index += 1;
    attemptsByProductId.set(productId, attemptsByProductId.get(productId) + 1);

    const result = await runProductWorker(productId, { ...args, maxAttempts: 1 });
    results.push({
      ...result,
      accountAttempt: results.length + 1,
      productAttempt: attemptsByProductId.get(productId),
    });
    if (shouldStopAccountQueue(result)) break;

    const waitMs = nextAccountDelayMs(result, args);
    if (waitMs > 0 && !await sleepWithinDeadline(waitMs, args)) break;
  }
  return results;
}

const args = parseArgs(process.argv.slice(2));
args.deadlineMs = args.maxDurationMs ? Date.now() + args.maxDurationMs : null;
await fs.mkdir(path.dirname(path.resolve(args.output)), { recursive: true });
await fs.writeFile(path.resolve(args.output), "", "utf8");

const started = {
  type: "batch_started",
  startedAt: new Date().toISOString(),
  productIds: args.productIds,
  size: args.size,
  sizeIndex: args.sizeIndex,
  quantity: args.quantity,
  maxAttempts: args.maxAttempts,
  maxDurationMs: args.maxDurationMs,
  retryDelayMs: args.retryDelayMs,
  rateLimitCooldownMs: args.rateLimitCooldownMs,
  strategy: args.strategy,
  clickMode: args.clickMode,
  concurrency: args.concurrency,
};
await appendJsonLine(args.output, started);
if (args.humanLog) logHuman(args, started);
else console.log(JSON.stringify(started));

let results;
if (args.strategy === "parallel") {
  results = await runPool(args.productIds, args.concurrency, (productId) => runProductWorker(productId, args));
} else if (args.strategy === "round-robin") {
  results = await runRoundRobinQueue(args.productIds, args);
} else {
  results = await runFocusQueue(args.productIds, args);
}
const completed = {
  type: "batch_completed",
  finishedAt: new Date().toISOString(),
  results,
};
await appendJsonLine(args.output, completed);
if (args.humanLog) logHuman(args, completed);
else console.log(JSON.stringify(completed, null, 2));
